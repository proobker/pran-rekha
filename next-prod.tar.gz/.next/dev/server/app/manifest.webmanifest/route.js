var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/node_modules_next_1y9yhdq._.js")
R.c("server/chunks/[root-of-the-server]__0ox19qk._.js")
R.c("server/chunks/apps_web__next-internal_server_app_manifest_webmanifest_route_actions_0y8malo.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/src/app/manifest--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/src/app/manifest--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
