module.exports = [
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/buffer [external] (buffer, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

var mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[project]/apps/web/src/platform/EnrollFace.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EnrollFace",
    ()=>EnrollFace
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/face.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/PhotoCapture.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$RegisterPatient$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/RegisterPatient.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function EnrollFace({ patients }) {
    const [pid, setPid] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [ready, setReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [consent, setConsent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [face, setFace] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadModels"])().then(()=>setReady(true), ()=>setMessage('Face model unavailable. Try again when the model is available.'));
    }, []);
    async function capture(source) {
        setBusy(true);
        setFace(null);
        setMessage('');
        try {
            setFace({
                photo: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$RegisterPatient$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toJpeg"])(source),
                descriptor: Array.from(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["describe"])(source))
            });
        } catch (e) {
            setMessage(e instanceof Error ? e.message : 'Photo could not be processed');
        } finally{
            setBusy(false);
        }
    }
    async function save() {
        if (!pid || !face || !consent) return;
        setBusy(true);
        setMessage('');
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + pid + '/face', {
                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                consent: true,
                ...face
            });
            setMessage('Photo saved. Face lookup is now available for this patient.');
            setFace(null);
            setConsent(false);
        } catch (e) {
            setMessage(e instanceof Error ? e.message : 'Photo could not be saved');
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface wide",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    children: "Add or update patient photo"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 24,
                    columnNumber: 55
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Select an existing patient. Their RFID card and medical record stay linked."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 25,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Patient",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            value: pid,
                            disabled: busy,
                            onChange: (e)=>{
                                setPid(e.target.value);
                                setFace(null);
                                setConsent(false);
                                setMessage('');
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                    value: "",
                                    children: "Choose patient"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                                    lineNumber: 26,
                                    columnNumber: 142
                                }, this),
                                patients.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: p.id,
                                        children: [
                                            p.name,
                                            " — ",
                                            p.id
                                        ]
                                    }, p.id, true, {
                                        fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                                        lineNumber: 26,
                                        columnNumber: 199
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                            lineNumber: 26,
                            columnNumber: 19
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 26,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PhotoCapture"], {
                    disabled: !ready || !pid || busy,
                    busy: busy,
                    alt: "Patient enrollment photo",
                    onImage: capture,
                    onError: setMessage
                }, pid, false, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 27,
                    columnNumber: 5
                }, this),
                face && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "One face detected. Ready to save."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 28,
                    columnNumber: 12
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "check",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "checkbox",
                            checked: consent,
                            onChange: (e)=>setConsent(e.target.checked)
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                            lineNumber: 29,
                            columnNumber: 30
                        }, this),
                        "Participant consents to storing this photo for demo face lookup"
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 29,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    disabled: !pid || !face || !consent || busy,
                    onClick: ()=>void save(),
                    children: "Save patient photo"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 30,
                    columnNumber: 5
                }, this),
                message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    children: message
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
                    lineNumber: 31,
                    columnNumber: 15
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
            lineNumber: 24,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/EnrollFace.tsx",
        lineNumber: 24,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/FaceLookup.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FaceLookup",
    ()=>FaceLookup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scan$2d$face$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ScanFace$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/scan-face.js [app-ssr] (ecmascript) <export default as ScanFace>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/trash-2.js [app-ssr] (ecmascript) <export default as Trash2>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/face.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/PhotoCapture.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const demoPatient = {
    id: 'PR-9042-8819',
    name: 'Siddharth Raj Sharma'
};
function FaceLookup({ patients = [] }) {
    const [consent, setConsent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('identify');
    const [registered, setRegistered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]), [gallery, setGallery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [label, setLabel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('Demo participant A'), [patientId, setPatientId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(demoPatient.id);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [captureKey, setCaptureKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [modelState, setModelState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('idle');
    const [result, setResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    function clearAll() {
        setGallery([]);
        setRegistered([]);
        setResult(null);
        setCaptureKey((k)=>k + 1);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const onHide = ()=>clearAll();
        window.addEventListener('pagehide', onHide);
        return ()=>window.removeEventListener('pagehide', onHide);
    }, []);
    // A newly registered patient becomes the enrollment target.
    const latest = patients.at(-1);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (latest) {
            setPatientId(latest.id);
            setLabel(latest.name);
        }
    }, [
        latest?.id
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!consent) {
            clearAll();
            return;
        }
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadModels"])().then(()=>setModelState('ready'), ()=>setModelState('unavailable'));
    }, [
        consent
    ]);
    // Registered faces come from the server; refetch when this session registers someone new.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!consent) return;
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/faces').then((rows)=>setRegistered(rows.map((f)=>({
                    handle: 'reg-' + f.patientId,
                    label: f.name,
                    patientId: f.patientId,
                    descriptor: Float32Array.from(f.descriptor)
                }))), ()=>setError('Registered faces could not be loaded.'));
    }, [
        consent,
        patients.length
    ]);
    async function process(source) {
        setBusy(true);
        setError('');
        setMessage('');
        setResult(null);
        try {
            const descriptor = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["describe"])(source);
            if (mode === 'enroll') {
                if (gallery.length >= __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MAX_ENROLLED"]) throw new __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaceInputError"]('Session gallery holds at most ' + __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MAX_ENROLLED"] + ' participants.');
                setGallery([
                    ...gallery,
                    {
                        handle: 'cand-' + crypto.randomUUID().slice(0, 8),
                        label: label.trim(),
                        patientId,
                        descriptor
                    }
                ]);
                setMessage('Enrolled ' + label.trim() + ' for this session only.');
            } else {
                const all = [
                    ...registered,
                    ...gallery
                ];
                setResult(all.length ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["match"])(descriptor, all) : {
                    state: 'NO_MATCH'
                });
            }
        } catch (e) {
            if (e instanceof __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaceInputError"]) setError(e.message);
            else {
                setModelState('unavailable');
                setResult({
                    state: 'UNAVAILABLE'
                });
            }
        } finally{
            setBusy(false);
        }
    }
    const enrollBlocked = mode === 'enroll' && (!label.trim() || gallery.length >= __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MAX_ENROLLED"]);
    const disabled = !consent || modelState !== 'ready' || enrollBlocked;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface wide face-lookup",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "board-heading",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$scan$2d$face$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ScanFace$3e$__["ScanFace"], {}, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 60,
                                    columnNumber: 40
                                }, this),
                                " Possible patient lookup"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 60,
                            columnNumber: 36
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: 'pill' + (modelState === 'unavailable' ? ' unavailable' : ''),
                            children: modelState === 'unavailable' ? 'UNAVAILABLE' : 'LIVE local matcher'
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 61,
                            columnNumber: 7
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 60,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Suggests a candidate from an uploaded photo or camera frame. Matching runs in this browser against faces saved at registration and any session-only enrollments. A candidate grants no record access."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 62,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    className: "check",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "checkbox",
                            checked: consent,
                            onChange: (e)=>setConsent(e.target.checked)
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 63,
                            columnNumber: 30
                        }, this),
                        "Consent to face candidate matching for this image"
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 63,
                    columnNumber: 5
                }, this),
                consent && modelState === 'idle' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    children: "Loading local face model…"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 64,
                    columnNumber: 36
                }, this),
                modelState === 'unavailable' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "error",
                    children: "Face model unavailable. Use the RFID, QR or manual locator route."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 65,
                    columnNumber: 34
                }, this),
                consent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "face-counts",
                    children: [
                        "Registered faces: ",
                        registered.length,
                        " · Session-enrolled: ",
                        gallery.length
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 66,
                    columnNumber: 15
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "face-tabs",
                    role: "tablist",
                    children: [
                        'identify',
                        'enroll'
                    ].map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            role: "tab",
                            "aria-selected": mode === m,
                            className: mode === m ? 'primary' : '',
                            onClick: ()=>{
                                setMode(m);
                                setResult(null);
                                setError('');
                                setMessage('');
                            },
                            children: m === 'identify' ? 'Identify' : 'Session enroll (' + gallery.length + '/' + __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MAX_ENROLLED"] + ')'
                        }, m, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 69,
                            columnNumber: 48
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 68,
                    columnNumber: 5
                }, this),
                mode === 'enroll' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "face-enroll",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Participant label",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: label,
                                    onChange: (e)=>setLabel(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 73,
                                    columnNumber: 31
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 73,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Synthetic patient",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: patientId,
                                    onChange: (e)=>setPatientId(e.target.value),
                                    children: [
                                        demoPatient,
                                        ...patients
                                    ].map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: p.id,
                                            children: [
                                                p.name,
                                                " · ",
                                                p.id
                                            ]
                                        }, p.id, true, {
                                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                            lineNumber: 74,
                                            columnNumber: 134
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 74,
                                    columnNumber: 31
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 74,
                            columnNumber: 7
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 72,
                    columnNumber: 23
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PhotoCapture"], {
                    disabled: disabled,
                    busy: busy,
                    alt: "Captured image",
                    onImage: process,
                    onError: setError
                }, captureKey, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 77,
                    columnNumber: 5
                }, this),
                busy && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    children: "Analysing locally…"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 78,
                    columnNumber: 12
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "error",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 79,
                    columnNumber: 13
                }, this),
                message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    children: message
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 80,
                    columnNumber: 15
                }, this),
                result && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: 'face-result ' + result.state.toLowerCase(),
                    role: "status",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "eyebrow",
                            children: result.state.replace('_', ' ')
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 83,
                            columnNumber: 7
                        }, this),
                        result.state === 'CANDIDATES' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "Possible candidate. Record remains locked."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 84,
                                    columnNumber: 39
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    className: "face-candidates",
                                    children: result.candidates.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: [
                                                c.handle.startsWith('reg-') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                    src: '/api/platform/faces/' + encodeURIComponent(c.patientId) + '/photo',
                                                    width: 56,
                                                    height: 56,
                                                    alt: 'Registered photo of ' + c.label
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                                    lineNumber: 86,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        c.label,
                                                        " · ",
                                                        c.patientId,
                                                        " · ",
                                                        c.handle.startsWith('reg-') ? 'registered' : 'session'
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                                    lineNumber: 87,
                                                    columnNumber: 11
                                                }, this)
                                            ]
                                        }, c.handle, true, {
                                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                            lineNumber: 85,
                                            columnNumber: 67
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 85,
                                    columnNumber: 9
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Compare the registered photo, then confirm linkage through the RFID, QR or manual locator workflow before any record access."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 88,
                                    columnNumber: 9
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 84,
                            columnNumber: 37
                        }, this),
                        result.state === 'NO_MATCH' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "No enrolled candidate is plausible for this image."
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 89,
                            columnNumber: 35
                        }, this),
                        result.state === 'AMBIGUOUS' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Too many plausible candidates. Use the locator route."
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 90,
                            columnNumber: 36
                        }, this),
                        result.state === 'UNAVAILABLE' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Matcher unavailable. Use the locator route."
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 91,
                            columnNumber: 38
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 82,
                    columnNumber: 14
                }, this),
                gallery.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            children: "Session gallery"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 94,
                            columnNumber: 26
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                            className: "receipts",
                            children: gallery.map((g)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: [
                                        g.label,
                                        " · ",
                                        g.patientId,
                                        " ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            "aria-label": 'Remove ' + g.label,
                                            onClick: ()=>setGallery(gallery.filter((x)=>x.handle !== g.handle)),
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$trash$2d$2$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Trash2$3e$__["Trash2"], {
                                                size: 14
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                                lineNumber: 94,
                                                columnNumber: 240
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                            lineNumber: 94,
                                            columnNumber: 136
                                        }, this)
                                    ]
                                }, g.handle, true, {
                                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                                    lineNumber: 94,
                                    columnNumber: 91
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 94,
                            columnNumber: 50
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setGallery([]),
                            children: "Clear session gallery"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                            lineNumber: 95,
                            columnNumber: 7
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
                    lineNumber: 94,
                    columnNumber: 24
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
            lineNumber: 59,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/FaceLookup.tsx",
        lineNumber: 59,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/HandwrittenUpdate.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HandwrittenUpdate",
    ()=>HandwrittenUpdate
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/notebook-pen.js [app-ssr] (ecmascript) <export default as NotebookPen>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/plus.js [app-ssr] (ecmascript) <export default as Plus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-ssr] (ecmascript) <export default as TriangleAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$categorize$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/categorize.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/medical-lexicon.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/ocr.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/PhotoCapture.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
const kinds = [
    'report',
    'medication',
    'allergy',
    'condition',
    'vital',
    'implant',
    'blood_group'
];
const label = (k)=>k.replace('_', ' ');
function toJpeg(source, maxSide = 1600) {
    const w = source instanceof HTMLImageElement ? source.naturalWidth : source.width, h = source instanceof HTMLImageElement ? source.naturalHeight : source.height;
    const scale = Math.min(1, maxSide / Math.max(w, h)), canvas = document.createElement('canvas');
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
}
function HandwrittenUpdate({ patients, onChange, mode = 'handwritten' }) {
    const labReport = mode === 'lab-report';
    const [patientId, setPatientId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(patients[0]?.id ?? ''), [revision, setRevision] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [image, setImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [ocrText, setOcrText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [rows, setRows] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [reportSource, setReportSource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [reportNumber, setReportNumber] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [savedSourceId, setSavedSourceId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [patientIdentityVerified, setPatientIdentityVerified] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [date, setDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(new Date().toISOString().slice(0, 10)), [compared, setCompared] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [engine, setEngine] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TROCR_ENGINE"]), [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [captureKey, setCaptureKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!patients.some((p)=>p.id === patientId)) setPatientId(patients[0]?.id ?? '');
    }, [
        patients
    ]);
    async function loadRevision(id = patientId) {
        if (!id) {
            setRevision(null);
            return;
        }
        setRevision((await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + id)).revision);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        void loadRevision().catch(()=>setRevision(null));
    }, [
        patientId
    ]);
    function reset() {
        setImage('');
        setOcrText('');
        setRows([]);
        setCompared(false);
        setReportSource('');
        setReportNumber('');
        setPatientIdentityVerified(false);
        setSavedSourceId('');
        setCaptureKey((k)=>k + 1);
    }
    async function onImage(source) {
        setBusy(true);
        setError('');
        setStatus('Preparing the photo…');
        setOcrText('');
        setRows([]);
        setCompared(false);
        const progress = (p)=>setStatus(p.stage === 'preparing' ? labReport ? 'Preparing report image…' : 'Finding lines of writing…' : p.stage === 'loading' ? (labReport ? 'Loading the report OCR model ' : 'Downloading the handwriting model ') + p.progress + '% (first time only, about 64 MB)…' : (labReport ? 'Reading report line ' : 'Reading line ') + p.line + ' of ' + p.total + ' on this device…');
        try {
            setImage(toJpeg(source));
            const result = labReport ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["recognizeLabReport"])(source, progress) : await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["recognize"])(source, progress);
            setOcrText(result.text);
            setEngine(result.engine);
            const candidates = mode === 'lab-report' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$categorize$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toLabReportCandidates"])(result.lines) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$categorize$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toCandidates"])(result.lines);
            setRows(candidates);
            setStatus(candidates.length ? candidates.length + ' line(s) recognized. Correct each line and its category against the image.' : 'No text recognized. Add lines manually or retake a sharper, well-lit photo.');
        } catch  {
            setError('OCR engine unavailable. Add lines manually from the image.');
            setStatus('');
        } finally{
            setBusy(false);
        }
    }
    const update = (id, patch)=>setRows(rows.map((r)=>r.id === id ? {
                ...r,
                ...patch
            } : r));
    const included = rows.filter((r)=>r.include);
    const ready = !!image && !!patientId && revision !== null && compared && (!labReport || patientIdentityVerified) && included.length > 0 && included.every((r)=>r.kind && r.text.trim());
    async function submit() {
        setBusy(true);
        setError('');
        try {
            const body = {
                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                expectedRevision: revision,
                image,
                ocrText: ocrText.slice(0, 8000),
                engine,
                sourceType: mode === 'lab-report' ? 'lab_report' : 'handwritten_note',
                ...mode === 'lab-report' && patientIdentityVerified ? {
                    patientIdentityVerified: true
                } : {},
                ...mode === 'lab-report' && reportSource.trim() ? {
                    reportSource: reportSource.trim()
                } : {},
                ...mode === 'lab-report' && reportNumber.trim() ? {
                    reportNumber: reportNumber.trim()
                } : {},
                entries: included.map((r)=>({
                        kind: r.kind,
                        text: r.text.trim(),
                        original: r.original,
                        date
                    }))
            };
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/handwritten', body);
            reset();
            setSavedSourceId(result.sourceId);
            setStatus(body.entries.length + ' entr' + (body.entries.length === 1 ? 'y' : 'ies') + ' signed. Patient approval is required for emergency sharing.');
            await loadRevision();
            await onChange();
        } catch (e) {
            setError(e instanceof Error && e.message === 'CONFLICT' ? 'The record changed since you started. Reload and review again.' : e instanceof Error ? e.message : 'Signing failed');
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface wide handwritten",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "board-heading",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$notebook$2d$pen$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__NotebookPen$3e$__["NotebookPen"], {}, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 73,
                                    columnNumber: 40
                                }, this),
                                " ",
                                labReport ? 'Scan a laboratory report' : 'Handwritten prescription or medical card'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 73,
                            columnNumber: 36
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "pill",
                            children: "OCR draft · human review required"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 73,
                            columnNumber: 141
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                    lineNumber: 73,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: labReport ? 'Scan or upload a report. English text is OCRed on this device; Nepali-script text needs manual transcription. Only explicit diagnosis/impression text can be suggested as a condition. Abnormal results are never converted into diagnoses. The original image and raw OCR text are kept as the source.' : 'Photograph or upload a handwritten note. Text is recognized on this device and sorted into categories; you correct every line before signing. The original image and raw OCR text are kept as the source.'
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                    lineNumber: 74,
                    columnNumber: 5
                }, this),
                !patients.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "No patients you can update yet. Hospital clinicians can update patients they registered."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                    lineNumber: 75,
                    columnNumber: 23
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Patient",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: patientId,
                                    onChange: (e)=>{
                                        setPatientId(e.target.value);
                                        reset();
                                        setStatus('');
                                    },
                                    children: patients.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: p.id,
                                            children: [
                                                p.name,
                                                " · ",
                                                p.id
                                            ]
                                        }, p.id, true, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 76,
                                            columnNumber: 132
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 76,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 76,
                            columnNumber: 7
                        }, this),
                        labReport && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    children: [
                                        "Source laboratory",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            maxLength: 160,
                                            value: reportSource,
                                            onChange: (e)=>setReportSource(e.target.value),
                                            placeholder: "As printed on the report"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 77,
                                            columnNumber: 45
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 77,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    children: [
                                        "Lab / accession number (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            maxLength: 120,
                                            value: reportNumber,
                                            onChange: (e)=>setReportNumber(e.target.value)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 77,
                                            columnNumber: 223
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 77,
                                    columnNumber: 183
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "check",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "checkbox",
                                            checked: patientIdentityVerified,
                                            onChange: (e)=>setPatientIdentityVerified(e.target.checked)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 77,
                                            columnNumber: 347
                                        }, this),
                                        "I matched two patient identifiers between the patient and this report."
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 77,
                                    columnNumber: 322
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 77,
                            columnNumber: 19
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "ocr-tips",
                            children: labReport ? 'For best results: keep the full report flat, well lit, and in focus. Make sure table columns and units are visible.' : 'For best results: lay the note flat in good light, fill the frame with it, and photograph one note at a time.'
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 78,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PhotoCapture"], {
                            disabled: !patientId,
                            busy: busy,
                            alt: "Handwritten note",
                            showPreview: false,
                            facing: "environment",
                            onImage: onImage,
                            onError: setError
                        }, captureKey, false, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 79,
                            columnNumber: 7
                        }, this),
                        status && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "status",
                            children: status
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 80,
                            columnNumber: 16
                        }, this),
                        labReport && savedSourceId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: '/api/platform/lab-reports/' + savedSourceId + '/image',
                            target: "_blank",
                            rel: "noreferrer",
                            children: "Open saved report image"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 81,
                            columnNumber: 34
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            role: "alert",
                            className: "error",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 82,
                            columnNumber: 15
                        }, this),
                        labReport && rows.some((r)=>r.kind === 'condition') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                            className: "notice",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: "Explicit condition mentions · draft"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 83,
                                    columnNumber: 81
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                    children: rows.filter((r)=>r.kind === 'condition').map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: r.original
                                        }, r.id, false, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 83,
                                            columnNumber: 182
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 83,
                                    columnNumber: 133
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "These are text matches for clinician review; no condition is inferred from results."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 83,
                                    columnNumber: 221
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 83,
                            columnNumber: 55
                        }, this),
                        image && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "ocr-layout",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                    className: "ocr-original",
                                    src: image,
                                    alt: "Handwritten original for comparison"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 85,
                                    columnNumber: 9
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "ocr-review",
                                    children: [
                                        rows.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: 'ocr-row' + (r.include ? '' : ' excluded'),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "checkbox",
                                                        checked: r.include,
                                                        "aria-label": 'Include line: ' + r.original,
                                                        onChange: (e)=>update(r.id, {
                                                                include: e.target.checked
                                                            })
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                        lineNumber: 88,
                                                        columnNumber: 13
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "ocr-text",
                                                        children: [
                                                            r.original && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                children: [
                                                                    "OCR: ",
                                                                    r.original,
                                                                    r.confidence < __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$categorize$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["LOW_CONFIDENCE"] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "low-confidence",
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__["TriangleAlert"], {
                                                                                size: 12
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                                lineNumber: 90,
                                                                                columnNumber: 115
                                                                            }, this),
                                                                            " low confidence"
                                                                        ]
                                                                    }, void 0, true, {
                                                                        fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                        lineNumber: 90,
                                                                        columnNumber: 82
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                lineNumber: 90,
                                                                columnNumber: 28
                                                            }, this),
                                                            !!r.corrections?.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                className: "ocr-corrections",
                                                                children: [
                                                                    "Dictionary: ",
                                                                    r.corrections.join(', ')
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                lineNumber: 91,
                                                                columnNumber: 41
                                                            }, this),
                                                            r.alternative && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                children: [
                                                                    "Other reading: ",
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        className: "link-button",
                                                                        title: "Use this reading",
                                                                        onClick: ()=>update(r.id, {
                                                                                text: labReport ? r.alternative : (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["correctLine"])(r.alternative).text
                                                                            }),
                                                                        children: r.alternative
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                        lineNumber: 92,
                                                                        columnNumber: 53
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                lineNumber: 92,
                                                                columnNumber: 31
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                "aria-label": "Corrected text",
                                                                value: r.text,
                                                                onChange: (e)=>update(r.id, {
                                                                        text: e.target.value
                                                                    })
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                lineNumber: 93,
                                                                columnNumber: 15
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                        lineNumber: 89,
                                                        columnNumber: 13
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        "aria-label": "Category",
                                                        value: r.kind ?? '',
                                                        onChange: (e)=>update(r.id, {
                                                                kind: e.target.value || null
                                                            }),
                                                        className: r.include && !r.kind ? 'needs-kind' : '',
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: "",
                                                                children: "Choose category…"
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                lineNumber: 96,
                                                                columnNumber: 15
                                                            }, this),
                                                            kinds.map((k)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                    value: k,
                                                                    children: label(k)
                                                                }, k, false, {
                                                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                                    lineNumber: 96,
                                                                    columnNumber: 71
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                        lineNumber: 95,
                                                        columnNumber: 13
                                                    }, this)
                                                ]
                                            }, r.id, true, {
                                                fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                lineNumber: 87,
                                                columnNumber: 24
                                            }, this)),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>setRows([
                                                    ...rows,
                                                    {
                                                        id: 'manual-' + crypto.randomUUID(),
                                                        original: '',
                                                        text: '',
                                                        kind: labReport ? 'report' : null,
                                                        confidence: 100,
                                                        include: true
                                                    }
                                                ]),
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Plus$3e$__["Plus"], {
                                                    size: 16
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                    lineNumber: 99,
                                                    columnNumber: 178
                                                }, this),
                                                " Add line"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 99,
                                            columnNumber: 11
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            children: [
                                                labReport ? 'Report date' : 'Date written',
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "date",
                                                    value: date,
                                                    max: new Date().toISOString().slice(0, 10),
                                                    onChange: (e)=>setDate(e.target.value)
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                    lineNumber: 100,
                                                    columnNumber: 58
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 100,
                                            columnNumber: 11
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            className: "check",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "checkbox",
                                                    checked: compared,
                                                    onChange: (e)=>setCompared(e.target.checked)
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                                    lineNumber: 101,
                                                    columnNumber: 36
                                                }, this),
                                                labReport ? 'I verified every included transcription and category against the original report' : 'I compared every included line with the handwritten original'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 101,
                                            columnNumber: 11
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "primary",
                                            disabled: !ready || busy,
                                            onClick: ()=>void submit(),
                                            children: [
                                                "Sign & commit ",
                                                included.length,
                                                " entr",
                                                included.length === 1 ? 'y' : 'ies'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                            lineNumber: 102,
                                            columnNumber: 11
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                                    lineNumber: 86,
                                    columnNumber: 9
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                            lineNumber: 84,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
                    lineNumber: 75,
                    columnNumber: 119
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
            lineNumber: 72,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/HandwrittenUpdate.tsx",
        lineNumber: 72,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Localized",
    ()=>Localized
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
// UI copy is keyed by its English source so the domain values and API payloads
// remain unchanged when the interface language changes.
const ne = {
    'Patient': 'बिरामी',
    'Paramedic': 'प्यारामेडिक',
    'Hospital': 'अस्पताल',
    'Lab': 'प्रयोगशाला',
    'Sign in': 'साइन इन गर्नुहोस्',
    'Sign out': 'साइन आउट गर्नुहोस्',
    'Health records': 'स्वास्थ्य अभिलेख',
    'Source': 'स्रोत',
    'Emergency release': 'आपत्कालीन पहुँच',
    'Save release': 'पहुँच सुरक्षित गर्नुहोस्',
    'Revoke release': 'पहुँच रद्द गर्नुहोस्',
    'Access receipts': 'पहुँच विवरण',
    'Sign clinical record': 'चिकित्सकीय अभिलेखमा हस्ताक्षर गर्नुहोस्',
    'Initiate pre-arrival dispatch': 'आगमनअघि सूचना पठाउनुहोस्',
    'Read paired RFID scanner': 'जडित RFID स्क्यानर पढ्नुहोस्',
    'Resolve locator': 'परिचायकबाट खोज्नुहोस्',
    'Prepare offline copy': 'अफलाइन प्रति तयार गर्नुहोस्',
    'Book review appointment': 'पुनरावलोकनको समय लिनुहोस्',
    'Add patient report': 'बिरामीको विवरण थप्नुहोस्',
    'Review due': 'पुनरावलोकन गर्नुपर्ने',
    'Synthetic demonstration': 'नमुना प्रदर्शन',
    'Refresh': 'ताजा गर्नुहोस्',
    'I have confirmed patient linkage': 'मैले बिरामीको पहिचान पुष्टि गरेको छु',
    'Access reason': 'पहुँचको कारण',
    'Username': 'प्रयोगकर्ता नाम',
    'Password': 'पासवर्ड',
    'Dark': 'गाढा',
    'Light': 'उज्यालो',
    'Switch to dark mode': 'गाढा मोडमा बदल्नुहोस्',
    'Switch to light mode': 'उज्यालो मोडमा बदल्नुहोस्',
    'English': 'अङ्ग्रेजी',
    'Demo accounts: siddharth, paramedic, hospital and lab. Password: pran-demo- followed by username.': 'डेमो खाताहरू: siddharth, paramedic, hospital र lab। पासवर्ड: pran-demo- पछि प्रयोगकर्ता नाम।',
    'This account has no access to this portal.': 'यो खातालाई यस पोर्टलमा पहुँच छैन।',
    'Sign out and authenticate with the provisioned account for this role.': 'साइन आउट गरी यो भूमिकाका लागि तोकिएको खाताबाट प्रवेश गर्नुहोस्।',
    'Your emergency pass': 'तपाईंको आपत्कालीन परिचयपत्र',
    'Historical recorded blood group · verification required': 'अभिलेखमा रहेको पुरानो रक्त समूह · पुष्टि आवश्यक',
    'FICTIONAL DEMO: date of birth and medical details are generated samples, not verified medical history.': 'काल्पनिक डेमो: जन्ममिति र स्वास्थ्य विवरण नमुना हुन्, पुष्टि गरिएको स्वास्थ्य इतिहास होइन।',
    'Date of birth:': 'जन्ममिति:',
    'Opaque emergency locator QR': 'आपत्कालीन परिचायक QR कोड',
    'Review overdue': 'पुनरावलोकन म्याद नाघेको',
    'Review schedule; current health and medication use require separate assessment.': 'पुनरावलोकन तालिका; हालको स्वास्थ्य र औषधि प्रयोगको छुट्टै मूल्याङ्कन आवश्यक छ।',
    'Review schedule; it does not confirm individual entries are current. Current health and medication use require separate assessment.': 'पुनरावलोकन तालिकाले प्रत्येक विवरण अद्यावधिक छ भन्ने पुष्टि गर्दैन। हालको स्वास्थ्य र औषधि प्रयोगको छुट्टै मूल्याङ्कन आवश्यक छ।',
    'I verified two identifiers against the patient, wristband, or authorized caregiver. Card/QR/face match alone is not identity proof.': 'मैले बिरामी, नाडीपट्टी वा अधिकृत हेरचाहकर्तासँग दुई परिचायक जाँचेको छु। कार्ड/QR/अनुहार मिलान मात्र पहिचानको प्रमाण होइन।',
    ' and the emergency purpose is appropriate.': ' र आपत्कालीन पहुँचको कारण उपयुक्त छ।',
    'Recorded ': 'अभिलेख मिति ',
    ' · verify currentness before use': ' · प्रयोगअघि हालको अवस्था पुष्टि गर्नुहोस्',
    'Second-clinician approval': 'दोस्रो चिकित्सकको स्वीकृति',
    'For already approved scope only': 'पहिले नै स्वीकृत विवरणका लागि मात्र',
    'Face data and privacy': 'अनुहारको विवरण र गोपनीयता',
    'Stored face photo and template are deleted automatically after 30 days, or you can remove them now.': 'सुरक्षित अनुहारको तस्बिर र टेम्प्लेट ३० दिनपछि स्वतः हट्छ; तपाईंले अहिले पनि हटाउन सक्नुहुन्छ।',
    'Scheduled deletion:': 'हटाउने मिति:',
    'Delete my face data': 'मेरो अनुहारको विवरण हटाउनुहोस्',
    'Face data deleted.': 'अनुहारको विवरण हटाइयो।',
    'Needs acknowledgement · use phone/radio if this board is not being monitored': 'स्वीकृति बाँकी · यो बोर्ड नहेरिएको भए फोन/रेडियो प्रयोग गर्नुहोस्',
    'Acknowledge dispatch': 'सूचना प्राप्त भएको पुष्टि गर्नुहोस्',
    'Record completed phone/radio handoff': 'फोन/रेडियोबाट जानकारी दिएको अभिलेख गर्नुहोस्',
    'Phone/radio handoff recorded': 'फोन/रेडियो हस्तान्तरण अभिलेख भयो',
    ' · Phone/radio handoff recorded': ' · फोन/रेडियो हस्तान्तरण अभिलेख भयो',
    'Patient sharing changed. The open summary was cleared; verify identity and scope before requesting access again.': 'बिरामीको साझेदारी परिवर्तन भयो। खुला सारांश हटाइयो; फेरि पहुँच माग्नुअघि पहिचान र स्वीकृत विवरण जाँच्नुहोस्।',
    'Requests access to entries the patient already approved. It cannot expand scope or bypass revocation; verify two identifiers first.': 'यसले बिरामीले पहिले नै स्वीकृत गरेका विवरणमा पहुँच माग्छ। यसले दायरा बढाउन वा रद्दीकरण छल्न सक्दैन; पहिले दुई परिचायक पुष्टि गर्नुहोस्।',
    'Acknowledged by': 'स्वीकृति दिने व्यक्ति',
    ' at ': ' समय ',
    'Business-model simulation': 'व्यापार मोडेलको नमुना',
    'Scan a laboratory report': 'प्रयोगशालाको प्रतिवेदन स्क्यान गर्नुहोस्',
    'OCR draft · human review required': 'OCR मस्यौदा · मानव समीक्षा आवश्यक',
    'Scan or upload a report. English text is OCRed on this device; Nepali-script text needs manual transcription. Only explicit diagnosis/impression text can be suggested as a condition. Abnormal results are never converted into diagnoses. The original image and raw OCR text are kept as the source.': 'प्रतिवेदन स्क्यान वा अपलोड गर्नुहोस्। यस उपकरणमा अंग्रेजी पाठको OCR हुन्छ; नेपाली लिपिको पाठ हातैले उतार्नुपर्छ। निदान/निष्कर्षमा स्पष्ट उल्लेख भएको अवस्थालाई मात्र सुझाव दिइन्छ। असामान्य नतिजालाई रोगको निदान बनाइँदैन। मूल तस्बिर र OCR पाठ स्रोतका रूपमा राखिन्छ।',
    'Source laboratory': 'स्रोत प्रयोगशाला',
    'Lab / accession number (optional)': 'प्रयोगशाला / नमुना नम्बर (वैकल्पिक)',
    'As printed on the report': 'प्रतिवेदनमा छापिएअनुसार',
    'I matched two patient identifiers between the patient and this report.': 'मैले बिरामी र प्रतिवेदनका दुई परिचायक रुजु गरेको छु।',
    'Explicit condition mentions · draft': 'रोग अवस्थाको स्पष्ट उल्लेख · मस्यौदा',
    'These are text matches for clinician review; no condition is inferred from results.': 'यी चिकित्सकले समीक्षा गर्नुपर्ने पाठ मिलान हुन्; नतिजाबाट कुनै रोग अवस्था अनुमान गरिएको छैन।',
    'Report date': 'प्रतिवेदन मिति',
    'I verified every included transcription and category against the original report': 'मैले समावेश गरिएको प्रत्येक पाठ र वर्ग मूल प्रतिवेदनसँग रुजु गरेको छु',
    'Patient to review': 'समीक्षा गर्ने बिरामी',
    'You can switch only among patients assigned to this laboratory.': 'यस प्रयोगशालालाई तोकिएका बिरामीमध्ये मात्र छान्न सकिन्छ।',
    'Laboratory access': 'प्रयोगशालाको पहुँच',
    'No patients are assigned to this hospital account.': 'यस अस्पताल खातामा कुनै बिरामी तोकिएको छैन।',
    'The demo laboratory can review and update this patient.': 'नमुना प्रयोगशालाले यो बिरामीको विवरण समीक्षा र अद्यावधिक गर्न सक्छ।',
    'The demo laboratory cannot access this patient.': 'नमुना प्रयोगशालाले यो बिरामीको विवरण हेर्न सक्दैन।',
    'Remove lab access': 'प्रयोगशालाको पहुँच हटाउनुहोस्',
    'Assign to lab': 'प्रयोगशालालाई तोक्नुहोस्',
    'Loading the report OCR model ': 'प्रतिवेदन OCR मोडेल लोड हुँदैछ ',
    'Preparing report image…': 'प्रतिवेदनको तस्बिर तयार हुँदैछ…',
    'Reading report line ': 'प्रतिवेदनको पङ्क्ति पढ्दैछ ',
    '$50 checkup · 15% Pran Rekha partner discount → $42.50 (simulated)': 'जाँच $५० · प्रण रेखा साझेदारको १५% छुटपछि → $४२.५० (नमुना)',
    'Simulated appointment booked for $42.50. No payment was taken.': '$४२.५० को नमुना भेटघाट तय भयो। कुनै भुक्तानी लिइएन।',
    'Select each entry and its excerpt for emergency sharing.': 'आपत्कालीन अवस्थामा साझा गर्न प्रत्येक विवरण र त्यसको अंश छान्नुहोस्।',
    'Emergency release updated.': 'आपत्कालीन पहुँच अद्यावधिक भयो।',
    'Add a personal note': 'व्यक्तिगत टिप्पणी थप्नुहोस्',
    'Your note': 'तपाईंको टिप्पणी',
    'Attributed to you; this does not change a clinician-signed record.': 'यो विवरण तपाईंको नाममा रहनेछ; यसले चिकित्सकले हस्ताक्षर गरेको अभिलेख परिवर्तन गर्दैन।',
    'No access receipts yet.': 'अहिलेसम्म पहुँच विवरण छैन。',
    'Signed in ·': 'प्रवेश गरिएको ·',
    'Record type': 'अभिलेखको प्रकार',
    'Verbatim observation, result or medication': 'जस्ताको तस्तै अवलोकन, नतिजा वा औषधि',
    'Signed version committed. Patient approval is required for emergency sharing.': 'हस्ताक्षर गरिएको संस्करण सुरक्षित भयो। आपत्कालीन रूपमा साझा गर्न बिरामीको स्वीकृति आवश्यक छ।',
    'Sign & commit to Pran Rekha': 'प्रण रेखामा हस्ताक्षर गरी सुरक्षित गर्नुहोस्',
    'Ed25519 demo signature · integrity verified on every read. Demonstrates record integrity, not accreditation.': 'Ed25519 नमुना हस्ताक्षर · प्रत्येक पटक पढ्दा अखण्डता जाँच हुन्छ। यसले अभिलेखको अखण्डता देखाउँछ, मान्यता होइन।',
    'Simulated revenue ledger': 'नमुना आम्दानी विवरण',
    'No checkups signed yet.': 'अहिलेसम्म कुनै जाँच हस्ताक्षर गरिएको छैन।',
    'Total commission:': 'कुल कमिसन:',
    'Illustrative only. No payments are processed.': 'जानकारीका लागि मात्र। कुनै भुक्तानी प्रक्रिया हुँदैन।',
    'Record history and entries': 'अभिलेखको इतिहास र विवरण',
    'Medication and document tools': 'औषधि तथा कागजातका उपकरण',
    'Review or add source evidence': 'स्रोत प्रमाण हेर्नुहोस् वा थप्नुहोस्',
    'Import documents or review medication history': 'कागजात आयात गर्नुहोस् वा औषधिको इतिहास हेर्नुहोस्',
    'RFID scanner': 'RFID स्क्यानर',
    'Paired reader:': 'जडित रिडर:',
    'Card found. Confirm access below to show the summary on the scanner LCD.': 'कार्ड भेटियो। स्क्यानरको पर्दामा सारांश देखाउन तल पहुँच पुष्टि गर्नुहोस्।',
    'Other ways to find a record': 'अभिलेख खोज्ने अन्य तरिका',
    'Simulate QR scan': 'QR स्क्यानको नमुना',
    'QR / manual locator': 'QR / परिचायक कोड',
    'Consent to session-only face candidate simulation': 'यो सत्रमा मात्र अनुहारको नमुना मिलान गर्न सहमति दिनुहोस्',
    'Simulate face candidate': 'अनुहारको नमुना मिलान गर्नुहोस्',
    'SIMULATED possible local candidate. Record remains locked. No image captured.': 'नमुना सम्भावित मिलान। अभिलेख बन्द नै छ। कुनै तस्बिर खिचिएको छैन।',
    'Pre-arrival access': 'आगमनअघिको पहुँच',
    'Awaiting locator': 'परिचायकको प्रतीक्षामा',
    'Trauma category': 'चोटपटकको वर्ग',
    'Open approved emergency summary': 'स्वीकृत आपत्कालीन सारांश खोल्नुहोस्',
    'Destination: Pran Rekha Demonstration Hospital': 'गन्तव्य: प्रण रेखा नमुना अस्पताल',
    'Initiate pre-arrival ER stream': 'आगमनअघि आपत्कालीन सूचना पठाउनुहोस्',
    'Dispatch committed. The destination hospital can now read its approved scope.': 'सूचना पठाइयो। गन्तव्य अस्पतालले अब स्वीकृत विवरण हेर्न सक्छ।',
    'Incoming patients': 'आगमन गर्ने बिरामी',
    'Sound on': 'ध्वनि चालु',
    'Sound off': 'ध्वनि बन्द',
    'No active authorized dispatches.': 'कुनै सक्रिय स्वीकृत सूचना छैन।',
    'Approved summary': 'स्वीकृत सारांश',
    'Mark arrived': 'आइपुगेको चिनो लगाउनुहोस्',
    'Resolve': 'समाधान गर्नुहोस्',
    'Patient and document tools': 'बिरामी तथा कागजातका उपकरण',
    'Registration · records · face lookup': 'दर्ता · अभिलेख · अनुहार खोज',
    'Prepared offline viewer': 'अफलाइन दर्शक तयार गर्नुहोस्',
    'Unlock or prepare this device': 'यो उपकरण खोल्नुहोस् वा तयार गर्नुहोस्',
    'Unlock phrase (12+ characters)': 'खोल्ने वाक्यांश (कम्तीमा १२ अक्षर)',
    'Encrypted snapshot prepared on this browser.': 'यस ब्राउजरमा गुप्तिकृत प्रतिलिपि तयार भयो।',
    'Unlock saved snapshot': 'सुरक्षित प्रतिलिपि खोल्नुहोस्',
    'Break-glass review': 'आपत्कालीन विशेष पहुँच समीक्षा',
    'Break-glass request': 'आपत्कालीन विशेष पहुँच अनुरोध',
    'Independent emergency access': 'स्वतन्त्र आपत्कालीन पहुँच',
    'Close': 'बन्द गर्नुहोस्',
    'Nepali copy pending native-speaker review · BS conversion unavailable pending verified reference pairs': 'नेपाली अनुवादको समीक्षा हुन बाँकी छ · प्रमाणित रूपान्तरण सन्दर्भ नभएकाले वि.सं. मिति उपलब्ध छैन',
    'Signed demo record ·': 'हस्ताक्षर गरिएको नमुना अभिलेख ·',
    'Patient report · not clinically verified': 'बिरामीले दिएको विवरण · चिकित्सकीय पुष्टि भएको छैन',
    'Historical recorded blood group. Follow the treating service\'s verification and compatibility procedures.': 'अभिलेखमा रहेको पुरानो रक्त समूह। उपचार टोलीको पुष्टि तथा अनुकूलता जाँच प्रक्रिया पालना गर्नुहोस्।',
    'Recorded allergy:': 'अभिलेखमा रहेको एलर्जी:',
    'Review the attributed source; this is not a treatment instruction.': 'उल्लेख गरिएको स्रोत जाँच्नुहोस्; यो उपचार निर्देशन होइन।',
    'Handwritten prescription or medical card': 'हातले लेखिएको औषधि पुर्जा वा स्वास्थ्य कार्ड',
    'OCR candidate · verify against image': 'OCR सुझाव · तस्बिरसँग रुजु गर्नुहोस्',
    'Photograph or upload a handwritten note. Text is recognized on this device and sorted into categories; you correct every line before signing. The original image and raw OCR text are kept as the source.': 'हातले लेखिएको कागजको तस्बिर खिच्नुहोस् वा अपलोड गर्नुहोस्। यस उपकरणमै पाठ पहिचान गरी वर्गीकरण गरिन्छ; हस्ताक्षर गर्नुअघि प्रत्येक पङ्क्ति सच्याउनुहोस्। मूल तस्बिर र OCR पाठ स्रोतका रूपमा राखिन्छ।',
    'No patients you can update yet. Hospital clinicians can update patients they registered.': 'अहिलेसम्म अद्यावधिक गर्न मिल्ने बिरामी छैनन्। अस्पतालका चिकित्सकले आफूले दर्ता गरेका बिरामीको विवरण अद्यावधिक गर्न सक्छन्।',
    'For best results: lay the note flat in good light, fill the frame with it, and photograph one note at a time.': 'राम्रो नतिजाका लागि कागजलाई राम्रो उज्यालोमा सम्याएर राख्नुहोस्, फ्रेमभरि देखिने गरी एक पटकमा एउटा मात्र कागजको तस्बिर खिच्नुहोस्।',
    'Handwritten note': 'हातले लेखिएको कागज',
    'Handwritten original for comparison': 'तुलना गर्न हातले लेखिएको मूल कागज',
    'Include line:': 'यो पङ्क्ति समावेश गर्नुहोस्:',
    'Other reading:': 'अर्को सम्भावित पाठ:',
    'Use this reading': 'यो पाठ प्रयोग गर्नुहोस्',
    'Corrected text': 'सच्याइएको पाठ',
    'Category': 'वर्ग',
    'Choose category…': 'वर्ग छान्नुहोस्…',
    'Add line': 'पङ्क्ति थप्नुहोस्',
    'Date written': 'लेखिएको मिति',
    'I compared every included line with the handwritten original': 'मैले समावेश गरिएका सबै पङ्क्ति मूल कागजसँग तुलना गरेको छु',
    'Registered': 'दर्ता भयो',
    'OCR:': 'OCR:',
    'low confidence': 'कम विश्वासयोग्य',
    'Dictionary:': 'शब्दकोश:',
    'Upload image': 'तस्बिर अपलोड गर्नुहोस्',
    'Use camera': 'क्यामेरा प्रयोग गर्नुहोस्',
    'Capture': 'तस्बिर खिच्नुहोस्',
    'Cancel': 'रद्द गर्नुहोस्',
    'Image could not be read.': 'तस्बिर पढ्न सकिएन।',
    'Camera unavailable or permission denied. Upload an image instead.': 'क्यामेरा उपलब्ध छैन वा अनुमति दिइएन। यसको सट्टा तस्बिर अपलोड गर्नुहोस्।',
    'Register patient': 'बिरामी दर्ता गर्नुहोस्',
    'Creates a synthetic Pran Rekha record, a patient login and an opaque QR locator. You can add a face photo now or later. Emergency sharing stays off until the patient approves each entry.': 'यसले प्रण रेखामा नमुना अभिलेख, बिरामी प्रवेश र गोप्य QR परिचायक बनाउँछ। अनुहारको तस्बिर अहिले वा पछि थप्न सकिन्छ। बिरामीले प्रत्येक विवरण स्वीकृत नगरेसम्म आपत्कालीन साझेदारी बन्द रहन्छ।',
    'Full name': 'पूरा नाम',
    'Date of birth': 'जन्ममिति',
    'Blood group': 'रक्त समूह',
    'Not recorded': 'अभिलेख गरिएको छैन',
    'Recorded allergies': 'अभिलेखमा रहेका एलर्जीहरू',
    'e.g. Penicillin — anaphylaxis': 'जस्तै: पेनिसिलिन — गम्भीर एलर्जी प्रतिक्रिया',
    'RFID tag UID (optional)': 'RFID ट्याग UID (वैकल्पिक)',
    '8, 14 or 20 hex characters': '८, १४ वा २० हेक्साडेसिमल अक्षर',
    'Patient username': 'बिरामीको प्रयोगकर्ता नाम',
    'lowercase, 3–32 characters': 'सानो अक्षर, ३–३२ वर्ण',
    'Initial password': 'सुरुको पासवर्ड',
    '12+ characters': 'कम्तीमा १२ वर्ण',
    'Face photo (optional; can be added later)': 'अनुहारको तस्बिर (वैकल्पिक; पछि थप्न सकिन्छ)',
    'Loading local face model…': 'स्थानीय अनुहार मोडेल लोड हुँदैछ…',
    'Face model unavailable. You can register now and add a photo later.': 'अनुहार मोडेल उपलब्ध छैन। अहिले दर्ता गरेर पछि तस्बिर थप्न सक्नुहुन्छ।',
    'Registration photo': 'दर्ताको तस्बिर',
    'Checking for exactly one face…': 'एउटा मात्र अनुहार छ कि जाँच हुँदैछ…',
    'One face detected. Photo ready.': 'एउटा अनुहार भेटियो। तस्बिर तयार छ।',
    'No photo selected. Face matching becomes available after you add one.': 'तस्बिर छानिएको छैन। तस्बिर थपेपछि अनुहार मिलान उपलब्ध हुनेछ।',
    'Add photo later': 'पछि तस्बिर थप्नुहोस्',
    'Participant consents to storing this face photo on the demo server': 'डेमो सर्भरमा यो अनुहारको तस्बिर राख्न सहभागीको सहमति छ',
    'Synthetic demonstration data only — no real patient information': 'नमुना प्रदर्शनका लागि मात्र — वास्तविक बिरामीको जानकारी होइन',
    'Username or RFID tag is already registered.': 'प्रयोगकर्ता नाम वा RFID ट्याग पहिले नै दर्ता छ।',
    'Some fields are invalid. Check the date of birth and RFID tag UID format.': 'केही विवरण अमान्य छन्। जन्ममिति र RFID ट्याग UID को ढाँचा जाँच्नुहोस्।',
    'Patient login:': 'बिरामी प्रवेश:',
    'sign in at /patient': '/patient मा साइन इन गर्नुहोस्',
    'Emergency sharing is off until the patient approves entries.': 'बिरामीले विवरण स्वीकृत नगरेसम्म आपत्कालीन साझेदारी बन्द रहन्छ।',
    'Registered photo of': 'दर्ता गरिएको तस्बिर:',
    'Opaque emergency locator QR for': 'गोप्य आपत्कालीन QR परिचायक:',
    'Add or update patient photo': 'बिरामीको तस्बिर थप्नुहोस् वा अद्यावधिक गर्नुहोस्',
    'Select an existing patient. Their RFID card and medical record stay linked.': 'अभिलेखमा भएको बिरामी छान्नुहोस्। उहाँको RFID कार्ड र स्वास्थ्य अभिलेख जोडिएकै रहन्छ।',
    'Choose patient': 'बिरामी छान्नुहोस्',
    'Patient enrollment photo': 'बिरामी दर्ताको तस्बिर',
    'One face detected. Ready to save.': 'एउटा अनुहार भेटियो। सुरक्षित गर्न तयार छ।',
    'Participant consents to storing this photo for demo face lookup': 'डेमो अनुहार खोजका लागि यो तस्बिर राख्न सहभागीको सहमति छ',
    'Save patient photo': 'बिरामीको तस्बिर सुरक्षित गर्नुहोस्',
    'Face model unavailable. Try again when the model is available.': 'अनुहार मोडेल उपलब्ध छैन। मोडेल उपलब्ध भएपछि फेरि प्रयास गर्नुहोस्।',
    'Photo could not be processed': 'तस्बिर प्रशोधन गर्न सकिएन',
    'Photo saved. Face lookup is now available for this patient.': 'तस्बिर सुरक्षित भयो। अब यो बिरामीका लागि अनुहार खोज उपलब्ध छ।',
    'Photo could not be saved': 'तस्बिर सुरक्षित गर्न सकिएन。',
    'Possible patient lookup': 'सम्भावित बिरामी खोज',
    'UNAVAILABLE': 'उपलब्ध छैन',
    'LIVE local matcher': 'स्थानीय मिलान चालु',
    'Suggests a candidate from an uploaded photo or camera frame. Matching runs in this browser against faces saved at registration and any session-only enrollments. A candidate grants no record access.': 'अपलोड गरिएको तस्बिर वा क्यामेरा दृश्यबाट सम्भावित बिरामी सुझाउँछ। मिलान यही ब्राउजरमा दर्ताका तस्बिर र यस सत्रमा थपिएका तस्बिरसँग हुन्छ। सम्भावित मिलानले अभिलेख खोल्दैन।',
    'Consent to face candidate matching for this image': 'यो तस्बिरसँग अनुहार मिलान गर्न सहमति दिनुहोस्',
    'Registered faces:': 'दर्ता गरिएका अनुहार:',
    'Session-enrolled:': 'यस सत्रमा थपिएका:',
    'Identify': 'पहिचान गर्नुहोस्',
    'Session enroll (': 'यस सत्रमा थप्नुहोस् (',
    'Participant label': 'सहभागीको नाम',
    'Synthetic patient': 'नमुना बिरामी',
    'Captured image': 'खिचिएको तस्बिर',
    'Analysing locally…': 'स्थानीय रूपमा विश्लेषण हुँदैछ…',
    'Possible candidate. Record remains locked.': 'सम्भावित मिलान। अभिलेख बन्द नै रहन्छ।',
    'Compare the registered photo, then confirm linkage through the RFID, QR or manual locator workflow before any record access.': 'दर्ता गरिएको तस्बिरसँग तुलना गर्नुहोस्, त्यसपछि अभिलेख खोल्नुअघि RFID, QR वा परिचायक कोडबाट पहिचान पुष्टि गर्नुहोस्।',
    'No enrolled candidate is plausible for this image.': 'यो तस्बिरसँग मिल्ने सम्भावित व्यक्ति भेटिएन।',
    'Too many plausible candidates. Use the locator route.': 'धेरै सम्भावित व्यक्ति भेटिए। परिचायक प्रयोग गर्नुहोस्।',
    'Matcher unavailable. Use the locator route.': 'मिलान सेवा उपलब्ध छैन। परिचायक प्रयोग गर्नुहोस्।',
    'Session gallery': 'यस सत्रका तस्बिर',
    'Clear session gallery': 'सत्रका तस्बिर हटाउनुहोस्',
    'Documents and medication history': 'कागजात र औषधिको इतिहास',
    'Import JPEG, PNG or text PDF (10 MiB maximum)': 'JPEG, PNG वा पाठ PDF आयात गर्नुहोस् (अधिकतम १० MiB)',
    'File exceeds 10 MiB.': 'फाइल १० MiB भन्दा ठूलो छ।',
    'Source document': 'स्रोत कागजात',
    'Select source': 'स्रोत छान्नुहोस्',
    'Download private original': 'मूल निजी फाइल डाउनलोड गर्नुहोस्',
    'Page': 'पृष्ठ',
    'No extracted text. Enter an attributed manual transcription below.': 'पाठ निकाल्न सकिएन। तल स्रोत उल्लेख गरी हातैले उतार्नुहोस्।',
    'Source start (UTF-16 offset)': 'स्रोतको सुरु (UTF-16 स्थान)',
    'Source end': 'स्रोतको अन्त्य',
    'Confirmed value': 'पुष्टि गरिएको विवरण',
    'Confirm source and patient': 'स्रोत र बिरामी पुष्टि गर्नुहोस्',
    'Effective clinical date': 'लागू हुने चिकित्सकीय मिति',
    'Attributed statement / source evidence': 'स्रोत उल्लेख वा प्रमाण',
    'Add immutable prescription': 'परिवर्तन गर्न नमिल्ने औषधि पुर्जा थप्नुहोस्',
    'Drug as written': 'पुर्जामा लेखिएको औषधि',
    'Dose as written': 'पुर्जामा लेखिएको मात्रा',
    'Frequency as written': 'पुर्जामा लेखिएको सेवन तालिका',
    'Save prescription evidence': 'औषधि पुर्जाको प्रमाण सुरक्षित गर्नुहोस्',
    'Event kind': 'घटनाको प्रकार',
    'Target event ID (correction/retraction)': 'लक्षित घटना ID (सच्याउने/हटाउने)',
    'Replacement event/record ID': 'वैकल्पिक घटना/अभिलेख ID',
    'Append event': 'घटना थप्नुहोस्',
    'Add attributed use report': 'औषधि प्रयोगको विवरण थप्नुहोस्',
    'Record:': 'अभिलेख:',
    'Reported by': 'विवरण दिने व्यक्ति',
    'at': 'समय',
    'last dose': 'अन्तिम मात्रा',
    'unknown': 'थाहा छैन',
    'Connected break-glass review': 'जडित आपत्कालीन विशेष पहुँच समीक्षा',
    'Requires a distinct clinician approval. Explicitly revoked scopes remain unavailable.': 'अर्को चिकित्सकको स्वीकृति आवश्यक छ। स्पष्ट रूपमा रद्द गरिएको पहुँच उपलब्ध हुँदैन।',
    'Load approval queue': 'स्वीकृति सूची लोड गर्नुहोस्',
    'Approve five-minute access': 'पाँच मिनेटको पहुँच स्वीकृत गर्नुहोस्',
    'Request independent approval': 'स्वतन्त्र स्वीकृति अनुरोध गर्नुहोस्',
    'Check approval': 'स्वीकृति जाँच्नुहोस्',
    'Unconscious polytrauma': 'बेहोस बहु-अङ्ग चोट',
    'Road traffic collision': 'सडक दुर्घटना',
    'Cardiac event': 'मुटुसम्बन्धी घटना',
    'Respiratory distress': 'श्वासप्रश्वासमा कठिनाइ',
    'Burns': 'पोलेको चोट',
    'Fall from height': 'उचाइबाट खसेको',
    'Other': 'अन्य',
    'Active': 'सक्रिय',
    'Revoked': 'रद्द गरियो',
    'fresh': 'नयाँ',
    'aging': 'पुरानो हुँदै',
    'expired': 'म्याद सकियो',
    'vital': 'महत्त्वपूर्ण स्वास्थ्य मापन',
    'medication': 'औषधि',
    'allergy': 'एलर्जी',
    'condition': 'स्वास्थ्य अवस्था',
    'implant': 'शरीरभित्र राखिएको उपकरण',
    'blood group': 'रक्त समूह',
    'donor': 'दाता',
    'Request failed': 'अनुरोध असफल भयो',
    'Session expired. Unlock again.': 'सत्रको म्याद सकियो। फेरि खोल्नुहोस्।',
    'Reader:': 'रिडर:',
    'Session active': 'सत्र सक्रिय',
    'Session required': 'सत्र आवश्यक',
    'Pre-arrival emergency record review': 'आगमनअघि आपत्कालीन अभिलेख समीक्षा',
    'SIMULATED QR scan of the demo pass.': 'नमुना परिचयपत्रको QR स्क्यान।',
    'SIMULATED': 'नमुना',
    'Reader: ': 'रिडर: ',
    ' · ETA ': ' · अनुमानित समय ',
    ' min · ': ' मिनेट · ',
    'Arriving in ': 'आगमन हुन बाँकी ',
    ' minutes': ' मिनेट',
    'Signed in · ': 'प्रवेश गरिएको · ',
    'Signed in': 'प्रवेश गरिएको',
    'FRESH': 'अद्यावधिक',
    'AGING': 'पुरानो हुँदै',
    'EXPIRED': 'म्याद सकियो',
    'blood_group': 'रक्त समूह',
    'CANDIDATES': 'सम्भावित मिलान',
    'NO MATCH': 'मिलान भेटिएन',
    'AMBIGUOUS': 'एकभन्दा बढी सम्भावित मिलान',
    ' entries': ' विवरणहरू',
    ' records': ' अभिलेखहरू',
    'Recorded allergy: ': 'अभिलेखमा रहेको एलर्जी: ',
    'Recorded blood group ': 'अभिलेखमा रहेको रक्त समूह ',
    ' · verify per transfusion protocol': ' · रगत चढाउने प्रक्रिया अनुसार पुष्टि गर्नुहोस्',
    'Approved summary (': 'स्वीकृत सारांश (',
    ' entries)': ' विवरण)',
    ' (': ' (',
    'Report': 'विवरण',
    'Profile': 'प्रोफाइल',
    'Demo clinician attestation': 'नमुना चिकित्सकको प्रमाणीकरण',
    'PRAN REKHA / ': 'प्राण रेखा / ',
    'PATIENT': 'बिरामी',
    'PARAMEDIC': 'प्यारामेडिक',
    'HOSPITAL': 'अस्पताल',
    'LAB': 'प्रयोगशाला',
    ' · Unit ': ' · एकाइ ',
    ' · revision ': ' · संशोधन ',
    'revision ': 'संशोधन ',
    'started': 'सुरु भयो',
    'status confirmed': 'स्थिति पुष्टि भयो',
    'held': 'रोकियो',
    'resumed': 'पुनः सुरु भयो',
    'stopped': 'बन्द भयो',
    'completed': 'पूरा भयो',
    'dose changed': 'मात्रा परिवर्तन भयो',
    'substituted': 'औषधि प्रतिस्थापन भयो',
    'corrected': 'सच्याइयो',
    'retracted': 'फिर्ता लिइयो',
    'documented active': 'सक्रिय भनेर अभिलेख गरिएको',
    'historical': 'पुरानो अभिलेख',
    'uncertain': 'अनिश्चित',
    'draft': 'मस्यौदा',
    'confirmed': 'पुष्टि भयो',
    'cancelled': 'रद्द भयो',
    'pending': 'प्रतीक्षामा',
    'Preparing the photo…': 'तस्बिर तयार हुँदैछ…',
    'Finding lines of writing…': 'लेखिएका पङ्क्ति खोजिँदैछ…',
    'Downloading the handwriting model ': 'हस्तलेखन मोडेल डाउनलोड हुँदैछ ',
    ' (first time only, about 64 MB)…': ' (पहिलो पटक मात्र, करिब ६४ MB)…',
    'Reading line ': 'पङ्क्ति पढिँदैछ ',
    ' of ': ' मध्ये ',
    ' on this device…': ' यस उपकरणमा…',
    'No text recognized. Add lines manually or retake a sharper, well-lit photo.': 'कुनै पाठ पहिचान भएन। पङ्क्ति हातैले थप्नुहोस् वा राम्रो उज्यालोमा स्पष्ट तस्बिर फेरि खिच्नुहोस्।',
    'OCR engine unavailable. Add lines manually from the image.': 'OCR सेवा उपलब्ध छैन। तस्बिरबाट पङ्क्ति हातैले थप्नुहोस्।',
    'Correct each line and its category against the image.': 'तस्बिरसँग तुलना गरी प्रत्येक पङ्क्ति र वर्ग सच्याउनुहोस्।',
    ' entr': ' विवरण',
    'y signed. Patient approval is required for emergency sharing.': ' मा हस्ताक्षर भयो। आपत्कालीन साझेदारीका लागि बिरामीको स्वीकृति आवश्यक छ।',
    'ies signed. Patient approval is required for emergency sharing.': ' विवरणमा हस्ताक्षर भयो। आपत्कालीन साझेदारीका लागि बिरामीको स्वीकृति आवश्यक छ।',
    'The record changed since you started. Reload and review again.': 'तपाईंले सुरु गरेपछि अभिलेख परिवर्तन भयो। फेरि लोड गरेर समीक्षा गर्नुहोस्।',
    'Signing failed': 'हस्ताक्षर असफल भयो',
    'Remove ': 'हटाउनुहोस् '
};
function translate(value) {
    const exact = ne[value];
    if (exact) return exact;
    const normalized = ne[value.replaceAll('_', ' ')];
    if (normalized) return normalized;
    let match = value.match(/^(\d+) days until review$/);
    if (match) return `${match[1]} दिनपछि पुनरावलोकन`;
    match = value.match(/^Loading the report OCR model (\d+)% \(first time only, about 64 MB\)…$/);
    if (match) return `प्रतिवेदन OCR मोडेल लोड हुँदैछ ${match[1]}% (पहिलो पटक मात्र, करिब ६४ MB)…`;
    match = value.match(/^Reading report line (\d+) of (\d+) on this device…$/);
    if (match) return `यस उपकरणमा प्रतिवेदनको पङ्क्ति ${match[1]} / ${match[2]} पढ्दैछ…`;
    match = value.match(/^Acknowledged by (.+) at (.+)$/);
    if (match) return `${match[1]} ले ${match[2]} मा स्वीकृत गर्नुभयो`;
    match = value.match(/^(\d+) line\(s\) recognized\. Correct each line and its category against the image\.$/);
    if (match) return `${match[1]} पङ्क्ति पहिचान भयो। तस्बिरसँग तुलना गरी प्रत्येक पङ्क्ति र वर्ग सच्याउनुहोस्।`;
    match = value.match(/^Downloading the handwriting model (\d+)% \(first time only, about 64 MB\)…$/);
    if (match) return `हस्तलेखन मोडेल डाउनलोड हुँदैछ ${match[1]}% (पहिलो पटक मात्र, करिब ६४ MB)…`;
    match = value.match(/^Reading line (\d+) of (\d+) on this device…$/);
    if (match) return `यस उपकरणमा ${match[2]} मध्ये ${match[1]} औँ पङ्क्ति पढिँदैछ…`;
    match = value.match(/^Session gallery holds at most (\d+) participants\.$/);
    if (match) return `यस सत्रको तस्बिर सङ्ग्रहमा बढीमा ${match[1]} सहभागी राख्न मिल्छ।`;
    match = value.match(/^(\d+) entr(?:y|ies) signed\. Patient approval is required for emergency sharing\.$/);
    if (match) return `${match[1]} विवरणमा हस्ताक्षर भयो। आपत्कालीन साझेदारीका लागि बिरामीको स्वीकृति आवश्यक छ।`;
    match = value.match(/^(\d+) entries$/);
    if (match) return `${match[1]} विवरण`;
    match = value.match(/^(\d+) records$/);
    if (match) return `${match[1]} अभिलेख`;
    match = value.match(/^(\d+) offline access receipt\(s\) synchronised\.$/);
    if (match) return `${match[1]} अफलाइन पहुँच विवरण समक्रमित भयो।`;
    match = value.match(/^Session enroll \((\d+)\/(\d+)\)$/);
    if (match) return `यस सत्रमा थप्नुहोस् (${match[1]}/${match[2]})`;
    match = value.match(/^Include line: (.*)$/);
    if (match) return `यो पङ्क्ति समावेश गर्नुहोस्: ${match[1]}`;
    match = value.match(/^Remove (.*)$/);
    if (match) return `हटाउनुहोस् ${match[1]}`;
    match = value.match(/^Registered photo of (.*)$/);
    if (match) return `${match[1]} को दर्ता गरिएको तस्बिर`;
    match = value.match(/^Opaque emergency locator QR for (.*)$/);
    if (match) return `${match[1]} का लागि गोप्य आपत्कालीन QR परिचायक`;
    return value;
}
function translateTree(node) {
    if (typeof node === 'string') return translate(node);
    if (Array.isArray(node)) return node.map(translateTree);
    if (!/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isValidElement"])(node)) return node;
    const props = node.props;
    const next = {};
    for (const key of [
        'aria-label',
        'alt',
        'title',
        'placeholder'
    ]){
        if (typeof props[key] === 'string') next[key] = translate(props[key]);
    }
    const children = props.children === undefined ? undefined : translateTree(props.children);
    // Pass children as separate variadic arguments. Putting an array in props.children
    // makes React treat static JSX siblings as a dynamic list and require keys for them.
    if (Array.isArray(children)) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cloneElement"])(node, next, ...children);
    if (children !== undefined) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cloneElement"])(node, next, children);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cloneElement"])(node, next);
}
function Localized({ children }) {
    const language = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePreferences"])((state)=>state.language);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: language === 'ne' ? translateTree(children) : children
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/Localized.tsx",
        lineNumber: 213,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/PhotoCapture.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PhotoCapture",
    ()=>PhotoCapture
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$camera$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Camera$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/camera.js [app-ssr] (ecmascript) <export default as Camera>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/upload.js [app-ssr] (ecmascript) <export default as Upload>");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
function PhotoCapture({ disabled, busy = false, alt, onImage, onError, showPreview = true, facing = 'user' }) {
    const [preview, setPreview] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [camera, setCamera] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const video = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null), stream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null), previewRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])('');
    previewRef.current = preview;
    function stopCamera() {
        stream.current?.getTracks().forEach((t)=>t.stop());
        stream.current = null;
        setCamera(false);
    }
    function setImage(url) {
        if (previewRef.current) URL.revokeObjectURL(previewRef.current);
        setPreview(url);
    }
    // Release camera tracks and preview URLs on unmount and page close.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const onHide = ()=>{
            stopCamera();
            setImage('');
        };
        window.addEventListener('pagehide', onHide);
        return ()=>{
            window.removeEventListener('pagehide', onHide);
            stream.current?.getTracks().forEach((t)=>t.stop());
            if (previewRef.current) URL.revokeObjectURL(previewRef.current);
        };
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (disabled) stopCamera();
    }, [
        disabled
    ]);
    async function onFile(file) {
        if (!file) return;
        const url = URL.createObjectURL(file);
        setImage(url);
        const img = new Image();
        img.src = url;
        try {
            await img.decode();
        } catch  {
            onError('Image could not be read.');
            return;
        }
        await onImage(img);
    }
    async function startCamera() {
        try {
            stream.current = await navigator.mediaDevices.getUserMedia({
                video: {
                    facingMode: facing
                }
            });
            setCamera(true);
            if (video.current) {
                video.current.srcObject = stream.current;
                await video.current.play();
            }
        } catch  {
            onError('Camera unavailable or permission denied. Upload an image instead.');
            stopCamera();
        }
    }
    async function capture() {
        const v = video.current;
        if (!v || !v.videoWidth) return;
        const canvas = document.createElement('canvas');
        canvas.width = v.videoWidth;
        canvas.height = v.videoHeight;
        canvas.getContext('2d').drawImage(v, 0, 0);
        const blob = await new Promise((r)=>canvas.toBlob(r, 'image/jpeg', 0.9));
        if (blob) setImage(URL.createObjectURL(blob));
        stopCamera();
        await onImage(canvas);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "face-inputs",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "file-button",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$upload$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Upload$3e$__["Upload"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                                    lineNumber: 50,
                                    columnNumber: 38
                                }, this),
                                " Upload image",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "file",
                                    accept: "image/*",
                                    capture: facing,
                                    disabled: disabled || busy,
                                    onChange: (e)=>{
                                        void onFile(e.target.files?.[0]);
                                        e.target.value = '';
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                                    lineNumber: 50,
                                    columnNumber: 70
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                            lineNumber: 50,
                            columnNumber: 7
                        }, this),
                        !camera ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            disabled: disabled || busy,
                            onClick: ()=>void startCamera(),
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$camera$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Camera$3e$__["Camera"], {
                                    size: 16
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                                    lineNumber: 51,
                                    columnNumber: 97
                                }, this),
                                " Use camera"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                            lineNumber: 51,
                            columnNumber: 16
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    className: "primary",
                                    disabled: busy,
                                    onClick: ()=>void capture(),
                                    children: "Capture"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                                    lineNumber: 52,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: stopCamera,
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                                    lineNumber: 52,
                                    columnNumber: 115
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                            lineNumber: 52,
                            columnNumber: 10
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                    lineNumber: 49,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "face-stage",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("video", {
                            ref: video,
                            className: "face-preview",
                            playsInline: true,
                            muted: true,
                            hidden: !camera
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                            lineNumber: 55,
                            columnNumber: 7
                        }, this),
                        !camera && showPreview && preview && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            className: "face-preview",
                            src: preview,
                            alt: alt
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                            lineNumber: 56,
                            columnNumber: 39
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
                    lineNumber: 54,
                    columnNumber: 5
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
            lineNumber: 48,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/PhotoCapture.tsx",
        lineNumber: 48,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/Portal.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Portal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/shield-check.js [app-ssr] (ecmascript) <export default as ShieldCheck>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radio$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/radio.js [app-ssr] (ecmascript) <export default as Radio>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hospital$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Hospital$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/hospital.js [app-ssr] (ecmascript) <export default as Hospital>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/flask-conical.js [app-ssr] (ecmascript) <export default as FlaskConical>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/user-round.js [app-ssr] (ecmascript) <export default as UserRound>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/log-out.js [app-ssr] (ecmascript) <export default as LogOut>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/triangle-alert.js [app-ssr] (ecmascript) <export default as TriangleAlert>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell.js [app-ssr] (ecmascript) <export default as Bell>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$off$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BellOff$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bell-off.js [app-ssr] (ecmascript) <export default as BellOff>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$qr$2d$code$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__QrCode$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/qr-code.js [app-ssr] (ecmascript) <export default as QrCode>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$moon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Moon$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/moon.js [app-ssr] (ecmascript) <export default as Moon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sun$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sun$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/sun.js [app-ssr] (ecmascript) <export default as Sun>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-dialog/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$qrcode$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/qrcode/lib/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$offline$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/offline.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Workflows$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Workflows.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$FaceLookup$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/FaceLookup.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$RegisterPatient$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/RegisterPatient.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$EnrollFace$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/EnrollFace.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$HandwrittenUpdate$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/HandwrittenUpdate.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
const routes = [
    [
        'patient',
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$round$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserRound$3e$__["UserRound"]
    ],
    [
        'paramedic',
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radio$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__["Radio"]
    ],
    [
        'hospital',
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$hospital$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Hospital$3e$__["Hospital"]
    ],
    [
        'lab',
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$flask$2d$conical$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__FlaskConical$3e$__["FlaskConical"]
    ]
];
const demoLocator = 'demo-opaque-93e74fd4-54c5-45cf-9760-54d64f20e347';
const traumaCategories = [
    'Unconscious polytrauma',
    'Road traffic collision',
    'Cardiac event',
    'Respiratory distress',
    'Burns',
    'Fall from height',
    'Other'
];
const signableKinds = [
    'vital',
    'medication',
    'allergy',
    'condition',
    'implant',
    'blood_group'
];
const statusColumns = [
    'EN_ROUTE',
    'ARRIVED',
    'RESOLVED'
];
// Short opt-in tone; never plays unless the hospital user enabled sound.
function chime() {
    const audio = new AudioContext(), osc = audio.createOscillator(), gain = audio.createGain();
    osc.frequency.value = 880;
    gain.gain.setValueAtTime(0.15, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.6);
    osc.connect(gain).connect(audio.destination);
    osc.start();
    osc.stop(audio.currentTime + 0.6);
    osc.onended = ()=>void audio.close();
}
function Portal({ portal }) {
    const { language, setLanguage, theme, setTheme } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["usePreferences"])();
    const t = __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["labels"][language];
    const [session, setSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [context, setContext] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [profile, setProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [username, setUsername] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : portal === 'patient' ? 'siddharth' : portal);
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : 'pran-demo-' + (portal === 'patient' ? 'siddharth' : portal));
    const [allowed, setAllowed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]), [receipts, setReceipts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [alerts, setAlerts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]), [ledger, setLedger] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [locator, setLocator] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [link, setLink] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [purpose, setPurpose] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('Pre-arrival emergency record review');
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(traumaCategories[0]);
    const [confirmed, setConfirmed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [eta, setEta] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(12), [card, setCard] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [grantId, setGrantId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [qr, setQr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [phrase, setPhrase] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [offlineCard, setOfflineCard] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [report, setReport] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [source, setSource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [signKind, setSignKind] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('vital'), [clinicalText, setClinicalText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('Blood pressure 118/78 mmHg'), [signSource, setSignSource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('Demo clinician attestation');
    const [face, setFace] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [faceConsent, setFaceConsent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [registered, setRegistered] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [sound, setSound] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [fresh, setFresh] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const seenAlerts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null), soundRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    soundRef.current = sound;
    async function refresh() {
        const c = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/context');
        setContext(c);
        // Patients see their own bound record; the lab sees its assigned one.
        const pid = c.patients[0]?.id;
        if (pid) {
            const p = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + pid);
            setProfile(p);
            setAllowed(p.release.allowedEntryIds);
            if (c.staff.role === 'patient') setReceipts(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + pid + '/receipts'));
        }
        if (c.staff.facility === 'hospital-demo') {
            const next = (await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/alerts/read', {})).filter((a)=>!a.unavailable);
            // First load seeds the seen set; later arrivals pulse and optionally chime.
            const added = seenAlerts.current ? next.filter((a)=>!seenAlerts.current.has(a.id)).map((a)=>a.id) : [];
            seenAlerts.current = new Set(next.map((a)=>a.id));
            setAlerts(next);
            if (added.length) {
                setFresh(added);
                setTimeout(()=>setFresh([]), 4000);
                if (soundRef.current) chime();
            }
        }
        if (c.staff.facility === 'lab-demo') setLedger(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/ledger'));
    }
    async function run(action) {
        setBusy(true);
        setError('');
        setMessage('');
        try {
            await action();
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Request failed');
        } finally{
            setBusy(false);
        }
    }
    async function flushOfflineReceipts() {
        const synced = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$offline$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["syncReceipts"])((body)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/offline/receipts', body));
        if (synced) setMessage(synced + ' offline access receipt(s) synchronised.');
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const saved = localStorage.getItem('pran-language');
        if (saved === 'ne') setLanguage('ne');
        if (document.documentElement.dataset.theme === 'dark') setTheme('dark', false);
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('session').then((s)=>{
            setSession(s);
            return refresh();
        }).catch(()=>{});
        if ('serviceWorker' in navigator) void navigator.serviceWorker.register('/sw.js').catch(()=>{});
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!profile) return;
        void __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$qrcode$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].toDataURL(profile.locator, {
            width: 180,
            margin: 1
        }).then(setQr);
    }, [
        profile?.locator
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!session || portal !== 'hospital') return;
        const stream = new EventSource('/api/platform/events');
        stream.addEventListener('refresh', ()=>{
            void refresh().catch((e)=>setError(String(e)));
        });
        // Same-browser fallback: carries only an opaque id; data is refetched through audited endpoints.
        const channel = new BroadcastChannel('pran-events');
        channel.onmessage = ()=>{
            void refresh().catch(()=>{});
        };
        return ()=>{
            stream.close();
            channel.close();
        };
    }, [
        session,
        portal
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!session || portal !== 'patient') return;
        const online = ()=>{
            void flushOfflineReceipts().catch(()=>{});
        };
        online();
        window.addEventListener('online', online);
        return ()=>window.removeEventListener('online', online);
    }, [
        session,
        portal
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!card && !offlineCard) return;
        const expiry = Math.min(Date.parse((card ?? offlineCard).expiresAt), Date.now() + 600000);
        const timer = setTimeout(()=>{
            setCard(null);
            setOfflineCard(null);
            setSource(null);
            setGrantId('');
            setMessage('Session expired. Unlock again.');
        }, Math.max(0, expiry - Date.now()));
        return ()=>clearTimeout(timer);
    }, [
        card,
        offlineCard
    ]);
    async function login() {
        const s = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('session', {
            username,
            password
        });
        setSession(s);
        await refresh();
    }
    async function signOut() {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('session', undefined, 'DELETE');
        setSession(null);
        setContext(null);
        setProfile(null);
        setAlerts([]);
        setCard(null);
        setOfflineCard(null);
        setFace(false);
        setFaceConsent(false);
        setSource(null);
        setLink(null);
        setGrantId('');
        setRegistered([]);
        seenAlerts.current = null;
    }
    async function resolveLocator(value) {
        setLink(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/linkage', {
            locator: value
        }));
        setConfirmed(false);
        setCard(null);
        setGrantId('');
    }
    const isAllowed = session && context && (portal === 'patient' ? context.staff.role === 'patient' : portal === 'paramedic' ? context.staff.role === 'paramedic' : portal === 'lab' ? context.staff.facility === 'lab-demo' : context.staff.facility === 'hospital-demo');
    const daysLeft = profile ? Math.ceil((Date.parse(profile.reviewDue) - Date.now()) / 86400000) : 0;
    const renderEntries = (entries)=>entries.map((entry)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                className: 'entry' + (entry.kind === 'allergy' ? ' warning' : ''),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "eyebrow",
                        children: entry.kind.replace('_', ' ')
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 110,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        children: [
                            entry.kind === 'allergy' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__["TriangleAlert"], {
                                size: 18,
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 111,
                                columnNumber: 34
                            }, this),
                            " ",
                            entry.text
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 111,
                        columnNumber: 5
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        children: entry.date
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 112,
                        columnNumber: 5
                    }, this),
                    entry.reviewed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "verified",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {
                                size: 14,
                                "aria-hidden": true
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 114,
                                columnNumber: 32
                            }, this),
                            " Signed demo record · ",
                            entry.source
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 114,
                        columnNumber: 8
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "unverified",
                        children: "Patient report · not clinically verified"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 115,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>setSource(entry),
                        children: t.source
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 116,
                        columnNumber: 5
                    }, this),
                    entry.kind === 'blood_group' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "caution",
                        children: "Historical recorded blood group. Follow the treating service's verification and compatibility procedures."
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 117,
                        columnNumber: 34
                    }, this)
                ]
            }, entry.id, true, {
                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                lineNumber: 109,
                columnNumber: 61
            }, this));
    const warnings = (c)=>c.entries.filter((e)=>e.kind === 'allergy').map((e)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "allergy-banner",
                role: "alert",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$triangle$2d$alert$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__TriangleAlert$3e$__["TriangleAlert"], {
                        "aria-hidden": true
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 120,
                        columnNumber: 129
                    }, this),
                    " Recorded allergy: ",
                    e.text,
                    ". Review the attributed source; this is not a treatment instruction."
                ]
            }, e.id, true, {
                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                lineNumber: 120,
                columnNumber: 75
            }, this));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "platform",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "portal-header",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        href: "/patient",
                        className: "logo",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: "/brand/pranrekha-logo.png",
                            alt: "Pran Rekha",
                            width: 960,
                            height: 198
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                            lineNumber: 123,
                            columnNumber: 78
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 123,
                        columnNumber: 39
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "pill",
                        children: t.synthetic
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 123,
                        columnNumber: 165
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "header-right",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                "aria-pressed": theme === 'dark',
                                "aria-label": theme === 'dark' ? t.toLight : t.toDark,
                                onClick: ()=>setTheme(theme === 'dark' ? 'light' : 'dark'),
                                children: [
                                    theme === 'dark' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$sun$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Sun$3e$__["Sun"], {
                                        size: 16
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 124,
                                        columnNumber: 192
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$moon$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Moon$3e$__["Moon"], {
                                        size: 16
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 124,
                                        columnNumber: 209
                                    }, this),
                                    theme === 'dark' ? t.light : t.dark
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 124,
                                columnNumber: 37
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setLanguage(language === 'en' ? 'ne' : 'en'),
                                children: language === 'en' ? 'नेपाली' : 'English'
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 124,
                                columnNumber: 267
                            }, this),
                            session && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>void run(signOut),
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$log$2d$out$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__LogOut$3e$__["LogOut"], {
                                        size: 16
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 124,
                                        columnNumber: 423
                                    }, this),
                                    t.signOut
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 124,
                                columnNumber: 383
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 124,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                lineNumber: 123,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: "portal-nav",
                children: routes.map(([name, Icon])=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        "aria-current": portal === name ? 'page' : undefined,
                        href: '/' + name,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                size: 18
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 126,
                                columnNumber: 139
                            }, this),
                            t[name]
                        ]
                    }, name, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 126,
                        columnNumber: 60
                    }, this))
            }, void 0, false, {
                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                lineNumber: 126,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "portal-main",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "portal-title",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "eyebrow",
                                        children: [
                                            "PRAN REKHA / ",
                                            portal.toUpperCase()
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 128,
                                        columnNumber: 42
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        children: t[portal]
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 128,
                                        columnNumber: 110
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 128,
                                columnNumber: 37
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "pill",
                                children: [
                                    "● ",
                                    session ? 'Session active' : 'Session required'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 128,
                                columnNumber: 136
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 128,
                        columnNumber: 7
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        role: "alert",
                        className: "notice error",
                        children: error
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 129,
                        columnNumber: 15
                    }, this),
                    message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        role: "status",
                        className: "notice",
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 129,
                        columnNumber: 78
                    }, this),
                    !session ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "surface login-panel",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                children: t.signIn
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 131,
                                columnNumber: 58
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                onSubmit: (e)=>{
                                    e.preventDefault();
                                    void run(login);
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: [
                                            t.name,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                value: username,
                                                onChange: (e)=>setUsername(e.target.value),
                                                autoComplete: "username"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 132,
                                                columnNumber: 24
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 132,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        children: [
                                            t.password,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "password",
                                                value: password,
                                                onChange: (e)=>setPassword(e.target.value),
                                                autoComplete: "current-password"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 133,
                                                columnNumber: 28
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 133,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "primary",
                                        disabled: busy,
                                        children: t.signIn
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 134,
                                        columnNumber: 9
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 131,
                                columnNumber: 77
                            }, this),
                            ("TURBOPACK compile-time value", "development") !== 'production' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "login-hint",
                                children: "Demo accounts: siddharth, paramedic, hospital and lab. Password: pran-demo- followed by username."
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 134,
                                columnNumber: 117
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 131,
                        columnNumber: 17
                    }, this) : !isAllowed ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "surface",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                children: "This account has no access to this portal."
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 135,
                                columnNumber: 48
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: "Sign out and authenticate with the provisioned account for this role."
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 135,
                                columnNumber: 99
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 135,
                        columnNumber: 19
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            portal === 'patient' && profile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "portal-grid",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface pass",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "eyebrow",
                                                        children: "Your emergency pass"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 48
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        children: profile.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 100
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "pass-id",
                                                        children: profile.id
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 138,
                                                        columnNumber: 123
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                        className: "pass-blood",
                                                        children: profile.entries.find((e)=>e.kind === 'blood_group')?.text
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 11
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "Historical recorded blood group · verification required"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 139,
                                                        columnNumber: 106
                                                    }, this),
                                                    profile.entries.find((e)=>e.kind === 'donor') && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: profile.entries.find((e)=>e.kind === 'donor').text
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 140,
                                                        columnNumber: 55
                                                    }, this),
                                                    profile.demo && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        role: "note",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                            children: "FICTIONAL DEMO: date of birth and medical details are generated samples, not verified medical history."
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                            lineNumber: 141,
                                                            columnNumber: 41
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 141,
                                                        columnNumber: 26
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: [
                                                            "Date of birth: ",
                                                            profile.dob
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 142,
                                                        columnNumber: 11
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 138,
                                                columnNumber: 43
                                            }, this),
                                            qr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                                src: qr,
                                                width: 180,
                                                height: 180,
                                                alt: "Opaque emergency locator QR"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 142,
                                                columnNumber: 57
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 138,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: 'surface freshness ' + profile.freshness.toLowerCase(),
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "eyebrow",
                                                children: t.review
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 143,
                                                columnNumber: 83
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "radar",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "dot",
                                                        "aria-hidden": true
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 144,
                                                        columnNumber: 34
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        children: profile.freshness
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 144,
                                                        columnNumber: 69
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 144,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    daysLeft > 0 ? daysLeft + ' days until review' : 'Review overdue',
                                                    " · ",
                                                    new Date(profile.reviewDue).toLocaleDateString(language === 'ne' ? 'ne-NP' : 'en-GB')
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 145,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Review schedule; current health and medication use require separate assessment."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 146,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "offer",
                                                children: "$50 checkup · 15% Pran Rekha partner discount → $42.50 (simulated)"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 147,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "primary",
                                                onClick: ()=>void run(async ()=>{
                                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + profile.id + '/book', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            date: new Date().toISOString().slice(0, 10)
                                                        });
                                                        setMessage('Simulated appointment booked for $42.50. No payment was taken.');
                                                    }),
                                                children: t.booking
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 148,
                                                columnNumber: 11
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 143,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                        className: "surface wide disclosure",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: t.records
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 149,
                                                        columnNumber: 63
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "disclosure-meta",
                                                        children: [
                                                            profile.entries.length,
                                                            " entries"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 149,
                                                        columnNumber: 87
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 149,
                                                columnNumber: 54
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "entries",
                                                children: renderEntries(profile.entries)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 149,
                                                columnNumber: 170
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 149,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: t.release
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 150,
                                                columnNumber: 38
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Select each entry and its excerpt for emergency sharing."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 150,
                                                columnNumber: 58
                                            }, this),
                                            profile.entries.map((e)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    className: "check",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                            type: "checkbox",
                                                            checked: allowed.includes(e.id),
                                                            onChange: (event)=>setAllowed(event.target.checked ? [
                                                                    ...allowed,
                                                                    e.id
                                                                ] : allowed.filter((id)=>id !== e.id))
                                                        }, void 0, false, {
                                                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                            lineNumber: 150,
                                                            columnNumber: 181
                                                        }, this),
                                                        e.text
                                                    ]
                                                }, e.id, true, {
                                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                    lineNumber: 150,
                                                    columnNumber: 145
                                                }, this)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "primary",
                                                onClick: ()=>void run(async ()=>{
                                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + profile.id + '/release', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            expectedRevision: profile.revision,
                                                            allowedEntryIds: allowed
                                                        });
                                                        await refresh();
                                                        setMessage('Emergency release updated.');
                                                    }),
                                                children: t.save
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 151,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>void run(async ()=>{
                                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + profile.id + '/revoke', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            expectedRevision: profile.revision
                                                        });
                                                        await refresh();
                                                    }),
                                                children: t.revoke
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 152,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    profile.release.revoked ? 'Revoked' : 'Active',
                                                    " · revision ",
                                                    profile.release.revision
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 153,
                                                columnNumber: 11
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 150,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                        className: "surface disclosure",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: t.report
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 154,
                                                        columnNumber: 58
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "disclosure-meta",
                                                        children: "Add a personal note"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 154,
                                                        columnNumber: 81
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 154,
                                                columnNumber: 49
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    "Your note",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        value: report,
                                                        onChange: (e)=>setReport(e.target.value),
                                                        "aria-label": "Patient report"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 154,
                                                        columnNumber: 167
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 154,
                                                columnNumber: 151
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                disabled: !report.trim(),
                                                onClick: ()=>void run(async ()=>{
                                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + profile.id + '/reports', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            expectedRevision: profile.revision,
                                                            text: report,
                                                            date: new Date().toISOString().slice(0, 10)
                                                        });
                                                        setReport('');
                                                        await refresh();
                                                    }),
                                                children: t.report
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 154,
                                                columnNumber: 269
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Attributed to you; this does not change a clinician-signed record."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 154,
                                                columnNumber: 554
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 154,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                        className: "surface wide disclosure",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: t.receipts
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 155,
                                                        columnNumber: 63
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "disclosure-meta",
                                                        children: [
                                                            receipts.length,
                                                            " records"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 155,
                                                        columnNumber: 88
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 155,
                                                columnNumber: 54
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>void run(refresh),
                                                children: t.refresh
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 155,
                                                columnNumber: 164
                                            }, this),
                                            receipts.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "receipts",
                                                children: receipts.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: [
                                                            String(r.at),
                                                            " · ",
                                                            String(r.actorId),
                                                            " · ",
                                                            String(r.purpose)
                                                        ]
                                                    }, String(r.id), true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 155,
                                                        columnNumber: 283
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 155,
                                                columnNumber: 241
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "No access receipts yet."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 155,
                                                columnNumber: 377
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 155,
                                        columnNumber: 9
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 137,
                                columnNumber: 37
                            }, this),
                            portal === 'lab' && profile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "portal-grid",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "eyebrow",
                                                children: [
                                                    "Signed in · ",
                                                    context?.staff.facility
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 159,
                                                columnNumber: 38
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$shield$2d$check$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__ShieldCheck$3e$__["ShieldCheck"], {}, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 159,
                                                        columnNumber: 112
                                                    }, this),
                                                    " ",
                                                    t.sign
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 159,
                                                columnNumber: 108
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    profile.name,
                                                    " · ",
                                                    profile.id,
                                                    " · revision ",
                                                    profile.revision
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 159,
                                                columnNumber: 140
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    "Record type",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        value: signKind,
                                                        onChange: (e)=>setSignKind(e.target.value),
                                                        children: signableKinds.map((k)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                value: k,
                                                                children: k.replace('_', ' ')
                                                            }, k, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 160,
                                                                columnNumber: 135
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 160,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 160,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    "Verbatim observation, result or medication",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        value: clinicalText,
                                                        onChange: (e)=>setClinicalText(e.target.value)
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 161,
                                                        columnNumber: 60
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 161,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    "Source",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        value: signSource,
                                                        onChange: (e)=>setSignSource(e.target.value)
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 162,
                                                        columnNumber: 24
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 162,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "primary",
                                                disabled: !clinicalText.trim() || !signSource.trim(),
                                                onClick: ()=>void run(async ()=>{
                                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + profile.id + '/sign', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            expectedRevision: profile.revision,
                                                            entries: [
                                                                {
                                                                    kind: signKind,
                                                                    text: clinicalText,
                                                                    excerpt: clinicalText,
                                                                    date: new Date().toISOString().slice(0, 10),
                                                                    source: signSource
                                                                }
                                                            ]
                                                        });
                                                        await refresh();
                                                        setMessage('Signed version committed. Patient approval is required for emergency sharing.');
                                                    }),
                                                children: "Sign & commit to Pran Rekha"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 163,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Ed25519 demo signature · integrity verified on every read. Demonstrates record integrity, not accreditation."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 164,
                                                columnNumber: 11
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 159,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: "Simulated revenue ledger"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 165,
                                                columnNumber: 38
                                            }, this),
                                            ledger.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "receipts",
                                                children: ledger.map((l)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: [
                                                            "Checkup $",
                                                            (Number(l.amountMinor) / 100).toFixed(2),
                                                            " · take-rate (8%) $",
                                                            (Number(l.commissionMinor) / 100).toFixed(2)
                                                        ]
                                                    }, String(l.id), true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 165,
                                                        columnNumber: 126
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 165,
                                                columnNumber: 86
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "No checkups signed yet."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 165,
                                                columnNumber: 274
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: [
                                                        "Total commission: $",
                                                        (ledger.reduce((sum, l)=>sum + Number(l.commissionMinor), 0) / 100).toFixed(2)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                    lineNumber: 166,
                                                    columnNumber: 14
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 166,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Illustrative only. No payments are processed."
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 166,
                                                columnNumber: 128
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 165,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                        className: "surface wide disclosure",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Record history and entries"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 167,
                                                        columnNumber: 63
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "disclosure-meta",
                                                        children: [
                                                            profile.versions.length,
                                                            " signed versions · ",
                                                            profile.entries.length,
                                                            " entries"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 167,
                                                        columnNumber: 102
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 167,
                                                columnNumber: 54
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "receipts",
                                                children: profile.versions.map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        children: [
                                                            "Version ",
                                                            v.revision,
                                                            " · ",
                                                            v.signer,
                                                            " · ",
                                                            v.signedAt,
                                                            " · review due ",
                                                            v.reviewDue.slice(0, 10)
                                                        ]
                                                    }, v.id, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 167,
                                                        columnNumber: 279
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 167,
                                                columnNumber: 229
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "entries",
                                                children: renderEntries(profile.entries)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 167,
                                                columnNumber: 393
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 167,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                        className: "surface wide disclosure",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: "Medication and document tools"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 63
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "disclosure-meta",
                                                        children: "Review or add source evidence"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 168,
                                                        columnNumber: 105
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 168,
                                                columnNumber: 54
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Workflows$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RecordWorkflows"], {
                                                patientId: profile.id,
                                                revision: profile.revision,
                                                onChange: refresh,
                                                clinician: true
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 168,
                                                columnNumber: 185
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 168,
                                        columnNumber: 9
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 158,
                                columnNumber: 33
                            }, this),
                            portal === 'paramedic' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "portal-grid",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "scanner",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$radio$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Radio$3e$__["Radio"], {
                                                        size: 64
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 172,
                                                        columnNumber: 63
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "RFID scanner"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 172,
                                                        columnNumber: 81
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        children: [
                                                            "Paired reader: ",
                                                            context?.staff.reader,
                                                            " · Unit ",
                                                            context?.staff.unit
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 172,
                                                        columnNumber: 100
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 172,
                                                columnNumber: 38
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "primary",
                                                onClick: ()=>void run(async ()=>{
                                                        setLink(null);
                                                        setCard(null);
                                                        setGrantId('');
                                                        setConfirmed(false);
                                                        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/rfid/pending');
                                                        if (result.state === 'CANDIDATE') {
                                                            setLink({
                                                                patientId: result.patientId,
                                                                linkageId: result.linkageId
                                                            });
                                                            setMessage('Card found. Confirm access below to show the summary on the scanner LCD.');
                                                        } else setMessage('Reader: ' + result.state);
                                                    }),
                                                children: t.scan
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 173,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                                className: "lookup-options",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                        children: "Other ways to find a record"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 174,
                                                        columnNumber: 47
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>void run(async ()=>{
                                                                setLocator(demoLocator);
                                                                await resolveLocator(demoLocator);
                                                                setMessage('SIMULATED QR scan of the demo pass.');
                                                            }),
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$qr$2d$code$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__QrCode$3e$__["QrCode"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 174,
                                                                columnNumber: 245
                                                            }, this),
                                                            " Simulate QR scan"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 174,
                                                        columnNumber: 93
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        children: [
                                                            "QR / manual locator",
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                value: locator,
                                                                onChange: (e)=>setLocator(e.target.value)
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 175,
                                                                columnNumber: 39
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 175,
                                                        columnNumber: 13
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        disabled: !locator,
                                                        onClick: ()=>void run(()=>resolveLocator(locator)),
                                                        children: t.manual
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 175,
                                                        columnNumber: 112
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                        className: "check",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                type: "checkbox",
                                                                checked: faceConsent,
                                                                onChange: (e)=>{
                                                                    setFaceConsent(e.target.checked);
                                                                    setFace(false);
                                                                }
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 176,
                                                                columnNumber: 38
                                                            }, this),
                                                            "Consent to session-only face candidate simulation"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 176,
                                                        columnNumber: 13
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        disabled: !faceConsent,
                                                        onClick: ()=>setFace(true),
                                                        children: "Simulate face candidate"
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 176,
                                                        columnNumber: 206
                                                    }, this),
                                                    face && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: "SIMULATED possible local candidate. Record remains locked. No image captured."
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 176,
                                                        columnNumber: 305
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 174,
                                                columnNumber: 11
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 172,
                                        columnNumber: 9
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: "Pre-arrival access"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 179,
                                                columnNumber: 38
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: link ? 'Candidate ' + link.patientId : 'Awaiting locator'
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 179,
                                                columnNumber: 65
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    "Trauma category",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                        value: category,
                                                        onChange: (e)=>setCategory(e.target.value),
                                                        children: traumaCategories.map((c)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: c
                                                            }, c, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 180,
                                                                columnNumber: 125
                                                            }, this))
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 180,
                                                        columnNumber: 33
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 180,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    t.purpose,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                                        value: purpose,
                                                        onChange: (e)=>setPurpose(e.target.value)
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 181,
                                                        columnNumber: 29
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 181,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "check",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "checkbox",
                                                        checked: confirmed,
                                                        onChange: (e)=>setConfirmed(e.target.checked)
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 182,
                                                        columnNumber: 36
                                                    }, this),
                                                    t.confirm
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 182,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                disabled: !confirmed || !link,
                                                className: "primary",
                                                onClick: ()=>void run(async ()=>{
                                                        const g = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/grants', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            ...link,
                                                            purpose: category + ': ' + purpose,
                                                            deviceId: 'staff-browser',
                                                            confirmed: true
                                                        });
                                                        setGrantId(g.id);
                                                        setCard(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/cards', {
                                                            grantId: g.id
                                                        }));
                                                    }),
                                                children: "Open approved emergency summary"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 183,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                children: [
                                                    "Arriving in ",
                                                    eta,
                                                    " minutes",
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "range",
                                                        min: 0,
                                                        max: 120,
                                                        value: eta,
                                                        onChange: (e)=>setEta(Number(e.target.value))
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 184,
                                                        columnNumber: 43
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 184,
                                                columnNumber: 11
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: "Destination: Pran Rekha Demonstration Hospital"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 184,
                                                columnNumber: 147
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                className: "dispatch",
                                                disabled: !grantId,
                                                onClick: ()=>void run(async ()=>{
                                                        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/dispatch', {
                                                            requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                            grantId,
                                                            destination: 'hospital-demo',
                                                            etaMinutes: eta
                                                        });
                                                        const channel = new BroadcastChannel('pran-events');
                                                        channel.postMessage({
                                                            id: result.id
                                                        });
                                                        channel.close();
                                                        setMessage('Dispatch committed. The destination hospital can now read its approved scope.');
                                                    }),
                                                children: "Initiate pre-arrival ER stream"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 185,
                                                columnNumber: 11
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 179,
                                        columnNumber: 9
                                    }, this),
                                    card && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                        className: "surface wide",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: card.name
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 187,
                                                columnNumber: 50
                                            }, this),
                                            warnings(card),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: card.notice
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 187,
                                                columnNumber: 86
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "entries",
                                                children: renderEntries(card.entries)
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 187,
                                                columnNumber: 106
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 187,
                                        columnNumber: 16
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 171,
                                columnNumber: 30
                            }, this),
                            portal === 'hospital' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                className: "surface board",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "board-heading",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                children: "Incoming patients"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 191,
                                                columnNumber: 40
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "header-right",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        "aria-pressed": sound,
                                                        onClick: ()=>setSound(!sound),
                                                        children: [
                                                            sound ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__Bell$3e$__["Bell"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 192,
                                                                columnNumber: 78
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bell$2d$off$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__BellOff$3e$__["BellOff"], {
                                                                size: 16
                                                            }, void 0, false, {
                                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                lineNumber: 192,
                                                                columnNumber: 96
                                                            }, this),
                                                            " ",
                                                            sound ? 'Sound on' : 'Sound off'
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 192,
                                                        columnNumber: 11
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>void run(refresh),
                                                        children: t.refresh
                                                    }, void 0, false, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 193,
                                                        columnNumber: 11
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 191,
                                                columnNumber: 66
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 191,
                                        columnNumber: 9
                                    }, this),
                                    !alerts.length && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "No active authorized dispatches."
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 194,
                                        columnNumber: 26
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "kanban",
                                        children: statusColumns.map((status)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "column",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        children: [
                                                            status.replace('_', ' '),
                                                            " (",
                                                            alerts.filter((a)=>a.status === status).length,
                                                            ")"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                        lineNumber: 195,
                                                        columnNumber: 97
                                                    }, this),
                                                    alerts.filter((a)=>a.status === status).map((a)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                                            className: 'entry alert' + (fresh.includes(a.id) ? ' pulse' : ''),
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                                    children: a.card.name
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                    lineNumber: 197,
                                                                    columnNumber: 13
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "eta",
                                                                    children: [
                                                                        a.unit,
                                                                        " · ETA ",
                                                                        a.etaMinutes,
                                                                        " min · ",
                                                                        new Date(a.timestamp).toLocaleTimeString()
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                    lineNumber: 198,
                                                                    columnNumber: 13
                                                                }, this),
                                                                a.card.entries.filter((e)=>e.kind === 'blood_group').map((e)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "blood",
                                                                        children: [
                                                                            "Recorded blood group ",
                                                                            e.text,
                                                                            " · verify per transfusion protocol"
                                                                        ]
                                                                    }, e.id, true, {
                                                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                        lineNumber: 199,
                                                                        columnNumber: 70
                                                                    }, this)),
                                                                warnings(a.card),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                                                            children: [
                                                                                "Approved summary (",
                                                                                a.card.entries.length,
                                                                                " entries)"
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                            lineNumber: 201,
                                                                            columnNumber: 22
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                            children: a.card.notice
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                            lineNumber: 201,
                                                                            columnNumber: 91
                                                                        }, this),
                                                                        renderEntries(a.card.entries)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                    lineNumber: 201,
                                                                    columnNumber: 13
                                                                }, this),
                                                                a.status !== 'RESOLVED' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    className: "primary",
                                                                    onClick: ()=>void run(async ()=>{
                                                                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/alerts/' + a.id + '/status', {
                                                                                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                                                expectedRevision: a.revision,
                                                                                status: a.status === 'EN_ROUTE' ? 'ARRIVED' : 'RESOLVED'
                                                                            });
                                                                            await refresh();
                                                                        }),
                                                                    children: a.status === 'EN_ROUTE' ? 'Mark arrived' : 'Resolve'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                                    lineNumber: 202,
                                                                    columnNumber: 37
                                                                }, this)
                                                            ]
                                                        }, a.id, true, {
                                                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                            lineNumber: 196,
                                                            columnNumber: 55
                                                        }, this))
                                                ]
                                            }, status, true, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 195,
                                                columnNumber: 60
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 195,
                                        columnNumber: 9
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 190,
                                columnNumber: 29
                            }, this),
                            portal === 'hospital' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                                className: "surface wide disclosure",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Patient and document tools"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 205,
                                                columnNumber: 83
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "disclosure-meta",
                                                children: "Registration · records · face lookup"
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 205,
                                                columnNumber: 122
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 205,
                                        columnNumber: 74
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "tool-stack",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$RegisterPatient$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RegisterPatient"], {
                                                onRegistered: (p)=>{
                                                    setRegistered((r)=>[
                                                            ...r,
                                                            p
                                                        ]);
                                                    void refresh().catch(()=>{});
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 206,
                                                columnNumber: 9
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$EnrollFace$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["EnrollFace"], {
                                                patients: context?.patients ?? []
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 207,
                                                columnNumber: 9
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$HandwrittenUpdate$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HandwrittenUpdate"], {
                                                patients: context?.patients ?? [],
                                                onChange: refresh
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 208,
                                                columnNumber: 9
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$FaceLookup$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaceLookup"], {
                                                patients: registered
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                                lineNumber: 209,
                                                columnNumber: 9
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 205,
                                        columnNumber: 209
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 205,
                                columnNumber: 29
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 135,
                        columnNumber: 186
                    }, this),
                    portal === 'patient' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "surface wide disclosure offline-panel",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Prepared offline viewer"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 213,
                                        columnNumber: 96
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "disclosure-meta",
                                        children: "Unlock or prepare this device"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 213,
                                        columnNumber: 132
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 213,
                                columnNumber: 87
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                children: [
                                    "Unlock phrase (12+ characters)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "password",
                                        value: phrase,
                                        onChange: (e)=>setPhrase(e.target.value)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 213,
                                        columnNumber: 249
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 213,
                                columnNumber: 212
                            }, this),
                            session && profile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>void run(async ()=>{
                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$offline$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["prepareBrowserShell"])();
                                        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$offline$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["prepare"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + profile.id + '/snapshot', {
                                            deviceId: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$offline$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["browserDeviceId"])()
                                        }), phrase);
                                        setPhrase('');
                                        setMessage('Encrypted snapshot prepared on this browser.');
                                    }),
                                children: t.offline
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 214,
                                columnNumber: 28
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>void run(async ()=>{
                                        const snap = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$offline$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["unlock"])(phrase);
                                        setOfflineCard(snap.card);
                                        setPhrase('');
                                        if (session && navigator.onLine) await flushOfflineReceipts().catch(()=>{});
                                    }),
                                children: "Unlock saved snapshot"
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 215,
                                columnNumber: 9
                            }, this),
                            offlineCard && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "Offline snapshot from ",
                                            offlineCard.generatedAt,
                                            "; later changes and revocations may be unavailable."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 216,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: offlineCard.notice
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 216,
                                        columnNumber: 130
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "entries",
                                        children: renderEntries(offlineCard.entries)
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 216,
                                        columnNumber: 157
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 216,
                                columnNumber: 23
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 213,
                        columnNumber: 28
                    }, this),
                    session && isAllowed && portal === 'patient' && profile && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "surface wide disclosure",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Medication and document tools"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 218,
                                        columnNumber: 111
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "disclosure-meta",
                                        children: "Import documents or review medication history"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 218,
                                        columnNumber: 153
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 218,
                                columnNumber: 102
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Workflows$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["RecordWorkflows"], {
                                patientId: profile.id,
                                revision: profile.revision,
                                onChange: refresh
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 218,
                                columnNumber: 249
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 218,
                        columnNumber: 57
                    }, this),
                    session && isAllowed && portal === 'hospital' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "surface wide disclosure",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Break-glass review"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 219,
                                        columnNumber: 103
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "disclosure-meta",
                                        children: "Independent emergency access"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 219,
                                        columnNumber: 134
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 219,
                                columnNumber: 94
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Workflows$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BreakGlass"], {
                                hospital: true
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 219,
                                columnNumber: 213
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 219,
                        columnNumber: 49
                    }, this),
                    session && isAllowed && portal === 'paramedic' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        className: "surface wide disclosure",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Break-glass request"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 220,
                                        columnNumber: 104
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "disclosure-meta",
                                        children: "Independent emergency access"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                        lineNumber: 220,
                                        columnNumber: 136
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 220,
                                columnNumber: 95
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Workflows$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BreakGlass"], {
                                link: link,
                                purpose: purpose
                            }, void 0, false, {
                                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                lineNumber: 220,
                                columnNumber: 215
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 220,
                        columnNumber: 50
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                        children: "Nepali copy pending native-speaker review · BS conversion unavailable pending verified reference pairs"
                    }, void 0, false, {
                        fileName: "[project]/apps/web/src/platform/Portal.tsx",
                        lineNumber: 221,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                lineNumber: 127,
                columnNumber: 5
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Root"], {
                open: !!source,
                onOpenChange: (open)=>!open && setSource(null),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Portal"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Overlay"], {
                            className: "dialog-overlay"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                            lineNumber: 223,
                            columnNumber: 93
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Content"], {
                            className: "dialog-content",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Title"], {
                                    children: t.source
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                    lineNumber: 223,
                                    columnNumber: 180
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Description"], {
                                    children: [
                                        source?.source,
                                        " · ",
                                        source?.date
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                    lineNumber: 223,
                                    columnNumber: 219
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
                                    children: source?.excerpt
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                    lineNumber: 223,
                                    columnNumber: 293
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: source?.reviewed ? 'Clinician-authored demo evidence' : 'Attributed patient report'
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                    lineNumber: 223,
                                    columnNumber: 335
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$dialog$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Close"], {
                                    children: "Close"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                                    lineNumber: 223,
                                    columnNumber: 423
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Portal.tsx",
                            lineNumber: 223,
                            columnNumber: 137
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Portal.tsx",
                    lineNumber: 223,
                    columnNumber: 78
                }, this)
            }, void 0, false, {
                fileName: "[project]/apps/web/src/platform/Portal.tsx",
                lineNumber: 223,
                columnNumber: 5
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/apps/web/src/platform/Portal.tsx",
        lineNumber: 122,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/RegisterPatient.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RegisterPatient",
    ()=>RegisterPatient,
    "toJpeg",
    ()=>toJpeg
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserPlus$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/user-plus.js [app-ssr] (ecmascript) <export default as UserPlus>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$qrcode$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/qrcode/lib/index.js [app-ssr] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@pran-rekha/contracts/platform'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/face.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/PhotoCapture.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
const MAX_SIDE = 480;
function toJpeg(source) {
    const w = source instanceof HTMLImageElement ? source.naturalWidth : source.width, h = source instanceof HTMLImageElement ? source.naturalHeight : source.height;
    const scale = Math.min(1, MAX_SIDE / Math.max(w, h)), canvas = document.createElement('canvas');
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
}
const blank = {
    name: '',
    dob: '',
    bloodGroup: '',
    allergies: '',
    tagUid: '',
    username: '',
    password: ''
};
function RegisterPatient({ onRegistered }) {
    const [form, setForm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(blank), [synthetic, setSynthetic] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [photoConsent, setPhotoConsent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [face, setFace] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [faceBusy, setFaceBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [faceError, setFaceError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [modelState, setModelState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('idle'), [captureKey, setCaptureKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0), [donePhoto, setDonePhoto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [done, setDone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null), [qr, setQr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const field = (key)=>({
            value: form[key],
            onChange: (e)=>setForm({
                    ...form,
                    [key]: e.target.value
                })
        });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["loadModels"])().then(()=>setModelState('ready'), ()=>setModelState('unavailable'));
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (done) void __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$qrcode$2f$lib$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].toDataURL(done.locator, {
            width: 160,
            margin: 1
        }).then(setQr);
        else setQr('');
    }, [
        done
    ]);
    async function onPhoto(source) {
        setFaceBusy(true);
        setFaceError('');
        setFace(null);
        try {
            setFace({
                photo: toJpeg(source),
                descriptor: Array.from(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["describe"])(source))
            });
        } catch (e) {
            if (e instanceof __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$face$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FaceInputError"]) setFaceError(e.message);
            else {
                setModelState('unavailable');
            }
        } finally{
            setFaceBusy(false);
        }
    }
    async function submit() {
        setBusy(true);
        setError('');
        setDone(null);
        try {
            const body = {
                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                name: form.name.trim(),
                dob: form.dob,
                username: form.username.trim(),
                password: form.password,
                ...face ? {
                    photo: face.photo,
                    descriptor: face.descriptor
                } : {},
                ...form.bloodGroup ? {
                    bloodGroup: form.bloodGroup
                } : {},
                ...form.allergies.trim() ? {
                    allergies: form.allergies.trim()
                } : {},
                ...form.tagUid.trim() ? {
                    tagUid: form.tagUid.trim()
                } : {}
            };
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/patients', body);
            setDone(result);
            setDonePhoto(face?.photo ?? '');
            setForm(blank);
            setSynthetic(false);
            setPhotoConsent(false);
            setFace(null);
            setCaptureKey((k)=>k + 1);
            onRegistered({
                id: result.patientId,
                name: result.name
            });
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Registration failed');
        } finally{
            setBusy(false);
        }
    }
    const ready = synthetic && (!face || photoConsent) && !faceBusy && form.name.trim() && form.dob && /^[a-z0-9_-]{3,32}$/.test(form.username.trim()) && form.password.length >= 12;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface wide register-patient",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$user$2d$plus$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__UserPlus$3e$__["UserPlus"], {}, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 54,
                            columnNumber: 9
                        }, this),
                        " Register patient"
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                    lineNumber: 54,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Creates a synthetic Pran Rekha record, a patient login and an opaque QR locator. You can add a face photo now or later. Emergency sharing stays off until the patient approves each entry."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                    lineNumber: 55,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                    className: "register-grid",
                    onSubmit: (e)=>{
                        e.preventDefault();
                        if (ready) void submit();
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Full name",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ...field('name'),
                                    autoComplete: "off"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 57,
                                    columnNumber: 23
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 57,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Date of birth",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "date",
                                    ...field('dob'),
                                    max: new Date().toISOString().slice(0, 10)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 58,
                                    columnNumber: 27
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 58,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Blood group",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    ...field('bloodGroup'),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Not recorded"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                            lineNumber: 59,
                                            columnNumber: 58
                                        }, this),
                                        BloodGroups.map((g)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                children: g
                                            }, g, false, {
                                                fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                                lineNumber: 59,
                                                columnNumber: 116
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 59,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 59,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Recorded allergies",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ...field('allergies'),
                                    placeholder: "e.g. Penicillin — anaphylaxis"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 60,
                                    columnNumber: 32
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 60,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "RFID tag UID (optional)",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ...field('tagUid'),
                                    placeholder: "8, 14 or 20 hex characters"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 61,
                                    columnNumber: 37
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 61,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Patient username",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    ...field('username'),
                                    autoComplete: "off",
                                    placeholder: "lowercase, 3–32 characters"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 62,
                                    columnNumber: 30
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 62,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Initial password",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "password",
                                    ...field('password'),
                                    autoComplete: "new-password",
                                    placeholder: "12+ characters"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 63,
                                    columnNumber: 30
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 63,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
                            className: "register-photo",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                                    children: "Face photo (optional; can be added later)"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 65,
                                    columnNumber: 9
                                }, this),
                                modelState === 'idle' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    role: "status",
                                    children: "Loading local face model…"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 66,
                                    columnNumber: 31
                                }, this),
                                modelState === 'unavailable' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    role: "status",
                                    children: "Face model unavailable. You can register now and add a photo later."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 67,
                                    columnNumber: 37
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$PhotoCapture$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["PhotoCapture"], {
                                    disabled: modelState !== 'ready',
                                    busy: faceBusy,
                                    alt: "Registration photo",
                                    onImage: onPhoto,
                                    onError: setFaceError
                                }, captureKey, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 68,
                                    columnNumber: 12
                                }, this),
                                faceBusy && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    role: "status",
                                    children: "Checking for exactly one face…"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 69,
                                    columnNumber: 20
                                }, this),
                                faceError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    role: "alert",
                                    className: "error",
                                    children: faceError
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 70,
                                    columnNumber: 21
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: face ? 'verified' : 'unverified',
                                    children: face ? 'One face detected. Photo ready.' : 'No photo selected. Face matching becomes available after you add one.'
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 71,
                                    columnNumber: 9
                                }, this),
                                face && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>{
                                        setFace(null);
                                        setPhotoConsent(false);
                                        setCaptureKey((k)=>k + 1);
                                    },
                                    children: "Add photo later"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 72,
                                    columnNumber: 16
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 64,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "check",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: photoConsent,
                                    onChange: (e)=>setPhotoConsent(e.target.checked)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 74,
                                    columnNumber: 32
                                }, this),
                                "Participant consents to storing this face photo on the demo server"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 74,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "check",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "checkbox",
                                    checked: synthetic,
                                    onChange: (e)=>setSynthetic(e.target.checked)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 75,
                                    columnNumber: 32
                                }, this),
                                "Synthetic demonstration data only — no real patient information"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 75,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "primary",
                            disabled: !ready || busy,
                            children: "Register patient"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 76,
                            columnNumber: 7
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                    lineNumber: 56,
                    columnNumber: 5
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "error",
                    children: error === 'CONFLICT' ? 'Username or RFID tag is already registered.' : error === 'INVALID_INPUT' ? 'Some fields are invalid. Check the date of birth and RFID tag UID format.' : error
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                    lineNumber: 78,
                    columnNumber: 13
                }, this),
                done && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "register-result",
                    role: "status",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "eyebrow",
                                    children: "Registered"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 80,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    children: done.name
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 80,
                                    columnNumber: 55
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "pass-id",
                                    children: done.patientId
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 80,
                                    columnNumber: 75
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        "Patient login: ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                            children: done.username
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                            lineNumber: 81,
                                            columnNumber: 27
                                        }, this),
                                        " · sign in at /patient"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 81,
                                    columnNumber: 9
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "Emergency sharing is off until the patient approves entries."
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                                    lineNumber: 82,
                                    columnNumber: 9
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 80,
                            columnNumber: 7
                        }, this),
                        donePhoto && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: donePhoto,
                            width: 120,
                            alt: 'Registered photo of ' + done.name
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 83,
                            columnNumber: 19
                        }, this),
                        qr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: qr,
                            width: 160,
                            height: 160,
                            alt: 'Opaque emergency locator QR for ' + done.name
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                            lineNumber: 84,
                            columnNumber: 12
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
                    lineNumber: 79,
                    columnNumber: 12
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
            lineNumber: 53,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/RegisterPatient.tsx",
        lineNumber: 53,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/Workflows.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BreakGlass",
    ()=>BreakGlass,
    "LabAccess",
    ()=>LabAccess,
    "RecordWorkflows",
    ()=>RecordWorkflows
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/Localized.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
;
function RecordWorkflows({ patientId, revision, onChange, clinician = false }) {
    const [docs, setDocs] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]), [meds, setMeds] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]), [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [documentId, setDocumentId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [page, setPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1), [start, setStart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0), [end, setEnd] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(1), [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [drug, setDrug] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [dose, setDose] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [frequency, setFrequency] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [evidence, setEvidence] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [effective, setEffective] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(new Date().toISOString().slice(0, 10)), [eventKind, setEventKind] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('status_confirmed'), [target, setTarget] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [replacement, setReplacement] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    async function refresh() {
        setMeds(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/medications'));
        if (!clinician) setDocs(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/documents'));
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        void refresh().catch((e)=>setError(String(e)));
    }, [
        patientId,
        revision,
        clinician
    ]);
    async function run(action) {
        setBusy(true);
        setError('');
        try {
            await action();
            await refresh();
            await onChange();
        } catch (e) {
            setError(e instanceof Error ? e.message : String(e));
        } finally{
            setBusy(false);
        }
    }
    const doc = docs.find((d)=>d.id === documentId);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface wide",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    children: "Documents and medication history"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 19,
                    columnNumber: 5
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "error",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 19,
                    columnNumber: 54
                }, this),
                !clinician && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Import JPEG, PNG or text PDF (10 MiB maximum)",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "file",
                                    accept: "image/jpeg,image/png,application/pdf",
                                    disabled: busy,
                                    onChange: (e)=>{
                                        const file = e.target.files?.[0];
                                        if (!file) return;
                                        void run(async ()=>{
                                            if (file.size > 10 * 1024 * 1024) throw new Error('File exceeds 10 MiB.');
                                            const base64 = await new Promise((resolve, reject)=>{
                                                const reader = new FileReader();
                                                reader.onload = ()=>resolve(String(reader.result).split(',')[1]);
                                                reader.onerror = ()=>reject(reader.error);
                                                reader.readAsDataURL(file);
                                            });
                                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/documents', {
                                                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                title: file.name,
                                                base64
                                            });
                                        });
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 21,
                                    columnNumber: 59
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 21,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Source document",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: documentId,
                                    onChange: (e)=>{
                                        setDocumentId(e.target.value);
                                        setPage(1);
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: "",
                                            children: "Select source"
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 28,
                                            columnNumber: 114
                                        }, this),
                                        docs.map((d)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                value: d.id,
                                                children: [
                                                    d.title,
                                                    " · ",
                                                    d.status
                                                ]
                                            }, d.id, true, {
                                                fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                lineNumber: 28,
                                                columnNumber: 166
                                            }, this))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 28,
                                    columnNumber: 29
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 28,
                            columnNumber: 7
                        }, this),
                        doc && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: '/api/platform/documents/' + doc.id + '/original',
                                    download: true,
                                    children: "Download private original"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 29,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    children: [
                                        "Page",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "number",
                                            min: 1,
                                            max: doc.pages.length,
                                            value: page,
                                            onChange: (e)=>setPage(Number(e.target.value))
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 30,
                                            columnNumber: 20
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 30,
                                    columnNumber: 9
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                    style: {
                                        whiteSpace: 'pre-wrap',
                                        maxHeight: 180,
                                        overflow: 'auto'
                                    },
                                    children: doc.pages[page - 1] || 'No extracted text. Enter an attributed manual transcription below.'
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 31,
                                    columnNumber: 9
                                }, this),
                                doc.pages[page - 1] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            children: [
                                                "Source start (UTF-16 offset)",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "number",
                                                    min: 0,
                                                    value: start,
                                                    onChange: (e)=>setStart(Number(e.target.value))
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                    lineNumber: 32,
                                                    columnNumber: 66
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 32,
                                            columnNumber: 31
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                            children: [
                                                "Source end",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "number",
                                                    min: 1,
                                                    value: end,
                                                    onChange: (e)=>setEnd(Number(e.target.value))
                                                }, void 0, false, {
                                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                    lineNumber: 32,
                                                    columnNumber: 182
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 32,
                                            columnNumber: 165
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("blockquote", {
                                            children: doc.pages[page - 1].slice(start, end)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 32,
                                            columnNumber: 277
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 32,
                                    columnNumber: 29
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    children: [
                                        "Confirmed value",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            value: value,
                                            onChange: (e)=>setValue(e.target.value)
                                        }, void 0, false, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 33,
                                            columnNumber: 31
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 33,
                                    columnNumber: 9
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    disabled: busy || !value,
                                    onClick: ()=>void run(async ()=>{
                                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/documents/' + doc.id + '/confirm', {
                                                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                expectedRevision: revision,
                                                page,
                                                start,
                                                end,
                                                text: value,
                                                date: effective,
                                                kind: 'report'
                                            });
                                            setValue('');
                                        }),
                                    children: "Confirm source and patient"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 34,
                                    columnNumber: 9
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 29,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 20,
                    columnNumber: 18
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Effective clinical date",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "date",
                            value: effective,
                            onChange: (e)=>setEffective(e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 37,
                            columnNumber: 35
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 37,
                    columnNumber: 5
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                    children: [
                        "Attributed statement / source evidence",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                            value: evidence,
                            onChange: (e)=>setEvidence(e.target.value)
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 38,
                            columnNumber: 50
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 38,
                    columnNumber: 5
                }, this),
                clinician && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            children: "Add immutable prescription"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 39,
                            columnNumber: 19
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Drug as written",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: drug,
                                    onChange: (e)=>setDrug(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 39,
                                    columnNumber: 76
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 39,
                            columnNumber: 54
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Dose as written",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: dose,
                                    onChange: (e)=>setDose(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 39,
                                    columnNumber: 165
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 39,
                            columnNumber: 143
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Frequency as written",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: frequency,
                                    onChange: (e)=>setFrequency(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 39,
                                    columnNumber: 259
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 39,
                            columnNumber: 232
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: busy || !drug || !dose || !frequency || !evidence,
                            onClick: ()=>void run(async ()=>{
                                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/medications', {
                                        requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                        drugText: drug,
                                        doseText: dose,
                                        frequencyText: frequency,
                                        source: evidence,
                                        startDate: effective,
                                        endDate: null
                                    });
                                }),
                            children: "Save prescription evidence"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 40,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Event kind",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: eventKind,
                                    onChange: (e)=>setEventKind(e.target.value),
                                    children: [
                                        'started',
                                        'status_confirmed',
                                        'held',
                                        'resumed',
                                        'stopped',
                                        'completed',
                                        'dose_changed',
                                        'substituted',
                                        'corrected',
                                        'retracted'
                                    ].map((k)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            children: k
                                        }, k, false, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 41,
                                            columnNumber: 224
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 41,
                                    columnNumber: 24
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 41,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Target event ID (correction/retraction)",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: target,
                                    onChange: (e)=>setTarget(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 42,
                                    columnNumber: 53
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 42,
                            columnNumber: 7
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Replacement event/record ID",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    value: replacement,
                                    onChange: (e)=>setReplacement(e.target.value)
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 43,
                                    columnNumber: 41
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 43,
                            columnNumber: 7
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 39,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "entries",
                    children: meds.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: "entry",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "pill",
                                    children: m.view.state
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 45,
                                    columnNumber: 88
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    children: m.record.drug.rawText
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 45,
                                    columnNumber: 132
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        m.record.doseText,
                                        " · ",
                                        m.record.frequencyText
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 45,
                                    columnNumber: 164
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: m.view.basis
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 45,
                                    columnNumber: 217
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                    children: [
                                        "Record: ",
                                        m.record.id
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 45,
                                    columnNumber: 238
                                }, this),
                                m.events.map((e)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            e.kind,
                                            " · ",
                                            e.effectiveDate,
                                            " · ",
                                            e.source,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                lineNumber: 46,
                                                columnNumber: 79
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                children: e.id
                                            }, void 0, false, {
                                                fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                lineNumber: 46,
                                                columnNumber: 84
                                            }, this)
                                        ]
                                    }, e.id, true, {
                                        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                        lineNumber: 46,
                                        columnNumber: 24
                                    }, this)),
                                m.useReports.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            "Reported by ",
                                            r.actorId,
                                            " at ",
                                            r.reportedAt,
                                            ": ",
                                            r.statement,
                                            " · last dose ",
                                            r.lastDose ?? 'unknown'
                                        ]
                                    }, r.id, true, {
                                        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                        lineNumber: 47,
                                        columnNumber: 28
                                    }, this)),
                                clinician ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    disabled: busy || !evidence,
                                    onClick: ()=>void run(async ()=>{
                                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/medications/' + m.record.id + '/events', {
                                                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                expectedRevision: m.view.sourceRevision,
                                                kind: eventKind,
                                                effectiveDate: effective,
                                                source: evidence,
                                                ...eventKind === 'status_confirmed' ? {
                                                    status: 'documented_active'
                                                } : {},
                                                ...[
                                                    'corrected',
                                                    'retracted'
                                                ].includes(eventKind) ? {
                                                    targetEventId: target
                                                } : {},
                                                ...eventKind === 'corrected' ? {
                                                    replacementEventId: replacement
                                                } : {},
                                                ...[
                                                    'substituted',
                                                    'dose_changed'
                                                ].includes(eventKind) ? {
                                                    replacementRecordId: replacement
                                                } : {}
                                            });
                                        }),
                                    children: "Append event"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 48,
                                    columnNumber: 18
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    disabled: busy || !evidence,
                                    onClick: ()=>void run(async ()=>{
                                            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/medications/' + m.record.id + '/use-reports', {
                                                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                                use: 'uncertain',
                                                lastDose: null,
                                                statement: evidence
                                            });
                                        }),
                                    children: "Add attributed use report"
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 49,
                                    columnNumber: 8
                                }, this)
                            ]
                        }, m.record.id, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 45,
                            columnNumber: 43
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 45,
                    columnNumber: 5
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
            lineNumber: 18,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
        lineNumber: 18,
        columnNumber: 10
    }, this);
}
function BreakGlass({ hospital = false, link, purpose, identityVerified = false }) {
    const [requests, setRequests] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]), [id, setId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [card, setCard] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    async function run(action) {
        try {
            setMessage(JSON.stringify(await action()));
        } catch (e) {
            setMessage(String(e));
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    children: "Second-clinician approval"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 57,
                    columnNumber: 50
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "Requests access to entries the patient already approved. It cannot expand scope or bypass revocation; verify two identifiers first."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 57,
                    columnNumber: 84
                }, this),
                hospital ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>void run(async ()=>{
                                    const rows = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/break-glass');
                                    setRequests(rows);
                                    return {
                                        pending: rows.length
                                    };
                                }),
                            children: "Load approval queue"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 58,
                            columnNumber: 17
                        }, this),
                        requests.map((r)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "Patient ",
                                    r.patient,
                                    " · ",
                                    r.approvedEntryCount,
                                    " entries · ",
                                    r.purpose,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>void run(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/break-glass/' + r.id + '/approve', {
                                                    requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])()
                                                })),
                                        children: "Approve five-minute access"
                                    }, void 0, false, {
                                        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                        lineNumber: 58,
                                        columnNumber: 295
                                    }, this)
                                ]
                            }, r.id, true, {
                                fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                lineNumber: 58,
                                columnNumber: 215
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 58,
                    columnNumber: 15
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: !link || !identityVerified,
                            onClick: ()=>void run(async ()=>{
                                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/break-glass', {
                                        requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                                        ...link,
                                        purpose: purpose ?? 'Emergency review request',
                                        deviceId: 'staff-browser',
                                        confirmed: true,
                                        identityVerified: true
                                    });
                                    setId(result.id);
                                    return result;
                                }),
                            children: "Request independent approval"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 59,
                            columnNumber: 8
                        }, this),
                        id && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>void run(async ()=>{
                                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/break-glass/' + id);
                                    if (result.grantId) setCard(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/cards', {
                                        grantId: result.grantId
                                    }));
                                    return result;
                                }),
                            children: "Check approval"
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 59,
                            columnNumber: 359
                        }, this),
                        card && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: card.notice
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 59,
                                    columnNumber: 620
                                }, this),
                                card.entries.map((entry)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                        className: "entry",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: [
                                                    entry.kind,
                                                    ": ",
                                                    entry.text
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                lineNumber: 59,
                                                columnNumber: 707
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                children: [
                                                    entry.date,
                                                    " · ",
                                                    entry.source
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                                lineNumber: 59,
                                                columnNumber: 750
                                            }, this)
                                        ]
                                    }, entry.id, true, {
                                        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                        lineNumber: 59,
                                        columnNumber: 665
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 59,
                            columnNumber: 618
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 59,
                    columnNumber: 6
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "status",
                    children: message
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 60,
                    columnNumber: 5
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
            lineNumber: 57,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
        lineNumber: 57,
        columnNumber: 10
    }, this);
}
function LabAccess({ patients }) {
    const [patientId, setPatientId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(patients[0]?.id ?? ''), [assigned, setAssigned] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false), [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(''), [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!patients.some((p)=>p.id === patientId)) setPatientId(patients[0]?.id ?? '');
    }, [
        patients,
        patientId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!patientId) {
            setAssigned(false);
            return;
        }
        void (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/lab-access').then((r)=>setAssigned(r.assigned)).catch((e)=>setError(String(e)));
    }, [
        patientId
    ]);
    async function toggle() {
        setBusy(true);
        setError('');
        try {
            const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["api"])('platform/profiles/' + patientId + '/lab-access', {
                requestId: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$client$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["requestId"])(),
                active: !assigned
            });
            setAssigned(result.assigned);
        } catch (e) {
            setError(String(e));
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$Localized$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Localized"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "surface",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    children: "Laboratory access"
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 69,
                    columnNumber: 50
                }, this),
                !patients.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "No patients are assigned to this hospital account."
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 69,
                    columnNumber: 94
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            children: [
                                "Patient",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                    value: patientId,
                                    onChange: (e)=>setPatientId(e.target.value),
                                    children: patients.map((p)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                            value: p.id,
                                            children: [
                                                p.name,
                                                " · ",
                                                p.id
                                            ]
                                        }, p.id, true, {
                                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                            lineNumber: 69,
                                            columnNumber: 254
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                                    lineNumber: 69,
                                    columnNumber: 168
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 69,
                            columnNumber: 154
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: assigned ? 'The demo laboratory can review and update this patient.' : 'The demo laboratory cannot access this patient.'
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 69,
                            columnNumber: 331
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            disabled: busy || !patientId,
                            onClick: ()=>void toggle(),
                            children: assigned ? 'Remove lab access' : 'Assign to lab'
                        }, void 0, false, {
                            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                            lineNumber: 69,
                            columnNumber: 456
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 69,
                    columnNumber: 152
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    role: "alert",
                    className: "error",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/apps/web/src/platform/Workflows.tsx",
                    lineNumber: 69,
                    columnNumber: 587
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/apps/web/src/platform/Workflows.tsx",
            lineNumber: 69,
            columnNumber: 21
        }, this)
    }, void 0, false, {
        fileName: "[project]/apps/web/src/platform/Workflows.tsx",
        lineNumber: 69,
        columnNumber: 10
    }, this);
}
}),
"[project]/apps/web/src/platform/categorize.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOW_CONFIDENCE",
    ()=>LOW_CONFIDENCE,
    "categorize",
    ()=>categorize,
    "toCandidates",
    ()=>toCandidates,
    "toLabReportCandidates",
    ()=>toLabReportCandidates
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/medical-lexicon.ts [app-ssr] (ecmascript)");
;
// Keyword rules that propose a record category for one recognized line. Order matters: first match wins.
// null means uncategorized; the clinician must choose before signing.
const rules = [
    [
        'allergy',
        /allerg|anaphyla|reaction to|intoleran/i
    ],
    [
        'blood_group',
        /blood\s*group|^\s*(A|B|AB|O)\s*(\+|-|pos|neg)\s*$|\b(A|B|AB|O)\s*(\+|-)(?=\s|$)/i
    ],
    [
        'vital',
        /\b(bp|blood pressure|pulse|hr|heart rate|spo2|sp02|temp|temperature|rr|resp(iratory)? rate)\b|\b\d{2,3}\/\d{2,3}\s*mm\s*hg\b/i
    ],
    [
        'implant',
        /implant|pacemaker|stent|prosthe/i
    ],
    [
        'medication',
        /\b\d+(\.\d+)?\s*(mg|mcg|µg|ml|g|iu|units?)\b|\b(tab|tabs|tablet|cap|caps|capsule|syr|syrup|inj|injection|od|bd|bid|tds|tid|qid|hs|prn|sos|stat)\b|\b[01]\s*-\s*[01]\s*-\s*[01]\b|^\s*rx\b/i
    ],
    [
        'condition',
        /diagnos|\bdx\b|\bh\/o\b|history of|diabet|hypertens|\bhtn\b|asthma|copd|\bckd\b|epilep|thyroid/i
    ]
];
function categorize(line) {
    for (const [kind, re] of rules)if (re.test(line)) return kind;
    return null;
}
const LOW_CONFIDENCE = 60;
function toCandidates(lines) {
    return lines.map((l)=>({
            ...l,
            text: l.text.replace(/\s+/g, ' ').trim()
        })).filter((l)=>l.text.replace(/[^\p{L}\p{N}]/gu, '').length >= 3).map((l, i)=>{
        const fixed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["correctLine"])(l.text);
        return {
            id: 'line-' + i,
            original: l.text,
            text: fixed.text,
            kind: categorize(fixed.text),
            confidence: l.confidence,
            include: true,
            corrections: fixed.changed,
            ...l.alternative ? {
                alternative: l.alternative
            } : {}
        };
    });
}
const diagnosisSection = /\b(diagnosis|impression|clinical impression|clinical diagnosis|provisional diagnosis|final diagnosis|interpretation|assessment|history of|known case of)\b|(?:निदान|निष्कर्ष|रोगको इतिहास|रोगको पहिचान)/i;
const diagnosisHeading = /^\s*(?:diagnosis|impression|clinical impression|clinical diagnosis|provisional diagnosis|final diagnosis|assessment|interpretation|निदान|निष्कर्ष|रोगको इतिहास|रोगको पहिचान)\s*[:\-–]?\s*$/i;
const otherSectionHeading = /^\s*(?:results?|investigations?|test(?:s)?|reference range|specimen|patient details|remarks|comments?|recommendations?|रिपोर्ट विवरण|परीक्षण नतिजा)\s*[:\-–]?\s*$/i;
const explicitCondition = /\b(diabet(?:es)?|\bdm\b|hypertension|htn|asthma|copd|chronic kidney disease|ckd|epilepsy|hypothyroid(?:ism)?|hyperthyroid(?:ism)?|anemia|anaemia|tuberculosis|\btb\b|dengue|malaria|hepatitis|hiv|cancer|carcinoma|migraine|thyroid disorder)\b|(?:मधुमेह|उच्च रक्तचाप|दम|क्षयरोग|मलेरिया|डेंगु|रक्तअल्पता|क्यान्सर)/i;
function toLabReportCandidates(lines) {
    let inDiagnosisSection = false;
    return lines.map((line, i)=>{
        const original = line.text.replace(/\s+/g, ' ').trim();
        if (diagnosisHeading.test(original)) inDiagnosisSection = true;
        else if (otherSectionHeading.test(original)) inDiagnosisSection = false;
        const condition = (diagnosisSection.test(original) || inDiagnosisSection) && explicitCondition.test(original);
        const kind = condition ? 'condition' : 'report';
        return {
            id: 'lab-line-' + i,
            original,
            text: original,
            kind,
            confidence: line.confidence,
            include: Boolean(original),
            ...line.alternative ? {
                alternative: line.alternative
            } : {}
        };
    }).filter((row)=>row.original.replace(/[^\p{L}\p{N}]/gu, '').length >= 3);
}
}),
"[project]/apps/web/src/platform/client.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "api",
    ()=>api,
    "labels",
    ()=>labels,
    "requestId",
    ()=>requestId,
    "usePreferences",
    ()=>usePreferences
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
;
const usePreferences = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])((set)=>({
        language: 'en',
        setLanguage: (language)=>{
            localStorage.setItem('pran-language', language);
            document.documentElement.lang = language;
            set({
                language
            });
        },
        // Light until the user explicitly chooses; only an explicit choice is remembered.
        theme: 'light',
        setTheme: (theme, remember = true)=>{
            if (remember) {
                try {
                    localStorage.setItem('pran-theme', theme);
                } catch  {}
            }
            document.documentElement.dataset.theme = theme;
            set({
                theme
            });
        }
    }));
async function api(path, body, method) {
    const response = await fetch('/api/' + path, {
        method: method ?? (body === undefined ? 'GET' : 'POST'),
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json'
        },
        ...body === undefined ? {} : {
            body: JSON.stringify(body)
        }
    });
    const data = response.status === 204 ? null : await response.json();
    if (!response.ok) throw new Error(data?.error?.message ?? 'Request failed');
    return data;
}
const requestId = ()=>crypto.randomUUID();
const labels = {
    en: {
        patient: 'Patient',
        paramedic: 'Paramedic',
        hospital: 'Hospital',
        lab: 'Lab',
        signIn: 'Sign in',
        signOut: 'Sign out',
        records: 'Health records',
        source: 'Source',
        release: 'Emergency release',
        save: 'Save release',
        revoke: 'Revoke release',
        receipts: 'Access receipts',
        sign: 'Sign clinical record',
        dispatch: 'Initiate pre-arrival dispatch',
        scan: 'Read paired RFID scanner',
        manual: 'Resolve locator',
        offline: 'Prepare offline copy',
        booking: 'Book review appointment',
        report: 'Add patient report',
        review: 'Review due',
        synthetic: 'Synthetic demonstration',
        refresh: 'Refresh',
        confirm: 'I have confirmed patient linkage',
        purpose: 'Access reason',
        name: 'Username',
        password: 'Password',
        dark: 'Dark',
        light: 'Light',
        toDark: 'Switch to dark mode',
        toLight: 'Switch to light mode'
    },
    ne: {
        patient: 'बिरामी',
        paramedic: 'प्यारामेडिक',
        hospital: 'अस्पताल',
        lab: 'प्रयोगशाला',
        signIn: 'साइन इन',
        signOut: 'साइन आउट',
        records: 'स्वास्थ्य अभिलेख',
        source: 'स्रोत',
        release: 'आपत्कालीन अनुमति',
        save: 'अनुमति सुरक्षित गर्नुहोस्',
        revoke: 'अनुमति रद्द गर्नुहोस्',
        receipts: 'पहुँच विवरण',
        sign: 'अभिलेखमा हस्ताक्षर गर्नुहोस्',
        dispatch: 'अस्पताललाई सूचना पठाउनुहोस्',
        scan: 'RFID स्क्यान पढ्नुहोस्',
        manual: 'परिचायक खोज्नुहोस्',
        offline: 'अफलाइन प्रति तयार गर्नुहोस्',
        booking: 'जाँच समय बुक गर्नुहोस्',
        report: 'बिरामीको विवरण थप्नुहोस्',
        review: 'पुनरावलोकन मिति',
        synthetic: 'कृत्रिम प्रदर्शन',
        refresh: 'ताजा गर्नुहोस्',
        confirm: 'मैले बिरामीको पहिचान पुष्टि गरेको छु',
        purpose: 'पहुँचको कारण',
        name: 'प्रयोगकर्ता नाम',
        password: 'पासवर्ड',
        dark: 'गाढा',
        light: 'उज्यालो',
        toDark: 'गाढा मोडमा बदल्नुहोस्',
        toLight: 'उज्यालो मोडमा बदल्नुहोस्'
    }
};
}),
"[project]/apps/web/src/platform/face.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Face candidate matcher. Detection, description and matching run in the browser. The gallery is the
// faces saved at hospital registration (photo + descriptor stored server-side, hospital-only) plus
// session-only enrollments that are never sent to the API. Probe images are never uploaded.
__turbopack_context__.s([
    "FaceInputError",
    ()=>FaceInputError,
    "MATCH_THRESHOLD",
    ()=>MATCH_THRESHOLD,
    "MAX_CANDIDATES",
    ()=>MAX_CANDIDATES,
    "MAX_ENROLLED",
    ()=>MAX_ENROLLED,
    "classify",
    ()=>classify,
    "describe",
    ()=>describe,
    "loadModels",
    ()=>loadModels,
    "match",
    ()=>match
]);
class FaceInputError extends Error {
}
const MAX_ENROLLED = 5, MAX_CANDIDATES = 3, MATCH_THRESHOLD = 0.5;
function classify(distances, threshold = MATCH_THRESHOLD) {
    const hits = distances.map((d, i)=>[
            d,
            i
        ]).filter(([d])=>d < threshold).sort((a, b)=>a[0] - b[0]).map(([, i])=>i);
    if (!hits.length) return {
        state: 'NO_MATCH'
    };
    if (hits.length > MAX_CANDIDATES) return {
        state: 'AMBIGUOUS'
    };
    return {
        state: 'CANDIDATES',
        indexes: hits
    };
}
function distance(a, b) {
    let sum = 0;
    for(let i = 0; i < a.length; i++){
        const d = a[i] - b[i];
        sum += d * d;
    }
    return Math.sqrt(sum);
}
function match(probe, gallery) {
    const result = classify(gallery.map((g)=>distance(probe, g.descriptor)));
    if (result.state !== 'CANDIDATES') return result;
    return {
        state: 'CANDIDATES',
        candidates: result.indexes.map((i)=>{
            const { handle, label, patientId } = gallery[i];
            return {
                handle,
                label,
                patientId
            };
        })
    };
}
let loading = null;
function loadModels() {
    loading ??= (async ()=>{
        const faceapi = await __turbopack_context__.A("[project]/node_modules/@vladmandic/face-api/dist/face-api.esm.js [app-ssr] (ecmascript, async loader)");
        await Promise.all([
            faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
            faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
            faceapi.nets.faceRecognitionNet.loadFromUri('/models')
        ]);
        return faceapi;
    })().catch((e)=>{
        loading = null;
        throw e;
    });
    return loading;
}
async function describe(source) {
    const faceapi = await loadModels();
    const faces = await faceapi.detectAllFaces(source, new faceapi.TinyFaceDetectorOptions({
        inputSize: 416,
        scoreThreshold: 0.3
    })).withFaceLandmarks().withFaceDescriptors();
    if (!faces.length) throw new FaceInputError('No face found. Use a clear, front-facing image.');
    if (faces.length > 1) throw new FaceInputError('More than one face found. Use an image with exactly one person.');
    return faces[0].descriptor;
}
}),
"[project]/apps/web/src/platform/medical-lexicon.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "correctLine",
    ()=>correctLine,
    "editDistance",
    ()=>editDistance,
    "plausibility",
    ()=>plausibility
]);
// Post-OCR correction for prescriptions: fixes digit/letter confusions in doses and units, and snaps
// near-miss words to common generic drug names. Output is still a candidate the clinician confirms.
// Common generics (WHO essential medicines + frequent Nepal OPD prescriptions). Spelling here is the output form.
const DRUGS = `Acetazolamide Aciclovir Acyclovir Adrenaline Albendazole Allopurinol Alprazolam Amiodarone Amitriptyline Amlodipine
Amoxicillin Amoxiclav Ampicillin Aspirin Atenolol Atorvastatin Atropine Azithromycin Baclofen Beclomethasone Betahistine
Betamethasone Bisacodyl Bisoprolol Budesonide Bupivacaine Calamine Calcitriol Calcium Captopril Carbamazepine Carvedilol
Cefadroxil Cefixime Cefpodoxime Ceftriaxone Cefuroxime Cephalexin Cetirizine Chloramphenicol Chloroquine Chlorpheniramine
Chlorpromazine Chlorhexidine Cholecalciferol Cinnarizine Ciprofloxacin Citalopram Clarithromycin Clindamycin Clobetasol
Clonazepam Clonidine Clopidogrel Clotrimazole Cloxacillin Codeine Colchicine Cotrimoxazole Cyproheptadine Dapagliflozin
Deferasirox Dexamethasone Dextromethorphan Diazepam Diclofenac Dicyclomine Digoxin Diltiazem Diphenhydramine Domperidone
Donepezil Doxycycline Duloxetine Empagliflozin Enalapril Enoxaparin Entecavir Erythromycin Escitalopram Esomeprazole
Ethambutol Etoricoxib Famotidine Febuxostat Fenofibrate Ferrous Fexofenadine Finasteride Fluconazole Fluoxetine Fluticasone
Folic Furosemide Gabapentin Gentamicin Glibenclamide Gliclazide Glimepiride Glipizide Glyceryl Haloperidol Heparin
Hydralazine Hydrochlorothiazide Hydrocortisone Hydroxychloroquine Hydroxyzine Hyoscine Ibuprofen Indomethacin Insulin
Ipratropium Irbesartan Iron Isoniazid Isosorbide Itraconazole Ivermectin Ketoconazole Ketorolac Labetalol Lactulose
Lamotrigine Lansoprazole Levetiracetam Levocetirizine Levofloxacin Levothyroxine Lidocaine Linagliptin Linezolid
Lisinopril Loperamide Loratadine Lorazepam Losartan Magnesium Mebendazole Mefenamic Meloxicam Metformin Methotrexate
Methyldopa Methylprednisolone Metoclopramide Metoprolol Metronidazole Miconazole Midazolam Mirtazapine Montelukast
Morphine Moxifloxacin Multivitamin Mupirocin Naproxen Nebivolol Neomycin Nifedipine Nitrofurantoin Nitroglycerin
Norfloxacin Nystatin Ofloxacin Olanzapine Olmesartan Omeprazole Ondansetron Oseltamivir Oxytocin Pantoprazole Paracetamol
Penicillin Permethrin Phenobarbital Phenytoin Pioglitazone Piroxicam Potassium Pramipexole Pravastatin Praziquantel
Prednisolone Prednisone Pregabalin Primaquine Prochlorperazine Promethazine Propranolol Pyrazinamide Pyridoxine Quetiapine
Rabeprazole Ramipril Ranitidine Rifampicin Risperidone Rosuvastatin Salbutamol Salmeterol Sertraline Sildenafil Simvastatin
Sitagliptin Sodium Spironolactone Sucralfate Sulfasalazine Sumatriptan Tamsulosin Telmisartan Tenofovir Terbinafine
Theophylline Thiamine Tinidazole Tiotropium Tramadol Tranexamic Trimethoprim Ursodeoxycholic Valproate Valsartan
Vancomycin Verapamil Vildagliptin Vitamin Warfarin Zinc Zolpidem`.split(/\s+/);
// Clinical words worth snapping to (Alergy → Allergy), in their output spelling.
const CLINICAL = `Allergy Allergic Reaction History Diagnosis Diabetes Hypertension Asthma Thyroid Pressure Blood Group Pulse
Temperature Sugar Fasting Stent Implant Pacemaker Tablet Tablets Capsule Capsules Syrup Drops Cream Ointment Injection
Inhaler Daily Morning Night Evening Before After Meals Weeks Months Review Continue`.split(/\s+/);
// Everyday words that must never be "corrected" into a drug or clinical word.
const COMMON = new Set(`with without take food days when needed until stop start dose units drug drugs sulfa tabs caps pain fever
cough cold vomiting nausea headache patient doctor hospital clinic times once twice thrice follow kidney liver heart random
that this then them they what have from your more less same each over under very also only into onto upon`.split(/\s+/));
const ABBREVIATIONS = {
    od: 'OD',
    bd: 'BD',
    bid: 'BID',
    tds: 'TDS',
    tid: 'TID',
    qid: 'QID',
    hs: 'HS',
    sos: 'SOS',
    prn: 'PRN',
    stat: 'STAT',
    tab: 'Tab',
    tabs: 'Tabs',
    cap: 'Cap',
    caps: 'Caps',
    syr: 'Syr',
    inj: 'Inj',
    rx: 'Rx',
    dx: 'Dx',
    bp: 'BP'
};
const FORMS = [
    'Tab',
    'Cap',
    'Syr',
    'Inj'
];
const UNITS = new Set([
    'mg',
    'mcg',
    'ml',
    'g',
    'iu',
    'mmhg',
    'units',
    'x',
    'kg',
    '%'
]);
const drugs = new Map(DRUGS.map((d)=>[
        d.toLowerCase(),
        d
    ]));
const vocabulary = new Map([
    ...CLINICAL.map((w)=>[
            w.toLowerCase(),
            w
        ]),
    ...drugs
]);
function editDistance(a, b) {
    const d = Array.from({
        length: a.length + 1
    }, (_, i)=>[
            i,
            ...Array(b.length).fill(0)
        ]);
    for(let j = 1; j <= b.length; j++)d[0][j] = j;
    for(let i = 1; i <= a.length; i++)for(let j = 1; j <= b.length; j++){
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
    }
    return d[a.length][b.length];
}
// Closest vocabulary word within ~a third of its length. Ties prefer the candidate of equal length
// (OCR mostly substitutes letters); a remaining tie keeps the original rather than guess.
function nearestWord(word) {
    const lower = word.toLowerCase();
    const exact = vocabulary.get(lower);
    if (exact) return exact;
    if (COMMON.has(lower) || lower.length < 4) return null;
    const limit = lower.length <= 5 ? 1 : Math.floor(lower.length * 0.34);
    let best = null, bestDistance = Infinity, bestGap = Infinity, tie = false;
    for (const [key, out] of vocabulary){
        const gap = Math.abs(key.length - lower.length);
        if (gap > limit) continue;
        const distance = editDistance(lower, key);
        if (distance < bestDistance || distance === bestDistance && gap < bestGap) {
            best = out;
            bestDistance = distance;
            bestGap = gap;
            tie = false;
        } else if (distance === bestDistance && gap === bestGap && out !== best) tie = true;
    }
    return best && bestDistance <= limit && !tie ? best : null;
}
const digitLike = (s)=>s.replace(/[Oo]/g, '0').replace(/[Il|(!\]i]/g, '1').replace(/[Ss]/g, '5');
const unitFor = (u)=>/^(mcg|mcq|meg)$/i.test(u) ? 'mcg' : /^(ml|rnl)$/i.test(u) || u === 'mI' ? 'ml' : 'mg';
function correctLine(input) {
    const changed = [];
    const note = (from, to)=>{
        if (from.trim() !== to.trim()) changed.push(`${from.trim()}→${to.trim()}`);
        return to;
    };
    // Stray punctuation at the ends, and glued words/numbers (Paracetamol650, mg.BD).
    let text = input.replace(/^[\s.,;:'"`~\-_]+|[\s.,;:'"`~\-_]+$/g, '').replace(/([A-Za-z]{3,})(\d)/g, '$1 $2').replace(/([a-z])\.(?=[A-Z]{2,}\b)/g, '$1 ').replace(/([A-Za-z])-(?=[A-Za-z]{3,})/g, '$1 ');
    // Dosing pattern like 1-0-1 written or read with look-alikes (l-O-l, (-O-I).
    text = text.replace(/(?<![\w])([01OoIil|(!\]])\s*[-–—]\s*([01OoIil|(!\]])\s*[-–—]\s*([01OoIil|(!\]])(?![\w])/g, (m)=>note(m, digitLike(m).replace(/\s*[-–—]\s*/g, '-')));
    // A number-like token followed by a unit-like token: 5OO rng, Soo mq → 500 mg.
    text = text.replace(/(?<![\w.])([0-9OoSsIl|]{1,5}(?:\.[0-9Oo]+)?)\s*(mg|mq|rng|rnq|nig|m9|mgs|mcg|mcq|meg|ml|rnl|mI)(?![a-z])/gi, (m, n, u)=>/\d/.test(n) || /^[Ss][Oo0]{1,3}$/.test(n) ? note(m, `${digitLike(n)} ${unitFor(u)}`) : m);
    // Remaining numbers with letter look-alikes: 5OO, l0.
    text = text.replace(/(?<![\w.])(?=[0-9OoIlSs|]*\d)[0-9OoIlSs|]{2,}(?:\.[0-9Oo]+)?(?![\w])/g, (m)=>note(m, digitLike(m)));
    text = text.replace(/(\d)(mg|mcg|ml|g|iu)\b/gi, (_m, d, u)=>`${d} ${u.toLowerCase()}`);
    // Blood pressure: 130 (85 → 130/85, BB 130/85 → BP, and a short word after the ratio is mmHg.
    text = text.replace(/\b(\d{2,3})\s?[(|\\]\s?(\d{2,3})\b/g, (m, a, b)=>note(m, `${a}/${b}`));
    text = text.replace(/^[A-Z8]{2}(?=\s*\d{2,3}\s*\/\s*\d{2,3})/, (m)=>m === 'BP' ? m : note(m, 'BP'));
    text = text.replace(/(\d{2,3}\s*\/\s*\d{2,3})\s*([A-Za-z]{2,6})\b/, (m, ratio, unit)=>/^mmhg$/i.test(unit) ? `${ratio} mmHg` : note(m, `${ratio} mmHg`));
    // Dotted abbreviations: B.D. → BD, t.d.s → TDS.
    text = text.replace(/\b([a-z])\.\s?([a-z])\.?(?:\s?([a-z])\.?)?(?=\s|$)/gi, (m, a, b, c)=>{
        const key = (a + b + (c ?? '')).toLowerCase();
        return ABBREVIATIONS[key] ? note(m, ABBREVIATIONS[key]) : m;
    });
    const words = text.split(/(\s+)/);
    for(let i = 0; i < words.length; i++){
        const core = /^([^A-Za-z]*)([A-Za-z]+)([^A-Za-z]*)$/.exec(words[i]);
        if (!core) continue;
        const [, pre, word, post] = core;
        const fixed = ABBREVIATIONS[word.toLowerCase()] ?? nearestWord(word);
        if (!fixed) continue;
        // Exact matches only take canonical casing for drugs and abbreviations; other words keep the writer's casing.
        const same = fixed.toLowerCase() === word.toLowerCase();
        words[i] = pre + (same ? drugs.has(word.toLowerCase()) || ABBREVIATIONS[word.toLowerCase()] ? fixed : word : note(word, fixed)) + post;
    }
    // A short garbled first word before a drug name is almost always the dosage form (Fab → Tab).
    const first = words[0] ?? '', bare = first.replace(/\.$/, '').toLowerCase(), next = words.slice(1).find((w)=>w.trim());
    if (/^[a-z]{2,4}$/.test(bare) && !ABBREVIATIONS[bare] && next && drugs.has(next.replace(/[^A-Za-z]/g, '').toLowerCase())) {
        const [form, distance] = FORMS.map((f)=>[
                f,
                editDistance(bare, f.toLowerCase())
            ]).sort((a, b)=>a[1] - b[1])[0];
        if (distance <= 2) words[0] = note(first, form);
    }
    return {
        text: words.join('').replace(/\s+/g, ' ').trim(),
        changed
    };
}
function plausibility(text) {
    const tokens = text.split(/\s+/).map((t)=>t.replace(/^[^\w%]+|[^\w%]+$/g, '')).filter(Boolean);
    if (!tokens.length) return 0;
    let good = 0;
    for (const t of tokens){
        const lower = t.toLowerCase();
        // Dosing grids (morning-noon-night) only use 0, 1, 2 or ½; anything else is probably a misread digit.
        if (/^\d+-\d+-\d+$/.test(t)) good += /^[012½]-[012½]-[012½]$/.test(t) ? 1 : 0.3;
        else if (vocabulary.has(lower) || COMMON.has(lower) || ABBREVIATIONS[lower] || UNITS.has(lower) || /^\d+([./]\d+)*$/.test(t)) good++;
        else if (/^[a-z]{3,}$/i.test(t) && !/[^aeiouy]{5}/i.test(t)) good += 0.4; // pronounceable but unknown
    }
    const junk = (text.match(/[^\w\s.,:/%+()-]/g) ?? []).length / Math.max(1, text.length);
    return Math.max(0, good / tokens.length - junk * 2);
}
}),
"[project]/apps/web/src/platform/ocr-image.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Pure image steps for handwriting OCR: lighting normalisation, binarisation, skew estimate and
// line segmentation. Works on plain grayscale arrays so it runs in tests without a DOM.
__turbopack_context__.s([
    "binarize",
    ()=>binarize,
    "estimateSkew",
    ()=>estimateSkew,
    "letterHeight",
    ()=>letterHeight,
    "normalize",
    ()=>normalize,
    "otsu",
    ()=>otsu,
    "segmentLines",
    ()=>segmentLines,
    "toGray",
    ()=>toGray
]);
function toGray(rgba, width, height) {
    const data = new Uint8Array(width * height);
    for(let i = 0, p = 0; p < data.length; i += 4, p++)data[p] = 0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2] | 0;
    return {
        data,
        width,
        height
    };
}
function normalize(g, block = 32) {
    const { data, width, height } = g, gw = Math.ceil(width / block), gh = Math.ceil(height / block), grid = new Float32Array(gw * gh);
    for(let by = 0; by < gh; by++)for(let bx = 0; bx < gw; bx++){
        let max = 0;
        for(let y = by * block; y < Math.min(height, (by + 1) * block); y++)for(let x = bx * block; x < Math.min(width, (bx + 1) * block); x++){
            const v = data[y * width + x];
            if (v > max) max = v;
        }
        grid[by * gw + bx] = max;
    }
    // A block that is entirely ink has a dark "maximum"; smoothing with its neighbours' maxima recovers the paper level.
    const smooth = new Float32Array(gw * gh);
    for(let by = 0; by < gh; by++)for(let bx = 0; bx < gw; bx++){
        let best = 0;
        for(let dy = -1; dy <= 1; dy++)for(let dx = -1; dx <= 1; dx++){
            const x = bx + dx, y = by + dy;
            if (x >= 0 && y >= 0 && x < gw && y < gh) best = Math.max(best, grid[y * gw + x]);
        }
        smooth[by * gw + bx] = Math.max(1, best);
    }
    const out = new Uint8Array(width * height), hist = new Uint32Array(256);
    for(let y = 0; y < height; y++){
        const fy = Math.min(gh - 1, Math.max(0, y / block - 0.5)), y0 = Math.floor(fy), y1 = Math.min(gh - 1, y0 + 1), ty = fy - y0;
        for(let x = 0; x < width; x++){
            const fx = Math.min(gw - 1, Math.max(0, x / block - 0.5)), x0 = Math.floor(fx), x1 = Math.min(gw - 1, x0 + 1), tx = fx - x0;
            const bg = (smooth[y0 * gw + x0] * (1 - tx) + smooth[y0 * gw + x1] * tx) * (1 - ty) + (smooth[y1 * gw + x0] * (1 - tx) + smooth[y1 * gw + x1] * tx) * ty;
            const v = Math.min(255, Math.round(data[y * width + x] * 255 / bg));
            out[y * width + x] = v;
            hist[v]++;
        }
    }
    const total = width * height;
    let lo = 0, hi = 255, acc = 0;
    for(let v = 0; v < 256; v++){
        acc += hist[v];
        if (acc >= total * 0.01) {
            lo = v;
            break;
        }
    }
    acc = 0;
    for(let v = 255; v >= 0; v--){
        acc += hist[v];
        if (acc >= total * 0.01) {
            hi = v;
            break;
        }
    }
    // Never stretch less than 64 levels: a blank or faint page must not have its paper grain amplified into ink.
    lo = Math.min(lo, hi - 64);
    const range = hi - lo;
    for(let i = 0; i < out.length; i++)out[i] = Math.max(0, Math.min(255, Math.round((out[i] - lo) * 255 / range)));
    return {
        data: out,
        width,
        height
    };
}
function otsu(g) {
    const hist = new Float64Array(256);
    for (const v of g.data)hist[v]++;
    const total = g.data.length;
    let sum = 0;
    for(let v = 0; v < 256; v++)sum += v * hist[v];
    let sumB = 0, wB = 0, best = 0, threshold = 128;
    for(let t = 0; t < 256; t++){
        wB += hist[t];
        if (!wB) continue;
        const wF = total - wB;
        if (!wF) break;
        sumB += t * hist[t];
        const mB = sumB / wB, mF = (sum - sumB) / wF, between = wB * wF * (mB - mF) ** 2;
        if (between > best) {
            best = between;
            threshold = t;
        }
    }
    return threshold;
}
function binarize(g, threshold = Math.min(otsu(g), 200)) {
    const mask = new Uint8Array(g.data.length);
    for(let i = 0; i < mask.length; i++)mask[i] = g.data[i] <= threshold ? 1 : 0;
    return mask;
}
function estimateSkew(mask, width, height, maxDeg = 6, step = 0.5) {
    const sx = Math.max(1, Math.floor(width / 600)), points = [];
    for(let y = 0; y < height; y += sx)for(let x = 0; x < width; x += sx)if (mask[y * width + x]) points.push(x, y);
    if (points.length < 40) return 0;
    let bestDeg = 0, bestScore = -1;
    for(let deg = -maxDeg; deg <= maxDeg + 1e-9; deg += step){
        const t = Math.tan(deg * Math.PI / 180), offset = Math.ceil(Math.abs(t) * width), rows = new Float64Array(Math.ceil((height + 2 * offset) / sx) + 1);
        for(let i = 0; i < points.length; i += 2)rows[Math.floor((points[i + 1] + points[i] * t + offset) / sx)]++;
        let s = 0, s2 = 0;
        for (const r of rows){
            s += r;
            s2 += r * r;
        }
        const score = s2 - s * s / rows.length;
        if (score > bestScore + 1e-6 || Math.abs(score - bestScore) <= 1e-6 && Math.abs(deg) < Math.abs(bestDeg)) {
            bestScore = score;
            bestDeg = deg;
        }
    }
    return bestDeg;
}
// Lower median: merged (touching) lines are the tall outliers, so ties resolve toward a single line height.
const median = (values)=>{
    const s = [
        ...values
    ].sort((a, b)=>a - b);
    return s.length ? s[Math.floor((s.length - 1) / 2)] : 0;
};
function letterHeight(mask, width, height) {
    const parent = new Int32Array(width * height).fill(-1), find = (i)=>{
        while(parent[i] !== i){
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    };
    for(let y = 0; y < height; y++)for(let x = 0; x < width; x++){
        const i = y * width + x;
        if (!mask[i]) continue;
        parent[i] = i;
        for (const j of [
            i - 1,
            i - width - 1,
            i - width,
            i - width + 1
        ]){
            if (j < 0 || x === 0 && (j === i - 1 || j === i - width - 1) || x === width - 1 && j === i - width + 1 || parent[j] === -1) continue;
            const a = find(i), b = find(j);
            if (a !== b) parent[a] = b;
        }
    }
    const top = new Map(), bottom = new Map(), left = new Map(), right = new Map(), area = new Map();
    for(let y = 0; y < height; y++)for(let x = 0; x < width; x++){
        const i = y * width + x;
        if (parent[i] === -1) continue;
        const r = find(i);
        if (!top.has(r)) {
            top.set(r, y);
            left.set(r, x);
            right.set(r, x);
        }
        bottom.set(r, y);
        left.set(r, Math.min(left.get(r), x));
        right.set(r, Math.max(right.get(r), x));
        area.set(r, (area.get(r) ?? 0) + 1);
    }
    const heights = [];
    for (const [r, t] of top){
        const h = bottom.get(r) - t + 1, w = right.get(r) - left.get(r) + 1;
        if (h >= 4 && area.get(r) >= 10 && w < width * 0.5) heights.push(h);
    }
    return median(heights);
}
function segmentLines(mask, width, height, maxLines = 40) {
    const rowInk = new Float64Array(height);
    for(let y = 0; y < height; y++){
        let c = 0;
        for(let x = 0; x < width; x++)c += mask[y * width + x];
        rowInk[y] = c;
    }
    // Ruled lines: thin runs (≤4 rows) where most of the width is ink.
    for(let y = 0; y < height;){
        if (rowInk[y] > width * 0.6) {
            let end = y;
            while(end < height && rowInk[end] > width * 0.6)end++;
            if (end - y <= 4) for(let r = y; r < end; r++)rowInk[r] = 0;
            y = end;
        } else y++;
    }
    // Smooth over ~0.4 letter heights: closes gaps between a line's ascenders, x-height and descenders
    // (thin strokes leave them once the page is deskewed) but not the larger gaps between lines.
    const radius = Math.max(1, Math.round(letterHeight(mask, width, height) * 0.4)), smooth = new Float64Array(height);
    for(let y = 0; y < height; y++){
        let sum = 0, n = 0;
        for(let k = Math.max(0, y - radius); k <= Math.min(height - 1, y + radius); k++){
            sum += rowInk[k];
            n++;
        }
        smooth[y] = sum / n;
    }
    const nonzero = [
        ...smooth
    ].filter((v)=>v > 0).sort((a, b)=>a - b);
    if (!nonzero.length) return [];
    const threshold = Math.max(1, 0.08 * nonzero[Math.floor(nonzero.length * 0.9)]);
    let bands = [];
    for(let y = 0; y < height;){
        if (smooth[y] > threshold) {
            let end = y;
            while(end < height && smooth[end] > threshold)end++;
            bands.push({
                top: y,
                bottom: end
            });
            y = end;
        } else y++;
    }
    if (!bands.length) return [];
    let mh = median(bands.map((b)=>b.bottom - b.top));
    // Rejoin dots, accents and broken strokes separated from their line by a small gap.
    const merged = [];
    for (const b of bands){
        const last = merged.at(-1);
        if (last && b.top - last.bottom < 0.35 * mh && Math.min(b.bottom - b.top, last.bottom - last.top) < 0.6 * mh) last.bottom = b.bottom;
        else merged.push({
            ...b
        });
    }
    bands = merged;
    // Smoothing widens every band by about the radius; trim back to rows that actually carry ink so
    // band heights stay comparable (a merged pair of lines must still look twice as tall).
    for (const b of bands){
        while(b.top < b.bottom - 1 && rowInk[b.top] < threshold)b.top++;
        while(b.bottom - 1 > b.top && rowInk[b.bottom - 1] < threshold)b.bottom--;
    }
    mh = median(bands.map((b)=>b.bottom - b.top));
    const split = [];
    for (const b of bands){
        const h = b.bottom - b.top, parts = Math.round(h / mh);
        if (parts >= 2 && h > 1.7 * mh) {
            let start = b.top;
            for(let k = 1; k < parts; k++){
                const centre = b.top + Math.round(h * k / parts), lo = Math.max(start + 1, centre - Math.round(mh * 0.4)), hi = Math.min(b.bottom - 1, centre + Math.round(mh * 0.4));
                let cut = centre, min = Infinity;
                for(let y = lo; y <= hi; y++)if (rowInk[y] < min) {
                    min = rowInk[y];
                    cut = y;
                }
                // Two touching lines have two dense cores with a dip between; a heavy descender is one core and a faint tail.
                let above = 0, below = 0;
                for(let y = start; y < cut; y++)above = Math.max(above, rowInk[y]);
                for(let y = cut; y < b.bottom; y++)below = Math.max(below, rowInk[y]);
                if (Math.min(above, below) < 0.5 * Math.max(above, below) || min > 0.5 * Math.min(above, below)) continue;
                split.push({
                    top: start,
                    bottom: cut
                });
                start = cut;
            }
            split.push({
                top: start,
                bottom: b.bottom
            });
        } else split.push(b);
    }
    const boxes = [];
    for (const b of split){
        const h = b.bottom - b.top;
        if (h < Math.max(3, 0.3 * mh)) continue;
        const colInk = new Uint32Array(width);
        let ink = 0;
        for(let y = b.top; y < b.bottom; y++)for(let x = 0; x < width; x++)if (mask[y * width + x]) {
            colInk[x]++;
            ink++;
        }
        if (ink < Math.max(12, h * 1.5)) continue;
        let left = 0, right = width - 1;
        while(left < width && !colInk[left])left++;
        while(right > left && !colInk[right])right--;
        const padY = Math.round(h * 0.25), padX = Math.round(h * 0.5), top = Math.max(0, b.top - padY), x = Math.max(0, left - padX);
        boxes.push({
            x,
            y: top,
            w: Math.min(width, right + 1 + padX) - x,
            h: Math.min(height, b.bottom + padY) - top
        });
        if (boxes.length >= maxLines) break;
    }
    return boxes;
}
}),
"[project]/apps/web/src/platform/ocr.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TESSERACT_ENGINE",
    ()=>TESSERACT_ENGINE,
    "TROCR_ENGINE",
    ()=>TROCR_ENGINE,
    "recognize",
    ()=>recognize,
    "recognizeLabReport",
    ()=>recognizeLabReport
]);
// Local handwriting OCR. The page is lighting-normalised, deskewed and split into lines; each line is read by
// TrOCR (trained on real handwriting, in a Web Worker) and by Tesseract.js (print-trained, bundled under
// /tesseract), and the reading that makes more sense as prescription text wins. TrOCR is better on cursive,
// Tesseract on neat print. Nothing leaves the browser except TrOCR's one-time model download.
// Output is a candidate only: a clinician must compare every line with the original before signing.
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/ocr-image.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/apps/web/src/platform/medical-lexicon.ts [app-ssr] (ecmascript)");
var __TURBOPACK__import$2e$meta__ = {
    get url () {
        return __turbopack_context__.F("apps/web/src/platform/ocr.ts");
    },
    env: {
        DEV: true,
        PROD: false,
        MODE: "development",
        BASE_URL: "/",
        SSR: true
    },
    get turbopackHot () {
        return __turbopack_context__.m.hot;
    }
};
;
;
const TROCR_ENGINE = 'trocr-small-handwritten-q8+tesseract.js@7.0.0-line+lexicon@1';
const TESSERACT_ENGINE = 'tesseract.js@7.0.0/eng-best_int+lexicon';
// Prepared page: normalised, deskewed grayscale canvas plus the detected line boxes.
function prepare(source) {
    const w = source instanceof HTMLImageElement ? source.naturalWidth : source.width, h = source instanceof HTMLImageElement ? source.naturalHeight : source.height;
    const scale = Math.min(1, 2000 / Math.max(w, h)), canvas = document.createElement('canvas');
    canvas.width = Math.round(w * scale);
    canvas.height = Math.round(h * scale);
    const ctx = canvas.getContext('2d', {
        willReadFrequently: true
    });
    ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
    const put = (gray)=>{
        const img = ctx.createImageData(canvas.width, canvas.height);
        for(let p = 0, i = 0; p < gray.length; p++, i += 4){
            img.data[i] = img.data[i + 1] = img.data[i + 2] = gray[p];
            img.data[i + 3] = 255;
        }
        ctx.putImageData(img, 0, 0);
    };
    let gray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["normalize"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toGray"])(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height));
    put(gray.data);
    const skew = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["estimateSkew"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["binarize"])(gray), gray.width, gray.height);
    if (Math.abs(skew) >= 0.5) {
        // Positive skew means lines rise to the right; a clockwise rotation (canvas y points down) levels them.
        const copy = document.createElement('canvas');
        copy.width = canvas.width;
        copy.height = canvas.height;
        copy.getContext('2d').drawImage(canvas, 0, 0);
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(skew * Math.PI / 180);
        ctx.drawImage(copy, -canvas.width / 2, -canvas.height / 2);
        ctx.restore();
        gray = (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toGray"])(ctx.getImageData(0, 0, canvas.width, canvas.height).data, canvas.width, canvas.height);
    }
    return {
        canvas,
        boxes: (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["segmentLines"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$ocr$2d$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["binarize"])(gray), gray.width, gray.height)
    };
}
let worker = null, nextId = 1;
function getWorker() {
    worker ??= new Worker(new __turbopack_context__.U(__turbopack_context__.r("[project]/apps/web/src/platform/ocr.worker.ts (static in ecmascript, tag client)")), {
        type: 'module'
    });
    return worker;
}
function recognizeTrocr(canvas, boxes, onProgress) {
    const ctx = canvas.getContext('2d'), id = nextId++;
    const lines = boxes.map((b)=>{
        const img = ctx.getImageData(b.x, b.y, b.w, b.h);
        return {
            data: img.data,
            width: b.w,
            height: b.h
        };
    });
    const results = new Array(lines.length);
    return new Promise((resolve, reject)=>{
        const w = getWorker();
        const onMessage = (event)=>{
            const m = event.data;
            if (m.id !== id) return;
            if (m.type === 'loading') onProgress({
                stage: 'loading',
                progress: m.progress
            });
            else if (m.type === 'line') {
                results[m.index] = {
                    text: m.text,
                    confidence: m.confidence
                };
                onProgress({
                    stage: 'reading',
                    line: m.index + 1,
                    total: m.total
                });
            } else {
                w.removeEventListener('message', onMessage);
                w.removeEventListener('error', onError);
                m.type === 'done' ? resolve(results) : reject(new Error(m.message));
            }
        };
        const onError = (event)=>{
            w.removeEventListener('message', onMessage);
            w.removeEventListener('error', onError);
            worker?.terminate();
            worker = null;
            reject(new Error(event.message || 'OCR worker failed'));
        };
        w.addEventListener('message', onMessage);
        w.addEventListener('error', onError);
        w.postMessage({
            id,
            lines
        }, lines.map((l)=>l.data.buffer));
    });
}
let tesseract = null;
function getTesseract() {
    tesseract ??= (async ()=>{
        const { createWorker, OEM } = await __turbopack_context__.A("[project]/node_modules/tesseract.js/src/index.js [app-ssr] (ecmascript, async loader)");
        return createWorker('eng', OEM.LSTM_ONLY, {
            workerPath: '/tesseract/worker.min.js',
            corePath: '/tesseract',
            langPath: '/tesseract/lang',
            workerBlobURL: false
        });
    })().catch((e)=>{
        tesseract = null;
        throw e;
    });
    return tesseract;
}
async function recognizeTesseract(canvas) {
    const t = await getTesseract();
    await t.setParameters({
        tessedit_pageseg_mode: '3'
    });
    const { data } = await t.recognize(canvas, {}, {
        text: true,
        blocks: true
    });
    const lines = (data.blocks ?? []).flatMap((b)=>b.paragraphs.flatMap((p)=>p.lines.map((l)=>({
                    text: l.text.trim(),
                    confidence: Math.round(l.confidence)
                }))));
    return lines.length ? lines : data.text.split('\n').map((text)=>({
            text: text.trim(),
            confidence: 0
        }));
}
// Tesseract in single-line mode on each segmented line, with a white margin it expects around text.
async function recognizeTesseractLines(canvas, boxes) {
    const t = await getTesseract();
    await t.setParameters({
        tessedit_pageseg_mode: '7'
    });
    const out = [];
    for (const b of boxes){
        const pad = Math.round(b.h * 0.3), crop = document.createElement('canvas');
        crop.width = b.w + 2 * pad;
        crop.height = b.h + 2 * pad;
        const c = crop.getContext('2d');
        c.fillStyle = '#fff';
        c.fillRect(0, 0, crop.width, crop.height);
        c.drawImage(canvas, b.x, b.y, b.w, b.h, pad, pad, b.w, b.h);
        const { data } = await t.recognize(crop);
        out.push({
            text: data.text.replace(/\s+/g, ' ').trim(),
            confidence: Math.round(data.confidence)
        });
    }
    return out;
}
// Prescription-sense first, engine confidence second. TrOCR can invent fluent text for a smudge, so a reading
// far longer than the line's shape allows (about 3 characters per line-height of width) is discarded.
function score(line, box, engine) {
    if (!line?.text) return -1;
    if (engine === 'trocr' && line.text.length > 3 * (box.w / box.h) + 6) return -1;
    return 0.75 * (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["plausibility"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["correctLine"])(line.text).text) + 0.25 * line.confidence / 100;
}
function pick(trocr, tesseract, boxes) {
    return boxes.map((box, i)=>{
        const a = trocr?.[i], b = tesseract?.[i], sa = score(a, box, 'trocr'), sb = score(b, box, 'tesseract');
        const [win, lose] = sa >= sb ? [
            a,
            b
        ] : [
            b,
            a
        ];
        if (!win || Math.max(sa, sb) < 0) return {
            text: '',
            confidence: 0
        };
        const alternative = lose?.text && (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["correctLine"])(lose.text).text !== (0, __TURBOPACK__imported__module__$5b$project$5d2f$apps$2f$web$2f$src$2f$platform$2f$medical$2d$lexicon$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["correctLine"])(win.text).text ? lose.text : undefined;
        return {
            text: win.text,
            confidence: win.confidence,
            ...alternative ? {
                alternative
            } : {}
        };
    });
}
function preferredEngine() {
    try {
        return localStorage.getItem('pran-ocr-engine');
    } catch  {
        return null;
    }
}
async function recognize(source, onProgress = ()=>{}) {
    onProgress({
        stage: 'preparing'
    });
    const { canvas, boxes } = prepare(source);
    const done = (lines, engine)=>({
            text: lines.map((l)=>l.text).join('\n'),
            lines,
            engine
        });
    if (preferredEngine() === 'tesseract' || !boxes.length) return done(await recognizeTesseract(canvas), TESSERACT_ENGINE);
    const [trocr, tesseract] = await Promise.all([
        recognizeTrocr(canvas, boxes, onProgress).catch((error)=>{
            console.warn('Handwriting model unavailable; using Tesseract only', error);
            return null;
        }),
        recognizeTesseractLines(canvas, boxes).catch(()=>null)
    ]);
    if (!trocr && !tesseract) throw new Error('No OCR engine available');
    return done(pick(trocr, tesseract, boxes).filter((l)=>l.text), trocr ? TROCR_ENGINE : TESSERACT_ENGINE);
}
async function recognizeLabReport(source, onProgress = ()=>{}) {
    onProgress({
        stage: 'preparing'
    });
    const { canvas } = prepare(source);
    onProgress({
        stage: 'reading',
        line: 1,
        total: 1
    });
    const lines = await recognizeTesseract(canvas);
    return {
        text: lines.map((line)=>line.text).join('\n'),
        lines,
        engine: 'tesseract.js@7.0.0/eng-best_int/printed-page'
    };
}
}),
"[project]/apps/web/src/platform/ocr.worker.ts (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/ocr.worker.20pbcgqukz6bs.ts" + (globalThis["NEXT_CLIENT_ASSET_SUFFIX"] || ''));}),
"[project]/apps/web/src/platform/offline.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "browserDeviceId",
    ()=>browserDeviceId,
    "prepare",
    ()=>prepare,
    "prepareBrowserShell",
    ()=>prepareBrowserShell,
    "syncReceipts",
    ()=>syncReceipts,
    "unlock",
    ()=>unlock
]);
const canonical = (v)=>Array.isArray(v) ? '[' + v.map(canonical).join(',') + ']' : v && typeof v === 'object' ? '{' + Object.entries(v).sort(([a], [b])=>a.localeCompare(b)).map(([k, x])=>JSON.stringify(k) + ':' + canonical(x)).join(',') + '}' : JSON.stringify(v);
const bytes = (value)=>Uint8Array.from(atob(value), (c)=>c.charCodeAt(0));
function database() {
    return new Promise((resolve, reject)=>{
        const r = indexedDB.open('pran-rekha-offline', 1);
        r.onupgradeneeded = ()=>{
            r.result.createObjectStore('vault');
            r.result.createObjectStore('receipts', {
                autoIncrement: true
            });
        };
        r.onsuccess = ()=>resolve(r.result);
        r.onerror = ()=>reject(r.error);
    });
}
async function derive(phrase, salt) {
    const raw = await crypto.subtle.importKey('raw', new TextEncoder().encode(phrase), 'PBKDF2', false, [
        'deriveKey'
    ]);
    return crypto.subtle.deriveKey({
        name: 'PBKDF2',
        salt,
        iterations: 310000,
        hash: 'SHA-256'
    }, raw, {
        name: 'AES-GCM',
        length: 256
    }, false, [
        'encrypt',
        'decrypt'
    ]);
}
async function browserDeviceId() {
    const db = await database();
    try {
        return await new Promise((resolve, reject)=>{
            const tx = db.transaction('vault', 'readwrite'), vault = tx.objectStore('vault'), read = vault.get('device-id');
            let id;
            read.onsuccess = ()=>{
                id = typeof read.result === 'string' ? read.result : crypto.randomUUID();
                vault.put(id, 'device-id');
            };
            tx.oncomplete = ()=>resolve(id);
            tx.onerror = ()=>reject(tx.error);
            tx.onabort = ()=>reject(tx.error);
        });
    } finally{
        db.close();
    }
}
async function prepareBrowserShell() {
    if (!('serviceWorker' in navigator)) throw new Error('Offline preparation requires a secure browser origin.');
    await navigator.serviceWorker.register('/sw.js');
    await navigator.serviceWorker.ready;
    // This route is a static, unauthenticated shell. Never cache an API response.
    const assets = new Set([
        '/patient',
        '/offline.html'
    ]);
    for (const resource of performance.getEntriesByType('resource')){
        const url = new URL(resource.name);
        if (url.origin === location.origin && url.pathname.startsWith('/_next/static/')) assets.add(url.pathname);
    }
    const cache = await caches.open('pran-shell-v1');
    await cache.addAll([
        ...assets
    ]);
}
async function prepare(snapshot, phrase) {
    if (phrase.length < 12) throw new Error('Use an unlock phrase of at least 12 characters.');
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await derive(phrase, salt);
    const encrypted = await crypto.subtle.encrypt({
        name: 'AES-GCM',
        iv
    }, key, new TextEncoder().encode(JSON.stringify(snapshot)));
    const db = await database();
    await new Promise((resolve, reject)=>{
        const tx = db.transaction('vault', 'readwrite');
        tx.objectStore('vault').put({
            salt,
            iv,
            encrypted,
            publicKey: snapshot.publicKey,
            deviceId: snapshot.deviceId,
            lastTime: Date.now()
        }, 'snapshot');
        tx.oncomplete = ()=>resolve();
        tx.onerror = ()=>reject(tx.error);
        tx.onabort = ()=>reject(tx.error);
    });
    db.close();
}
async function unlock(phrase) {
    const db = await database();
    const saved = await new Promise((resolve, reject)=>{
        const r = db.transaction('vault').objectStore('vault').get('snapshot');
        r.onsuccess = ()=>r.result ? resolve(r.result) : reject(new Error('No prepared snapshot.'));
        r.onerror = ()=>reject(r.error);
    });
    if (Date.now() < saved.lastTime) throw new Error('Clock rollback detected.');
    const key = await derive(phrase, saved.salt);
    const plaintext = await crypto.subtle.decrypt({
        name: 'AES-GCM',
        iv: saved.iv
    }, key, saved.encrypted);
    const snapshot = JSON.parse(new TextDecoder().decode(plaintext));
    const revoked = await new Promise((resolve, reject)=>{
        const r = db.transaction('vault').objectStore('vault').get('revoked:' + snapshot.id);
        r.onsuccess = ()=>resolve(Boolean(r.result));
        r.onerror = ()=>reject(r.error);
    });
    if (revoked) throw new Error('Snapshot revoked.');
    if (navigator.onLine) {
        let knownRevoked = false;
        try {
            const response = await fetch('/api/platform/offline/status', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    snapshotId: snapshot.id
                })
            });
            if (response.ok) knownRevoked = Boolean((await response.json()).revoked);
        } catch  {}
        if (knownRevoked) {
            await new Promise((resolve, reject)=>{
                const tx = db.transaction('vault', 'readwrite');
                tx.objectStore('vault').put(true, 'revoked:' + snapshot.id);
                tx.oncomplete = ()=>resolve();
                tx.onerror = ()=>reject(tx.error);
            });
            throw new Error('Snapshot revoked.');
        }
    }
    const { signature, publicKey, ...body } = snapshot;
    if (publicKey !== saved.publicKey || snapshot.deviceId !== saved.deviceId || Date.parse(snapshot.expiresAt) <= Date.now()) throw new Error('Snapshot expired or binding invalid.');
    const pem = publicKey.replace(/-----[^-]+-----/g, '').replace(/\s/g, '');
    const verificationKey = await crypto.subtle.importKey('spki', bytes(pem), {
        name: 'Ed25519'
    }, false, [
        'verify'
    ]);
    if (!await crypto.subtle.verify('Ed25519', verificationKey, bytes(signature), new TextEncoder().encode(canonical(body)))) throw new Error('Snapshot signature invalid.');
    await new Promise((resolve, reject)=>{
        const tx = db.transaction([
            'vault',
            'receipts'
        ], 'readwrite');
        tx.objectStore('vault').put({
            ...saved,
            lastTime: Date.now()
        }, 'snapshot');
        tx.objectStore('receipts').add({
            snapshotId: snapshot.id,
            deviceId: snapshot.deviceId,
            at: new Date().toISOString()
        });
        tx.oncomplete = ()=>resolve();
        tx.onerror = ()=>reject(tx.error);
        tx.onabort = ()=>reject(tx.error);
    });
    db.close();
    return snapshot;
}
async function syncReceipts(post) {
    const db = await database();
    const queued = await new Promise((resolve, reject)=>{
        const out = [];
        const r = db.transaction('receipts').objectStore('receipts').openCursor();
        r.onsuccess = ()=>{
            const c = r.result;
            if (!c) {
                resolve(out);
                return;
            }
            out.push({
                key: Number(c.key),
                value: c.value
            });
            c.continue();
        };
        r.onerror = ()=>reject(r.error);
    });
    let synced = 0;
    for (const { key, value } of queued){
        try {
            await post({
                ...value,
                sequence: key
            });
        } catch  {
            break;
        }
        await new Promise((resolve, reject)=>{
            const tx = db.transaction('receipts', 'readwrite');
            tx.objectStore('receipts').delete(key);
            tx.oncomplete = ()=>resolve();
            tx.onerror = ()=>reject(tx.error);
        });
        synced++;
    }
    db.close();
    return synced;
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__1j8s8tl._.js.map