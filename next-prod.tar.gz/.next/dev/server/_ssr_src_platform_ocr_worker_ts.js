/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "(ssr)/./src/platform/ocr.worker.ts":
/*!************************************!*\
  !*** ./src/platform/ocr.worker.ts ***!
  \************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TROCR_MODEL: () => (/* binding */ TROCR_MODEL)\n/* harmony export */ });\n/* harmony import */ var _huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @huggingface/transformers */ \"@huggingface/transformers\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__]);\n_huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// Runs TrOCR (handwriting-trained) off the main thread. Model weights come from the Hugging Face CDN on\n// first use and are cached by the browser; images are processed here and never leave the device.\n\nconst TROCR_MODEL = 'Xenova/trocr-small-handwritten';\n// Greedy decoding picks the arg-max token, so the max softmax probability at each step is the chosen\n// token's probability. Their mean is a usable per-line confidence.\nclass ConfidenceTracker extends _huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__.LogitsProcessor {\n    probabilities = [];\n    _call(_inputIds, logits) {\n        const values = logits.data, width = logits.dims.at(-1), row = values.subarray(values.length - width);\n        let max = -Infinity;\n        for (const v of row)if (v > max) max = v;\n        let sum = 0;\n        for (const v of row)sum += Math.exp(v - max);\n        this.probabilities.push(1 / sum);\n        return logits;\n    }\n}\nlet loading = null;\nconst fileProgress = new Map();\nfunction load(report) {\n    loading ??= (async ()=>{\n        const progress_callback = (info)=>{\n            if (info.status === 'progress' && info.file) {\n                fileProgress.set(info.file, info.progress ?? 0);\n                const values = [\n                    ...fileProgress.values()\n                ];\n                report(Math.round(values.reduce((a, b)=>a + b, 0) / Math.max(values.length, 3)));\n            }\n        };\n        const [processor, tokenizer, model] = await Promise.all([\n            _huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__.AutoProcessor.from_pretrained(TROCR_MODEL, {\n                progress_callback\n            }),\n            _huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__.AutoTokenizer.from_pretrained(TROCR_MODEL, {\n                progress_callback\n            }),\n            _huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__.VisionEncoderDecoderModel.from_pretrained(TROCR_MODEL, {\n                dtype: 'q8',\n                device: 'wasm',\n                progress_callback\n            })\n        ]);\n        return {\n            processor,\n            tokenizer,\n            model\n        };\n    })().catch((error)=>{\n        loading = null;\n        throw error;\n    });\n    return loading;\n}\nself.onmessage = async (event)=>{\n    const { id, lines } = event.data;\n    const post = (message)=>self.postMessage(message);\n    try {\n        const { processor, tokenizer, model } = await load((progress)=>post({\n                id,\n                type: 'loading',\n                progress\n            }));\n        for (const [index, line] of lines.entries()){\n            const { pixel_values } = await processor(new _huggingface_transformers__WEBPACK_IMPORTED_MODULE_0__.RawImage(line.data, line.width, line.height, 4));\n            const tracker = new ConfidenceTracker();\n            const output = await model.generate({\n                inputs: pixel_values,\n                max_new_tokens: 64,\n                logits_processor: [\n                    tracker\n                ]\n            });\n            const text = tokenizer.batch_decode(output, {\n                skip_special_tokens: true\n            })[0]?.trim() ?? '';\n            const p = tracker.probabilities, confidence = p.length ? Math.round(100 * p.reduce((a, b)=>a + b, 0) / p.length) : 0;\n            post({\n                id,\n                type: 'line',\n                index,\n                total: lines.length,\n                text,\n                confidence\n            });\n        }\n        post({\n            id,\n            type: 'done'\n        });\n    } catch (error) {\n        post({\n            id,\n            type: 'error',\n            message: error instanceof Error ? error.message : String(error)\n        });\n    }\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHNzcikvLi9zcmMvcGxhdGZvcm0vb2NyLndvcmtlci50cyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLHdHQUF3RztBQUN4RyxpR0FBaUc7QUFDMkM7QUFFckksTUFBTUssY0FBYyxpQ0FBaUM7QUFTNUQscUdBQXFHO0FBQ3JHLG1FQUFtRTtBQUNuRSxNQUFNQywwQkFBMEJKLHNFQUFlQTtJQUM3Q0ssZ0JBQTBCLEVBQUUsQ0FBQztJQUM3QkMsTUFBTUMsU0FBcUIsRUFBRUMsTUFBYyxFQUFFO1FBQzNDLE1BQU1DLFNBQVNELE9BQU9FLElBQUksRUFBa0JDLFFBQVFILE9BQU9JLElBQUksQ0FBQ0MsRUFBRSxDQUFDLENBQUMsSUFBS0MsTUFBTUwsT0FBT00sUUFBUSxDQUFDTixPQUFPTyxNQUFNLEdBQUdMO1FBQy9HLElBQUlNLE1BQU0sQ0FBQ0M7UUFBVSxLQUFLLE1BQU1DLEtBQUtMLElBQUssSUFBSUssSUFBSUYsS0FBS0EsTUFBTUU7UUFDN0QsSUFBSUMsTUFBTTtRQUFHLEtBQUssTUFBTUQsS0FBS0wsSUFBS00sT0FBT0MsS0FBS0MsR0FBRyxDQUFDSCxJQUFJRjtRQUN0RCxJQUFJLENBQUNaLGFBQWEsQ0FBQ2tCLElBQUksQ0FBQyxJQUFJSDtRQUM1QixPQUFPWjtJQUNUO0FBQ0Y7QUFHQSxJQUFJZ0IsVUFBa0M7QUFDdEMsTUFBTUMsZUFBZSxJQUFJQztBQUV6QixTQUFTQyxLQUFLQyxNQUFrQztJQUM5Q0osWUFBWSxDQUFDO1FBQ1gsTUFBTUssb0JBQW9CLENBQUNDO1lBQ3pCLElBQUlBLEtBQUtDLE1BQU0sS0FBSyxjQUFjRCxLQUFLRSxJQUFJLEVBQUU7Z0JBQzNDUCxhQUFhUSxHQUFHLENBQUNILEtBQUtFLElBQUksRUFBRUYsS0FBS0ksUUFBUSxJQUFJO2dCQUM3QyxNQUFNekIsU0FBUzt1QkFBSWdCLGFBQWFoQixNQUFNO2lCQUFHO2dCQUN6Q21CLE9BQU9QLEtBQUtjLEtBQUssQ0FBQzFCLE9BQU8yQixNQUFNLENBQUMsQ0FBQ0MsR0FBR0MsSUFBTUQsSUFBSUMsR0FBRyxLQUFLakIsS0FBS0osR0FBRyxDQUFDUixPQUFPTyxNQUFNLEVBQUU7WUFDaEY7UUFDRjtRQUNBLE1BQU0sQ0FBQ3VCLFdBQVdDLFdBQVdDLE1BQU0sR0FBRyxNQUFNQyxRQUFRQyxHQUFHLENBQUM7WUFDdEQ3QyxvRUFBYUEsQ0FBQzhDLGVBQWUsQ0FBQ3pDLGFBQWE7Z0JBQUUwQjtZQUFrQjtZQUMvRDlCLG9FQUFhQSxDQUFDNkMsZUFBZSxDQUFDekMsYUFBYTtnQkFBRTBCO1lBQWtCO1lBQy9EM0IsZ0ZBQXlCQSxDQUFDMEMsZUFBZSxDQUFDekMsYUFBYTtnQkFBRTBDLE9BQU87Z0JBQU1DLFFBQVE7Z0JBQVFqQjtZQUFrQjtTQUN6RztRQUNELE9BQU87WUFBRVU7WUFBV0M7WUFBV0M7UUFBTTtJQUN2QyxLQUFLTSxLQUFLLENBQUNDLENBQUFBO1FBQVd4QixVQUFVO1FBQU0sTUFBTXdCO0lBQU87SUFDbkQsT0FBT3hCO0FBQ1Q7QUFFQXlCLEtBQUtDLFNBQVMsR0FBRyxPQUFPQztJQUN0QixNQUFNLEVBQUVDLEVBQUUsRUFBRUMsS0FBSyxFQUFFLEdBQUdGLE1BQU16QyxJQUFJO0lBQ2hDLE1BQU00QyxPQUFPLENBQUNDLFVBQTJCTixLQUFLTyxXQUFXLENBQUNEO0lBQzFELElBQUk7UUFDRixNQUFNLEVBQUVoQixTQUFTLEVBQUVDLFNBQVMsRUFBRUMsS0FBSyxFQUFFLEdBQUcsTUFBTWQsS0FBS08sQ0FBQUEsV0FBWW9CLEtBQUs7Z0JBQUVGO2dCQUFJSyxNQUFNO2dCQUFXdkI7WUFBUztRQUNwRyxLQUFLLE1BQU0sQ0FBQ3dCLE9BQU9DLEtBQUssSUFBSU4sTUFBTU8sT0FBTyxHQUFJO1lBQzNDLE1BQU0sRUFBRUMsWUFBWSxFQUFFLEdBQUcsTUFBTXRCLFVBQVUsSUFBSXRDLCtEQUFRQSxDQUFDMEQsS0FBS2pELElBQUksRUFBRWlELEtBQUtoRCxLQUFLLEVBQUVnRCxLQUFLRyxNQUFNLEVBQUU7WUFDMUYsTUFBTUMsVUFBVSxJQUFJM0Q7WUFDcEIsTUFBTTRELFNBQVMsTUFBTXZCLE1BQU13QixRQUFRLENBQUM7Z0JBQUVDLFFBQVFMO2dCQUFjTSxnQkFBZ0I7Z0JBQUlDLGtCQUFrQjtvQkFBQ0w7aUJBQVE7WUFBQztZQUM1RyxNQUFNTSxPQUFPN0IsVUFBVThCLFlBQVksQ0FBQ04sUUFBUTtnQkFBRU8scUJBQXFCO1lBQUssRUFBRSxDQUFDLEVBQUUsRUFBRUMsVUFBVTtZQUN6RixNQUFNQyxJQUFJVixRQUFRMUQsYUFBYSxFQUFFcUUsYUFBYUQsRUFBRXpELE1BQU0sR0FBR0ssS0FBS2MsS0FBSyxDQUFDLE1BQU1zQyxFQUFFckMsTUFBTSxDQUFDLENBQUNDLEdBQUdDLElBQU1ELElBQUlDLEdBQUcsS0FBS21DLEVBQUV6RCxNQUFNLElBQUk7WUFDckhzQyxLQUFLO2dCQUFFRjtnQkFBSUssTUFBTTtnQkFBUUM7Z0JBQU9pQixPQUFPdEIsTUFBTXJDLE1BQU07Z0JBQUVxRDtnQkFBTUs7WUFBVztRQUN4RTtRQUNBcEIsS0FBSztZQUFFRjtZQUFJSyxNQUFNO1FBQU87SUFDMUIsRUFBRSxPQUFPVCxPQUFPO1FBQ2RNLEtBQUs7WUFBRUY7WUFBSUssTUFBTTtZQUFTRixTQUFTUCxpQkFBaUI0QixRQUFRNUIsTUFBTU8sT0FBTyxHQUFHc0IsT0FBTzdCO1FBQU87SUFDNUY7QUFDRiIsInNvdXJjZXMiOlsiQzpcXHBlcnNvbmFsX2ZpbGVzXFxjb2RlZm9sZGVyc1xcdHNcXHVsbGVuc1xcdWxsZW5zX2hhY2thdGhvblxcYXBwc1xcd2ViXFxzcmNcXHBsYXRmb3JtXFxvY3Iud29ya2VyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJ1bnMgVHJPQ1IgKGhhbmR3cml0aW5nLXRyYWluZWQpIG9mZiB0aGUgbWFpbiB0aHJlYWQuIE1vZGVsIHdlaWdodHMgY29tZSBmcm9tIHRoZSBIdWdnaW5nIEZhY2UgQ0ROIG9uXHJcbi8vIGZpcnN0IHVzZSBhbmQgYXJlIGNhY2hlZCBieSB0aGUgYnJvd3NlcjsgaW1hZ2VzIGFyZSBwcm9jZXNzZWQgaGVyZSBhbmQgbmV2ZXIgbGVhdmUgdGhlIGRldmljZS5cclxuaW1wb3J0IHsgQXV0b1Byb2Nlc3NvciwgQXV0b1Rva2VuaXplciwgTG9naXRzUHJvY2Vzc29yLCBSYXdJbWFnZSwgVmlzaW9uRW5jb2RlckRlY29kZXJNb2RlbCwgdHlwZSBUZW5zb3IgfSBmcm9tICdAaHVnZ2luZ2ZhY2UvdHJhbnNmb3JtZXJzJztcclxuXHJcbmV4cG9ydCBjb25zdCBUUk9DUl9NT0RFTCA9ICdYZW5vdmEvdHJvY3Itc21hbGwtaGFuZHdyaXR0ZW4nO1xyXG5leHBvcnQgdHlwZSBXb3JrZXJMaW5lID0geyBkYXRhOiBVaW50OENsYW1wZWRBcnJheTsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfTtcclxuZXhwb3J0IHR5cGUgV29ya2VyUmVxdWVzdCA9IHsgaWQ6IG51bWJlcjsgbGluZXM6IFdvcmtlckxpbmVbXSB9O1xyXG5leHBvcnQgdHlwZSBXb3JrZXJNZXNzYWdlID1cclxuICB8IHsgaWQ6IG51bWJlcjsgdHlwZTogJ2xvYWRpbmcnOyBwcm9ncmVzczogbnVtYmVyIH1cclxuICB8IHsgaWQ6IG51bWJlcjsgdHlwZTogJ2xpbmUnOyBpbmRleDogbnVtYmVyOyB0b3RhbDogbnVtYmVyOyB0ZXh0OiBzdHJpbmc7IGNvbmZpZGVuY2U6IG51bWJlciB9XHJcbiAgfCB7IGlkOiBudW1iZXI7IHR5cGU6ICdkb25lJyB9XHJcbiAgfCB7IGlkOiBudW1iZXI7IHR5cGU6ICdlcnJvcic7IG1lc3NhZ2U6IHN0cmluZyB9O1xyXG5cclxuLy8gR3JlZWR5IGRlY29kaW5nIHBpY2tzIHRoZSBhcmctbWF4IHRva2VuLCBzbyB0aGUgbWF4IHNvZnRtYXggcHJvYmFiaWxpdHkgYXQgZWFjaCBzdGVwIGlzIHRoZSBjaG9zZW5cclxuLy8gdG9rZW4ncyBwcm9iYWJpbGl0eS4gVGhlaXIgbWVhbiBpcyBhIHVzYWJsZSBwZXItbGluZSBjb25maWRlbmNlLlxyXG5jbGFzcyBDb25maWRlbmNlVHJhY2tlciBleHRlbmRzIExvZ2l0c1Byb2Nlc3NvciB7XHJcbiAgcHJvYmFiaWxpdGllczogbnVtYmVyW10gPSBbXTtcclxuICBfY2FsbChfaW5wdXRJZHM6IGJpZ2ludFtdW10sIGxvZ2l0czogVGVuc29yKSB7XHJcbiAgICBjb25zdCB2YWx1ZXMgPSBsb2dpdHMuZGF0YSBhcyBGbG9hdDMyQXJyYXksIHdpZHRoID0gbG9naXRzLmRpbXMuYXQoLTEpISwgcm93ID0gdmFsdWVzLnN1YmFycmF5KHZhbHVlcy5sZW5ndGggLSB3aWR0aCk7XHJcbiAgICBsZXQgbWF4ID0gLUluZmluaXR5OyBmb3IgKGNvbnN0IHYgb2Ygcm93KSBpZiAodiA+IG1heCkgbWF4ID0gdjtcclxuICAgIGxldCBzdW0gPSAwOyBmb3IgKGNvbnN0IHYgb2Ygcm93KSBzdW0gKz0gTWF0aC5leHAodiAtIG1heCk7XHJcbiAgICB0aGlzLnByb2JhYmlsaXRpZXMucHVzaCgxIC8gc3VtKTtcclxuICAgIHJldHVybiBsb2dpdHM7XHJcbiAgfVxyXG59XHJcblxyXG50eXBlIExvYWRlZCA9IHsgcHJvY2Vzc29yOiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIEF1dG9Qcm9jZXNzb3IuZnJvbV9wcmV0cmFpbmVkPj47IHRva2VuaXplcjogQXdhaXRlZDxSZXR1cm5UeXBlPHR5cGVvZiBBdXRvVG9rZW5pemVyLmZyb21fcHJldHJhaW5lZD4+OyBtb2RlbDogQXdhaXRlZDxSZXR1cm5UeXBlPHR5cGVvZiBWaXNpb25FbmNvZGVyRGVjb2Rlck1vZGVsLmZyb21fcHJldHJhaW5lZD4+IH07XHJcbmxldCBsb2FkaW5nOiBQcm9taXNlPExvYWRlZD4gfCBudWxsID0gbnVsbDtcclxuY29uc3QgZmlsZVByb2dyZXNzID0gbmV3IE1hcDxzdHJpbmcsIG51bWJlcj4oKTtcclxuXHJcbmZ1bmN0aW9uIGxvYWQocmVwb3J0OiAocHJvZ3Jlc3M6IG51bWJlcikgPT4gdm9pZCk6IFByb21pc2U8TG9hZGVkPiB7XHJcbiAgbG9hZGluZyA/Pz0gKGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHByb2dyZXNzX2NhbGxiYWNrID0gKGluZm86IHsgc3RhdHVzOiBzdHJpbmc7IGZpbGU/OiBzdHJpbmc7IHByb2dyZXNzPzogbnVtYmVyIH0pID0+IHtcclxuICAgICAgaWYgKGluZm8uc3RhdHVzID09PSAncHJvZ3Jlc3MnICYmIGluZm8uZmlsZSkge1xyXG4gICAgICAgIGZpbGVQcm9ncmVzcy5zZXQoaW5mby5maWxlLCBpbmZvLnByb2dyZXNzID8/IDApO1xyXG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IFsuLi5maWxlUHJvZ3Jlc3MudmFsdWVzKCldO1xyXG4gICAgICAgIHJlcG9ydChNYXRoLnJvdW5kKHZhbHVlcy5yZWR1Y2UoKGEsIGIpID0+IGEgKyBiLCAwKSAvIE1hdGgubWF4KHZhbHVlcy5sZW5ndGgsIDMpKSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICBjb25zdCBbcHJvY2Vzc29yLCB0b2tlbml6ZXIsIG1vZGVsXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcclxuICAgICAgQXV0b1Byb2Nlc3Nvci5mcm9tX3ByZXRyYWluZWQoVFJPQ1JfTU9ERUwsIHsgcHJvZ3Jlc3NfY2FsbGJhY2sgfSksXHJcbiAgICAgIEF1dG9Ub2tlbml6ZXIuZnJvbV9wcmV0cmFpbmVkKFRST0NSX01PREVMLCB7IHByb2dyZXNzX2NhbGxiYWNrIH0pLFxyXG4gICAgICBWaXNpb25FbmNvZGVyRGVjb2Rlck1vZGVsLmZyb21fcHJldHJhaW5lZChUUk9DUl9NT0RFTCwgeyBkdHlwZTogJ3E4JywgZGV2aWNlOiAnd2FzbScsIHByb2dyZXNzX2NhbGxiYWNrIH0pLFxyXG4gICAgXSk7XHJcbiAgICByZXR1cm4geyBwcm9jZXNzb3IsIHRva2VuaXplciwgbW9kZWwgfTtcclxuICB9KSgpLmNhdGNoKGVycm9yID0+IHsgbG9hZGluZyA9IG51bGw7IHRocm93IGVycm9yOyB9KTtcclxuICByZXR1cm4gbG9hZGluZztcclxufVxyXG5cclxuc2VsZi5vbm1lc3NhZ2UgPSBhc3luYyAoZXZlbnQ6IE1lc3NhZ2VFdmVudDxXb3JrZXJSZXF1ZXN0PikgPT4ge1xyXG4gIGNvbnN0IHsgaWQsIGxpbmVzIH0gPSBldmVudC5kYXRhO1xyXG4gIGNvbnN0IHBvc3QgPSAobWVzc2FnZTogV29ya2VyTWVzc2FnZSkgPT4gc2VsZi5wb3N0TWVzc2FnZShtZXNzYWdlKTtcclxuICB0cnkge1xyXG4gICAgY29uc3QgeyBwcm9jZXNzb3IsIHRva2VuaXplciwgbW9kZWwgfSA9IGF3YWl0IGxvYWQocHJvZ3Jlc3MgPT4gcG9zdCh7IGlkLCB0eXBlOiAnbG9hZGluZycsIHByb2dyZXNzIH0pKTtcclxuICAgIGZvciAoY29uc3QgW2luZGV4LCBsaW5lXSBvZiBsaW5lcy5lbnRyaWVzKCkpIHtcclxuICAgICAgY29uc3QgeyBwaXhlbF92YWx1ZXMgfSA9IGF3YWl0IHByb2Nlc3NvcihuZXcgUmF3SW1hZ2UobGluZS5kYXRhLCBsaW5lLndpZHRoLCBsaW5lLmhlaWdodCwgNCkpO1xyXG4gICAgICBjb25zdCB0cmFja2VyID0gbmV3IENvbmZpZGVuY2VUcmFja2VyKCk7XHJcbiAgICAgIGNvbnN0IG91dHB1dCA9IGF3YWl0IG1vZGVsLmdlbmVyYXRlKHsgaW5wdXRzOiBwaXhlbF92YWx1ZXMsIG1heF9uZXdfdG9rZW5zOiA2NCwgbG9naXRzX3Byb2Nlc3NvcjogW3RyYWNrZXJdIH0gYXMgbmV2ZXIpIGFzIFRlbnNvcjtcclxuICAgICAgY29uc3QgdGV4dCA9IHRva2VuaXplci5iYXRjaF9kZWNvZGUob3V0cHV0LCB7IHNraXBfc3BlY2lhbF90b2tlbnM6IHRydWUgfSlbMF0/LnRyaW0oKSA/PyAnJztcclxuICAgICAgY29uc3QgcCA9IHRyYWNrZXIucHJvYmFiaWxpdGllcywgY29uZmlkZW5jZSA9IHAubGVuZ3RoID8gTWF0aC5yb3VuZCgxMDAgKiBwLnJlZHVjZSgoYSwgYikgPT4gYSArIGIsIDApIC8gcC5sZW5ndGgpIDogMDtcclxuICAgICAgcG9zdCh7IGlkLCB0eXBlOiAnbGluZScsIGluZGV4LCB0b3RhbDogbGluZXMubGVuZ3RoLCB0ZXh0LCBjb25maWRlbmNlIH0pO1xyXG4gICAgfVxyXG4gICAgcG9zdCh7IGlkLCB0eXBlOiAnZG9uZScgfSk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHBvc3QoeyBpZCwgdHlwZTogJ2Vycm9yJywgbWVzc2FnZTogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBTdHJpbmcoZXJyb3IpIH0pO1xyXG4gIH1cclxufTtcclxuIl0sIm5hbWVzIjpbIkF1dG9Qcm9jZXNzb3IiLCJBdXRvVG9rZW5pemVyIiwiTG9naXRzUHJvY2Vzc29yIiwiUmF3SW1hZ2UiLCJWaXNpb25FbmNvZGVyRGVjb2Rlck1vZGVsIiwiVFJPQ1JfTU9ERUwiLCJDb25maWRlbmNlVHJhY2tlciIsInByb2JhYmlsaXRpZXMiLCJfY2FsbCIsIl9pbnB1dElkcyIsImxvZ2l0cyIsInZhbHVlcyIsImRhdGEiLCJ3aWR0aCIsImRpbXMiLCJhdCIsInJvdyIsInN1YmFycmF5IiwibGVuZ3RoIiwibWF4IiwiSW5maW5pdHkiLCJ2Iiwic3VtIiwiTWF0aCIsImV4cCIsInB1c2giLCJsb2FkaW5nIiwiZmlsZVByb2dyZXNzIiwiTWFwIiwibG9hZCIsInJlcG9ydCIsInByb2dyZXNzX2NhbGxiYWNrIiwiaW5mbyIsInN0YXR1cyIsImZpbGUiLCJzZXQiLCJwcm9ncmVzcyIsInJvdW5kIiwicmVkdWNlIiwiYSIsImIiLCJwcm9jZXNzb3IiLCJ0b2tlbml6ZXIiLCJtb2RlbCIsIlByb21pc2UiLCJhbGwiLCJmcm9tX3ByZXRyYWluZWQiLCJkdHlwZSIsImRldmljZSIsImNhdGNoIiwiZXJyb3IiLCJzZWxmIiwib25tZXNzYWdlIiwiZXZlbnQiLCJpZCIsImxpbmVzIiwicG9zdCIsIm1lc3NhZ2UiLCJwb3N0TWVzc2FnZSIsInR5cGUiLCJpbmRleCIsImxpbmUiLCJlbnRyaWVzIiwicGl4ZWxfdmFsdWVzIiwiaGVpZ2h0IiwidHJhY2tlciIsIm91dHB1dCIsImdlbmVyYXRlIiwiaW5wdXRzIiwibWF4X25ld190b2tlbnMiLCJsb2dpdHNfcHJvY2Vzc29yIiwidGV4dCIsImJhdGNoX2RlY29kZSIsInNraXBfc3BlY2lhbF90b2tlbnMiLCJ0cmltIiwicCIsImNvbmZpZGVuY2UiLCJ0b3RhbCIsIkVycm9yIiwiU3RyaW5nIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(ssr)/./src/platform/ocr.worker.ts\n");

/***/ }),

/***/ "@huggingface/transformers":
/*!********************************************!*\
  !*** external "@huggingface/transformers" ***!
  \********************************************/
/***/ ((module) => {

module.exports = import("@huggingface/transformers");;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete __webpack_module_cache__[moduleId];
/******/ 		}
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/async module */
/******/ 	(() => {
/******/ 		var webpackQueues = typeof Symbol === "function" ? Symbol("webpack queues") : "__webpack_queues__";
/******/ 		var webpackExports = typeof Symbol === "function" ? Symbol("webpack exports") : "__webpack_exports__";
/******/ 		var webpackError = typeof Symbol === "function" ? Symbol("webpack error") : "__webpack_error__";
/******/ 		var resolveQueue = (queue) => {
/******/ 			if(queue && queue.d < 1) {
/******/ 				queue.d = 1;
/******/ 				queue.forEach((fn) => (fn.r--));
/******/ 				queue.forEach((fn) => (fn.r-- ? fn.r++ : fn()));
/******/ 			}
/******/ 		}
/******/ 		var wrapDeps = (deps) => (deps.map((dep) => {
/******/ 			if(dep !== null && typeof dep === "object") {
/******/ 				if(dep[webpackQueues]) return dep;
/******/ 				if(dep.then) {
/******/ 					var queue = [];
/******/ 					queue.d = 0;
/******/ 					dep.then((r) => {
/******/ 						obj[webpackExports] = r;
/******/ 						resolveQueue(queue);
/******/ 					}, (e) => {
/******/ 						obj[webpackError] = e;
/******/ 						resolveQueue(queue);
/******/ 					});
/******/ 					var obj = {};
/******/ 					obj[webpackQueues] = (fn) => (fn(queue));
/******/ 					return obj;
/******/ 				}
/******/ 			}
/******/ 			var ret = {};
/******/ 			ret[webpackQueues] = x => {};
/******/ 			ret[webpackExports] = dep;
/******/ 			return ret;
/******/ 		}));
/******/ 		__webpack_require__.a = (module, body, hasAwait) => {
/******/ 			var queue;
/******/ 			hasAwait && ((queue = []).d = -1);
/******/ 			var depQueues = new Set();
/******/ 			var exports = module.exports;
/******/ 			var currentDeps;
/******/ 			var outerResolve;
/******/ 			var reject;
/******/ 			var promise = new Promise((resolve, rej) => {
/******/ 				reject = rej;
/******/ 				outerResolve = resolve;
/******/ 			});
/******/ 			promise[webpackExports] = exports;
/******/ 			promise[webpackQueues] = (fn) => (queue && fn(queue), depQueues.forEach(fn), promise["catch"](x => {}));
/******/ 			module.exports = promise;
/******/ 			body((deps) => {
/******/ 				currentDeps = wrapDeps(deps);
/******/ 				var fn;
/******/ 				var getResult = () => (currentDeps.map((d) => {
/******/ 					if(d[webpackError]) throw d[webpackError];
/******/ 					return d[webpackExports];
/******/ 				}))
/******/ 				var promise = new Promise((resolve) => {
/******/ 					fn = () => (resolve(getResult));
/******/ 					fn.r = 0;
/******/ 					var fnQueue = (q) => (q !== queue && !depQueues.has(q) && (depQueues.add(q), q && !q.d && (fn.r++, q.push(fn))));
/******/ 					currentDeps.map((dep) => (dep[webpackQueues](fnQueue)));
/******/ 				});
/******/ 				return fn.r ? promise : getResult();
/******/ 			}, (err) => ((err ? reject(promise[webpackError] = err) : outerResolve(exports)), resolveQueue(queue)));
/******/ 			queue && queue.d < 0 && (queue.d = 0);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("(ssr)/./src/platform/ocr.worker.ts");
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;