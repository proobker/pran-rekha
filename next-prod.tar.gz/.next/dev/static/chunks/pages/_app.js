__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_dist_compiled_199if1i._.js",
  "static/chunks/node_modules_next_dist_shared_lib_0c-iiom._.js",
  "static/chunks/node_modules_next_dist_client_16lnmlo._.js",
  "static/chunks/node_modules_next_dist_20ud_8w._.js",
  "static/chunks/node_modules_next_app_0yrdk3r.js",
  "static/chunks/[next]_entry_page-loader_ts_0z3haqk._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom-client_development_1nq9a-7.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_0d3scg3.js",
  "static/chunks/node_modules_react-dom_13voigl._.js",
  "static/chunks/node_modules_10e2-xo._.js",
  "static/chunks/[root-of-the-server]__0v4f-fb._.js",
  "static/chunks/apps_web_pages__app_0du2_q-._.js",
  "static/chunks/turbopack-apps_web_pages__app_10rd6wi._.js"
])
