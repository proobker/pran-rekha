__turbopack_load_page_chunks__("/_error", [
  "static/chunks/node_modules_next_dist_compiled_199if1i._.js",
  "static/chunks/node_modules_next_dist_shared_lib_1-1urvf._.js",
  "static/chunks/node_modules_next_dist_client_16lnmlo._.js",
  "static/chunks/node_modules_next_dist_1wf0dq6._.js",
  "static/chunks/[next]_entry_page-loader_ts_1aoli7m._.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom-client_development_1nq9a-7.js",
  "static/chunks/node_modules_react-dom_cjs_react-dom_development_0d3scg3.js",
  "static/chunks/node_modules_react-dom_13voigl._.js",
  "static/chunks/node_modules_10e2-xo._.js",
  "static/chunks/[root-of-the-server]__0nu-1gm._.js",
  "static/chunks/apps_web_pages__error_0du2_q-._.js",
  "static/chunks/turbopack-apps_web_pages__error_13wievi._.js"
])
