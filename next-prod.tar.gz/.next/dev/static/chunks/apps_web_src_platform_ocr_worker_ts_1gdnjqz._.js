(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_onnxruntime-web_dist_20xkdlb._.js","static/chunks/node_modules_@huggingface_transformers_dist_transformers_web_1a07gw1.js","static/chunks/node_modules_1cigw7a._.js","static/chunks/apps_web_src_platform_ocr_worker_ts_0m4h51g._.js"],
    source: "entry"
});
