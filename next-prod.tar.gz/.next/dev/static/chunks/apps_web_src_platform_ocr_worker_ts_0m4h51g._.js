(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/apps/web/src/platform/ocr.worker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TROCR_MODEL",
    ()=>TROCR_MODEL
]);
// Runs TrOCR (handwriting-trained) off the main thread. Model weights come from the Hugging Face CDN on
// first use and are cached by the browser; images are processed here and never leave the device.
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$transformers$2f$dist$2f$transformers$2e$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@huggingface/transformers/dist/transformers.web.js [app-client] (ecmascript)");
;
const TROCR_MODEL = 'Xenova/trocr-small-handwritten';
// Greedy decoding picks the arg-max token, so the max softmax probability at each step is the chosen
// token's probability. Their mean is a usable per-line confidence.
class ConfidenceTracker extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$transformers$2f$dist$2f$transformers$2e$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LogitsProcessor"] {
    probabilities = [];
    _call(_inputIds, logits) {
        const values = logits.data, width = logits.dims.at(-1), row = values.subarray(values.length - width);
        let max = -Infinity;
        for (const v of row)if (v > max) max = v;
        let sum = 0;
        for (const v of row)sum += Math.exp(v - max);
        this.probabilities.push(1 / sum);
        return logits;
    }
}
let loading = null;
const fileProgress = new Map();
function load(report) {
    loading ??= (async ()=>{
        const progress_callback = (info)=>{
            if (info.status === 'progress' && info.file) {
                fileProgress.set(info.file, info.progress ?? 0);
                const values = [
                    ...fileProgress.values()
                ];
                report(Math.round(values.reduce((a, b)=>a + b, 0) / Math.max(values.length, 3)));
            }
        };
        const [processor, tokenizer, model] = await Promise.all([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$transformers$2f$dist$2f$transformers$2e$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutoProcessor"].from_pretrained(TROCR_MODEL, {
                progress_callback
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$transformers$2f$dist$2f$transformers$2e$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AutoTokenizer"].from_pretrained(TROCR_MODEL, {
                progress_callback
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$transformers$2f$dist$2f$transformers$2e$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VisionEncoderDecoderModel"].from_pretrained(TROCR_MODEL, {
                dtype: 'q8',
                device: 'wasm',
                progress_callback
            })
        ]);
        return {
            processor,
            tokenizer,
            model
        };
    })().catch((error)=>{
        loading = null;
        throw error;
    });
    return loading;
}
self.onmessage = async (event)=>{
    const { id, lines } = event.data;
    const post = (message)=>self.postMessage(message);
    try {
        const { processor, tokenizer, model } = await load((progress)=>post({
                id,
                type: 'loading',
                progress
            }));
        for (const [index, line] of lines.entries()){
            const { pixel_values } = await processor(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$huggingface$2f$transformers$2f$dist$2f$transformers$2e$web$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RawImage"](line.data, line.width, line.height, 4));
            const tracker = new ConfidenceTracker();
            const output = await model.generate({
                inputs: pixel_values,
                max_new_tokens: 64,
                logits_processor: [
                    tracker
                ]
            });
            const text = tokenizer.batch_decode(output, {
                skip_special_tokens: true
            })[0]?.trim() ?? '';
            const p = tracker.probabilities, confidence = p.length ? Math.round(100 * p.reduce((a, b)=>a + b, 0) / p.length) : 0;
            post({
                id,
                type: 'line',
                index,
                total: lines.length,
                text,
                confidence
            });
        }
        post({
            id,
            type: 'done'
        });
    } catch (error) {
        post({
            id,
            type: 'error',
            message: error instanceof Error ? error.message : String(error)
        });
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=apps_web_src_platform_ocr_worker_ts_0m4h51g._.js.map