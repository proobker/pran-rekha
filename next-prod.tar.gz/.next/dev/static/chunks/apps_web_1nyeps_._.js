(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1avbg75._.css","static/chunks/node_modules_next_dist_20wefz_._.js","static/chunks/node_modules_09k1s32._.js","static/chunks/[root-of-the-server]__1qj73wq._.js","static/chunks/node_modules_0btgihn._.js","static/chunks/node_modules_@vladmandic_face-api_dist_face-api_esm_15c908v.js","static/chunks/node_modules_next_dist_compiled_buffer_index_18vu4gz.js","static/chunks/node_modules_0gwxx19._.js"],
    source: "entry"
});
